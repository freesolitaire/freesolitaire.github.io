var __extends = (this && this.__extends) || (function() {
    var extendStatics = Object.setPrototypeOf || ({
            __proto__: []
        }
        instanceof Array && function(d, b) {
            d.__proto__ = b;
        }) || function(d, b) {
        for (var p in b)
            if (b.hasOwnProperty(p)) d[p] = b[p];
    };
    return function(d, b) {
        extendStatics(d, b);

        function __() {
            this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Consts = (function() {
    function Consts() {}
    Consts.DELAY_BETWEEN_EVENTS_TOUCH = 200;
    Consts.DELAY_BETWEEN_EVENTS_DESKTOP = 100;
    Consts.timeToHint = 350;
    Consts.GAMETIME_EASY = 10 * 60;
    Consts.GAMETIME_MEDIUM = 12 * 60;
    Consts.GAMETIME_HARD = 15 * 60;
    return Consts;
}());
var WebFontConfig = {
    active: function() {
        console.log("loadgoooglefonts");
        SimpleGame.myGame.time.events.add(200, function() {
            console.log("all fonts loaded");
            SimpleGame.fontsLoadedFlag = true;
        }, this);
    },
    google: {
        families: ["Arimo:700,800"]
    }
};
var mouseIsWithinGame;
var SimpleGame = (function() {
    function SimpleGame() {
        this.mouseMovedWithinGameTicks = 0;
        this.ticks = 0;
        var config = {
            width: 880,
            height: 600,
            renderer: Phaser.CANVAS,
            parent: 'content',
            disableVisibilityChange: true
        };
        this.game = new Phaser.Game(config);
        SimpleGame.myGame = this.game;
        if (SimpleGame.isReleaseVersion) {
            console.log = function() {};
        }
        this.boot = new Phaser.State();
        this.game.state.add("Boot", this.boot, true);
        this.gamestate = new Phaser.State();
        this.gamestate.preload = this.preload;
        this.gamestate.create = this.create;
        this.gamestate.update = this.update;
        this.game.state.add("Gamestate", this.gamestate, false);
        var resizeF = function() {
            SimpleGame.myGame.scale.scaleMode = Phaser.ScaleManager.RESIZE;
        };
        this.boot.preload = function() {
            console.log("boot preload");
            this.game.stage.backgroundColor = 0x000000;
            this.game.add.text(0, 0, "Arial", {
                font: "1px peace_sans",
                fill: "#FFFFFF"
            });
            SimpleGame.myGame.stage.disableVisibilityChange = true;
            window.addEventListener("resize", resizeF);
            SimpleGame.myGame.stage.disableVisibilityChange = true;
            resizeF();
            this.game.time.advancedTiming = true;
            this.game.scale.refresh();
            console.log("height: " + window.innerHeight + ", " + window.innerWidth + ", " + this.game.height + "," + this.game.scale.sourceAspectRatio);
        };
        this.boot.create = function() {
            this.game.state.start("Gamestate");
            var deviceWidth = window.outerWidth;
            var deviceHeight = window.outerHeight;
            console.log("device w,h: " + deviceWidth, deviceHeight);
            if (SimpleGame.logo) {
                console.log("change logo dim: " + SimpleGame.logo.width, deviceWidth);
                SimpleGame.logo.setScaleMinMax(1, 1, 10, 10);
                SimpleGame.logo.width = deviceWidth;
                console.log("changed logo dim: " + SimpleGame.logo.width, deviceWidth);
                resizeF();
            }
        };
        console.log("boot preloaded", Phaser.VERSION);
    }
    SimpleGame.prototype.preload = function() {
        console.log("start game preloading");
        this.game.load.script('webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js');
        var deviceWidth = window.outerWidth;
        var deviceHeight = window.outerHeight;
        console.log("device w,h: " + deviceWidth, deviceHeight);
        if (SimpleGame.logo) {
            console.log("change logo dim: " + SimpleGame.logo.width, deviceWidth);
            SimpleGame.logo.setScaleMinMax(1, 1, 10, 10);
            SimpleGame.logo.width = deviceWidth;
            console.log("changed logo dim: " + SimpleGame.logo.width, deviceWidth);
        }
        SimpleGame.myGame.stage.backgroundColor = 0x000000;
        this.game.load.image('game_bg', "assets/game_bg.jpg");
        this.game.load.image('button_newgame', 'assets/PROMPTS/button_newgame.png');
        this.game.load.image('button_newgame_over', 'assets/PROMPTS/button_newgame_over.png');
        this.game.load.image('prompt_difficulty', 'assets/PROMPTS/new_game_bg.png');
        this.game.load.image('button_new_game', 'assets/BUTTONS/button_new.png');
        this.game.load.image('button_new_game_over', 'assets/BUTTONS/button_new_over.png');
        this.game.load.image('button_restart', 'assets/BUTTONS/button_restart.png');
        this.game.load.image('button_restart_over', 'assets/BUTTONS/button_restart_over.png');
        this.game.load.image('button_stats', 'assets/BUTTONS/button_stats.png');
        this.game.load.image('button_stats_over', 'assets/BUTTONS/button_stats_over.png');
        this.game.load.image('button_undo', 'assets/BUTTONS/button_undo.png');
        this.game.load.image('button_undo', 'assets/BUTTONS/button_undo.png');
        this.game.load.image('button_hint', 'assets/BUTTONS/button_hint.png');
        this.game.load.image('button_hint_over', 'assets/BUTTONS/button_hint_over.png');
        this.game.load.image('button_music', 'assets/BUTTONS/button_music.png');
        this.game.load.image('button_music_off', 'assets/BUTTONS/button_music_off.png');
        this.game.load.image('button_music_over', 'assets/BUTTONS/button_music_over.png');
        this.game.load.image('button_music_off_over', 'assets/BUTTONS/button_music_off_over.png');
        this.game.load.image('home_bg', 'assets/home_bg.png');
        this.game.load.image('under_cards', 'assets/under_cards.png');
        this.game.load.image('button_undo_over', 'assets/BUTTONS/button_undo_over.png');
        this.game.load.image('button_undo_no_undo', 'assets/BUTTONS/button_undo_no_undo.png');
        this.game.load.image('button_bookmark_over', 'assets/BUTTONS/button_bookmark_over.png');
        this.game.load.image('button_bookmark', 'assets/BUTTONS/button_bookmark.png');
        Spinner.preload();
        console.log("load language.xml");
        this.game.load.xml('language', 'assets/language.xml');
        this.game.load.audio('clearrow', ['assets/SOUNDS/clearrow.mp3', 'assets/SOUNDS/clearrow.ogg']);
        this.game.load.audio('click', ['assets/SOUNDS/click.mp3', 'assets/SOUNDS/click.ogg']);
        this.game.load.audio('grabcard', ['assets/SOUNDS/grabcard.mp3', 'assets/SOUNDS/grabcard.ogg']);
        this.game.load.audio('valid', ['assets/SOUNDS/valid.mp3', 'assets/SOUNDS/valid.ogg']);
        this.game.load.audio('won', ['assets/SOUNDS/won.mp3', 'assets/SOUNDS/won.ogg']);
        this.game.load.audio('hint', ['assets/SOUNDS/hint.mp3', 'assets/SOUNDS/hint.ogg']);
        this.game.load.audio('no-more-hints', ['assets/SOUNDS/no-more-hints.mp3', 'assets/SOUNDS/no-more-hints.ogg']);
        this.game.load.audio('deal1card', ['assets/SOUNDS/dealcards.mp3', 'assets/SOUNDS/dealcards.ogg']);
    };
    SimpleGame.prototype.create = function() {
        console.log("everything preloaded!");
        SoundManager.clearrow = this.game.add.audio('clearrow');
        SoundManager.click = this.game.add.audio('click');
        SoundManager.grabcard = this.game.add.audio('grabcard');
        SoundManager.valid = this.game.add.audio('valid');
        SoundManager.won = this.game.add.audio('won');
        SoundManager.dealcards = this.game.add.audio('deal1card');
        SoundManager.hint = this.game.add.audio('hint');
        SoundManager.noMoreHints = this.game.add.audio('no-more-hints');
        document.getElementById("content").style.opacity = "1";
        SoundManager.init();
        this.game.load.image('button_prompt', 'assets/PROMPTS/button_prompt.png');
        this.game.load.image('button_prompt_over', 'assets/PROMPTS/button_prompt_over.png');
        this.game.load.image('won_bg', 'assets/PROMPTS/won_bg.png');
        this.game.load.image('statics_bg', 'assets/PROMPTS/statics_bg.png');
        Card.preload();
        this.game.load.start();
        this.game.load.onFileComplete.add(function(progress, cacheKey, success, totalLoaded, totalFiles) {
            console.log(progress, success, totalLoaded, totalFiles);
            if (totalLoaded == totalFiles) {
                console.log("all cards preloaded is true");
                SimpleGame.allCardsPreloaded = true;
                if (SimpleGame.spinnerAnim != null)
                    SimpleGame.spinnerAnim.visible = false;
            }
        }, this);
        this.ticks = 0;
        var text = this.game.add.text(870, 32, '', {
            font: "35px Comic Sans MS",
            fill: "#ff0000"
        });
        text.text = "super";
        var key1 = this.game.input.keyboard.addKey(Phaser.Keyboard.CONTROL);
        var key2 = this.game.input.keyboard.addKey(Phaser.Keyboard.Z);
        var key3 = this.game.input.keyboard.addKey(Phaser.Keyboard.H);
        var sBind;
        key3.onDown.add(function() {
            BoardManager.Hint();
        });
        key1.onDown.add(function() {
            sBind = key2.onDown.add(function() {
                BoardManager.Undo();
            }, this);
        }, this);
        key1.onUp.add(function() {
            sBind.detach();
        });
        text.visible = false;
        SimpleGame.game_bg = this.game.add.sprite(0, 0, 'game_bg');
        SimpleGame.game_bg.visible = false;
        console.log("check assets loaded");
        SimpleGame.checkAssetsLoaded();
        SimpleGame.myGame.input.onUp.add(SimpleGame.onPointerUp, this);
        SimpleGame.myGame.input.onDown.add(SimpleGame.onPointerDown, this);
        SimpleGame.myGame.input.mspointer.capture = false;
        document.addEventListener('contextmenu', function(event) {
            return event.preventDefault();
        });
        window.onbeforeunload = function() {
            if (GameUI.initialMoveMade) {
                Util.setStoragePerDifficulty("gamesPlayed", Util.getStoragePerDifficulty("gamesPlayed", 0) + 1);
                var cumulativeScore = Util.getStoragePerDifficulty("cumulativeScore", 0);
                cumulativeScore += GameUI.scoreTotal;
                Util.setStoragePerDifficulty("cumulativeScore", cumulativeScore);
                Util.setStoragePerDifficulty("cumulativeTime", (Util.getStoragePerDifficulty("cumulativeTime", 0) + GameUI.time));
                Util.setStoragePerDifficulty("cumulativeMoves", (Util.getStoragePerDifficulty("cumulativeMoves", 0) + GameUI.moves));
            }
        };
    };
    SimpleGame.handleOrientation = function() {
        SimpleGame.myGame.scale.forceOrientation(true, false);
        SimpleGame.myGame.scale.enterIncorrectOrientation.add(function() {
            SimpleGame.myGame.time.events.add(0.1, function() {
                var deviceWidth = window.innerWidth;
                var deviceHeight = window.innerHeight;
                var isIframed = false;
                if (window.self !== window.top) {
                    isIframed = true;
                }
                if (isIframed)
                    return;
                console.log("add turn image");
                SimpleGame.myGame.input.enabled = false;
                var splash = document.getElementById('splash');
                if (splash) {
                    splash.parentNode.removeChild(splash);
                }
            }, this);
        }, this);
        SimpleGame.myGame.scale.leaveIncorrectOrientation.add(function() {
            var deviceWidth = window.outerWidth;
            var deviceHeight = window.outerHeight;
            SimpleGame.myGame.input.enabled = true;
            if (deviceWidth < deviceHeight) {} else {}
        }, this);
    };
    SimpleGame.onPointerDown = function() {
        SimpleGame.pointerDown = true;
        console.log("input down");
    };
    SimpleGame.onPointerUp = function() {
        SimpleGame.pointerDown = false;
        console.log("input up");
    };
    SimpleGame.checkAssetsLoaded = function() {
        console.log("check assets loaded entered");
        if (SimpleGame.fontsLoadedFlag == false) {
            console.log("call checkAssetsLoaded in 0.05s");
            SimpleGame.myGame.time.events.add(50, function() {
                SimpleGame.checkAssetsLoaded();
            }, this);
        } else {
            console.log("add init screen in 1 second");
            SimpleGame.addInitScreen();
        }
    };
    SimpleGame.addInitScreen = function() {
        document.getElementById("bg").parentNode.removeChild(document.getElementById("bg"));
        SimpleGame.myGame.add.sprite(0, 0, "game_bg");
        document.body.addEventListener('click', function() {
            SoundManager.context = new AudioContext();
            SimpleGame.myGame.sound.context.resume();
        });
        var splash = document.getElementById('splash');
        if (splash) {
            splash.parentNode.removeChild(splash);
        }
        console.log("add init screen");
        Language.initLanguage();
        document.getElementById("content").style.backgroundColor = "#ffffff";
        SimpleGame.myGame.time.events.add(0.1, function() {
            SimpleGame.startGame();
        }, this);
    };
    SimpleGame.startGame = function(firstGame) {
        if (firstGame === void 0) {
            firstGame = true;
        }
        if (firstGame) {
            ResizeManager.update();
            SimpleGame.gameEngineStarted = true;
            SimpleGame.game_bg.visible = true;
            Card.Init();
            GameUI.initialize();
            console.log("easy game");
            GameUI.promptLayer.removeAll(true);
            if (SimpleGame.allCardsPreloaded == false) {}
            var newgame = new NewGamePrompt();
            if (SimpleGame.myGame.device.safari == false && SimpleGame.myGame.device.firefox == false && SimpleGame.myGame.input.touch && (SimpleGame.myGame.device.android || SimpleGame.myGame.device.iOS)) {
                SimpleGame.myGame.input.mouse.stop();
            } else if (SimpleGame.myGame.device.safari == false && SimpleGame.myGame.device.firefox == false && SimpleGame.myGame.device.ie == false && SimpleGame.myGame.input.touch) {
                SimpleGame.myGame.input.mouse.stop();
            }
        } else {
            GameUI.resetMenuButton();
            GameUI.reinitData();
            BoardManager.InitializeBoard();
        }
    };
    SimpleGame.prototype.update = function() {
        if (SoundButton.soundFlagChecked) {
            if (SoundButton.soundFlag) {
                Util.setStorage("soundFlag", 1);
            } else {
                Util.setStorage("soundFlag", 0);
            }
        }
        if (SoundManager.context) {}
        if (GameUI.promptLayer != null) {
            if (GameUI.promptLayer.length > 0) {} else {}
        }
        ResizeManager.update();
        if (this.turnImage) {}
        if (SimpleGame.gameEngineStarted == false)
            return;
        this.ticks++;
        var i = Card.cardArray.length;
        var selectedCardExists = false;
        while (i-- > 0) {
            Card.cardArray[i].update();
            if (Card.cardArray[i].selectedFlag) {
                selectedCardExists = true;
            }
        }
        if (GameUI.promptLayer.countLiving() > 0) {
            if (this.ticks % 120 == 1) {}
        } else {}
        GameUI.update();
        SimpleGame.myGame.input.update();
        BoardManager.update();
        var mouseIsMovedWithinGame;
        if (this.lastMouseCoordX != SimpleGame.myGame.input.x || this.lastMouseCoordY != SimpleGame.myGame.input.y) {
            mouseIsMovedWithinGame = true;
            this.mouseMovedWithinGameTicks++;
        } else {
            mouseIsMovedWithinGame = false;
            this.mouseMovedWithinGameTicks = 0;
        }
        this.lastMouseCoordX = SimpleGame.myGame.input.x;
        this.lastMouseCoordY = SimpleGame.myGame.input.y;
        if (SimpleGame.pointerDown == false && this.mouseMovedWithinGameTicks > 5 && SimpleGame.myGame.input.activePointer.withinGame == false) {} else {}
    };
    SimpleGame.fontsLoadedFlag = false;
    SimpleGame.gameEngineStarted = false;
    SimpleGame.allCardsPreloaded = false;
    SimpleGame.unselectAllCards = false;
    SimpleGame.isReleaseVersion = false;
    SimpleGame.pointerDown = false;
    return SimpleGame;
}());

function onLogoClicked() {}
window.onload = function() {
    var game = new SimpleGame();
};
var GameUI = (function() {
    function GameUI() {}
    GameUI.initialize = function() {
        GameUI.uiLayer = SimpleGame.myGame.add.group();
        GameUI.uiLayerButtons = SimpleGame.myGame.add.group();
        GameUI.promptLayer = SimpleGame.myGame.add.group();
        GameUI.promptHolder = SimpleGame.myGame.add.group(GameUI.promptLayer);
        GameUI.topLayer = SimpleGame.myGame.add.group();
        GameUI.uiAreaBackground = SimpleGame.myGame.make.graphics(0, 0);
        GameUI.uiAreaBackground1 = SimpleGame.myGame.make.graphics(0, 0);
        GameUI.initializeBackgroundBar();
        SimpleGame.spinnerAnim = SimpleGame.myGame.add.sprite(0, 0, "spinner");
        SimpleGame.spinnerAnim.anchor.set(0.75, 0.75);
        SimpleGame.spinnerAnim.scale.set(0.8, 0.8);
        SimpleGame.spinnerAnim.animations.add('play', Phaser.Animation.generateFrameNames('frame-', 0, 28, ''), 10, true, false);
        SimpleGame.spinnerAnim.animations.play('play');
        SimpleGame.spinnerAnim.visible = false;
        console.log("add spinner");
        var i = 8;
        while (i-- > 0) {
            var foundationBottom = SimpleGame.myGame.make.sprite(Math.floor(Card.CARD_FOUND_POS_X_INIT) - Math.floor(Card.CARD_FOUND_POS_X_DELTA) * i, Card.CARD_FOUND_POS_Y_INIT, "home_bg");
            Card.backgroundLayer.add(foundationBottom);
            foundationBottom.anchor.set(0.5, 0.5);
            console.log(foundationBottom.x, Card.CARD_FOUND_POS_X_DELTA);
        }
        var i = 10;
        while (i-- > 0) {
            var foundationBottom = SimpleGame.myGame.make.sprite(Card.CARD_TAB_POS_X_INIT + Card.CARD_TAB_POS_X_DELTA * i, Card.CARD_TAB_POS_Y_INIT, "under_cards");
            Card.backgroundLayer.add(foundationBottom);
            foundationBottom.width = 98;
            foundationBottom.height = 137;
            foundationBottom.anchor.set(0.5, 0.5);
        }
        GameUI.scoreTxt = SimpleGame.myGame.make.text(440, 24, "0500", {
            font: "22px Arimo",
            fill: "#ffd1b9",
            fontWeight: "700",
            align: "Right"
        });
        GameUI.stepsText = SimpleGame.myGame.make.text(440, 24, "0500", {
            font: "22px Arimo",
            fill: "#ffd1b9",
            fontWeight: "700",
            align: "Right"
        });
        GameUI.timeTxt = SimpleGame.myGame.make.text(440, 24, "0500", {
            font: "22px Arimo",
            fill: "#ffd1b9",
            fontWeight: "700",
            align: "Right"
        });
        GameUI.bestScoreTxt = SimpleGame.myGame.make.text(440, 24, "0500", {
            font: "22px Arimo",
            fill: "#ffd1b9",
            fontWeight: "700",
            align: "Right"
        });
        GameUI.gameTitleTxt = SimpleGame.myGame.make.text(440, 24, Language.SPIDER_SOLITAIRE[Language.langIdx], {
            font: "26px Arimo",
            fill: "#f7ad24",
            fontWeight: "700",
            align: "Right"
        });
        GameUI.scoreTxt.anchor.set(0.5, 0.5);
        GameUI.stepsText.anchor.set(0.5, 0.5);
        GameUI.timeTxt.anchor.set(0.5, 0.5);
        GameUI.bestScoreTxt.anchor.set(0.5, 0.5);
        GameUI.gameTitleTxt.anchor.set(0.5, 0.5);
        GameUI.gameTitleTxt.y -= 1;
        GameUI.microsoft = SimpleGame.myGame.make.graphics(0, 0);
        GameUI.microsoft.beginFill(0xffffff);
        GameUI.microsoft.drawRect(SimpleGame.myGame.width * 0.5 - 150, SimpleGame.myGame.height - 40, 300, 40);
        GameUI.microsoft.endFill();
        GameUI.microsoft.alpha = 0.01;
        GameUI.menuButton = SimpleGame.myGame.make.graphics(0, 0);
        GameUI.menuButton.beginFill(0xffffff);
        GameUI.menuButton.drawRect(0, 2, 60, 40);
        GameUI.menuButton.endFill();
        GameUI.menuButton.inputEnabled = false;
        GameUI.menuButton.events.onInputDown.add(GameUI.onMenuButtonPressed, this);
        GameUI.menuButton.events.onInputOver.add(function() {
            SimpleGame.myGame.canvas.style.cursor = "pointer";
            console.log("show pointer");
        }, GameUI.menuButton);
        GameUI.menuButton.events.onInputOut.add(function() {
            SimpleGame.myGame.canvas.style.cursor = "default";
        }, GameUI.menuButton);
        GameUI.menuButton.alpha = 0.01;
        window.addEventListener("click", onWindowClicked);
        GameUI.hintBigBut = SimpleGame.myGame.make.graphics(0, 0);
        GameUI.hintBigBut.beginFill(0xffffff);
        GameUI.hintBigBut.drawRect(340, 490, 200, 120);
        GameUI.hintBigBut.endFill();
        GameUI.hintBigBut.inputEnabled = true;
        GameUI.hintBigBut.events.onInputDown.add(BoardManager.Hint, this);
        GameUI.hintBigBut.alpha = 0.01;
        GameUI.hintBigBut.input.useHandCursor = true;
        var buttondelta = 330;
        var buttoninitx = -610;
        var newgametxt = SimpleGame.myGame.make.text(0, 0, "" + "New".toUpperCase(), {
            font: "22px Arimo",
            fill: "#f4f2f1",
            fontWeight: "700"
        });
        var newgamebut = new ButtonWithOverAndText(newgametxt, GameUI.uiLayerButtons, "button_new_game", "button_new_game_over", buttoninitx, 0, function() {
            console.log("button start new game clicked");
            var areyousure = new AreYouSurePrompt(AreYouSurePrompt.TYPE_NEW_GAME);
            SoundManager.playClick();
        });
        newgamebut.fixedTxtCoords = true;
        newgamebut.fixedTxtX = 102;
        newgamebut.fixedTxtY = 10;
        newgametxt.anchor.set(0.5, 0);
        GameUI.newgamebut = newgamebut;
        var restarttxt = SimpleGame.myGame.make.text(0, 0, "" + "Restart".toUpperCase(), {
            font: "22px Arimo",
            fill: "#f4f2f1",
            fontWeight: "700"
        });
        var restartbut = new ButtonWithOverAndText(restarttxt, GameUI.uiLayerButtons, "button_restart", "button_restart_over", buttoninitx + buttondelta, 0, function() {
            var areyousure = new AreYouSurePrompt(AreYouSurePrompt.TYPE_RESTART_GAME);
            SoundManager.playClick();
        });
        restartbut.fixedTxtCoords = true;
        restartbut.fixedTxtX = 104 + 3;
        restartbut.fixedTxtY = 10;
        restarttxt.anchor.set(0.5, 0);
        GameUI.restartbut = restartbut;
        var stattxt = SimpleGame.myGame.make.text(0, 0, "" + "Stats".toUpperCase(), {
            font: "22px Arimo",
            fill: "#f4f2f1",
            fontWeight: "700"
        });
        var statbut = new ButtonWithOverAndText(stattxt, GameUI.uiLayerButtons, "button_stats", "button_stats_over", buttoninitx + 2 * buttondelta, 0, function() {
            SoundManager.playClick();
            var stats = new StatisticsPrompt();
        });
        statbut.fixedTxtCoords = true;
        statbut.fixedTxtX = 104 + 3;
        statbut.fixedTxtY = 10;
        stattxt.anchor.set(0.5, 0);
        GameUI.statbut = statbut;
        var undotxt = SimpleGame.myGame.make.text(0, 0, "" + "Undo".toUpperCase(), {
            font: "22px Arimo",
            fill: "#f4f2f1",
            fontWeight: "700"
        });
        var undobut = new UndoBut(undotxt, GameUI.uiLayerButtons, "button_undo", "button_undo_over", buttoninitx + 3 * buttondelta, 0, function() {
            BoardManager.Undo();
            SoundManager.playClick();
        });
        undobut.fixedTxtCoords = true;
        undobut.fixedTxtX = 108 + 10;
        undobut.fixedTxtY = 10;
        undotxt.anchor.set(0.5, 0);
        GameUI.undobut = undobut;
        var hinttxt = SimpleGame.myGame.make.text(0, 0, "" + "Hint".toUpperCase(), {
            font: "22px Arimo",
            fill: "#f4f2f1",
            fontWeight: "700"
        });
        var hintbut = new ButtonWithOverAndText(hinttxt, GameUI.uiLayerButtons, "button_hint", "button_hint_over", buttoninitx + 4 * buttondelta, 0, function() {
            BoardManager.Hint();
            SoundManager.playClick();
        });
        hintbut.fixedTxtCoords = true;
        hintbut.fixedTxtX = 108 + 5;
        hintbut.fixedTxtY = 10;
        hinttxt.anchor.set(0.5, 0);
        GameUI.hintbut = hintbut;
        var soundbut = new SoundButton(GameUI.uiLayerButtons, "button_music", "button_music_off", "button_music_over", "button_music_off_over", buttoninitx + 5 * buttondelta, 0);
        GameUI.soundbut = soundbut;
        GameUI.uiLayer.add(GameUI.uiAreaBackground);
        GameUI.uiLayer.add(GameUI.uiAreaBackground1);
        GameUI.uiLayer.add(GameUI.scoreTxt);
        GameUI.uiLayer.add(GameUI.timeTxt);
        GameUI.uiLayer.add(GameUI.stepsText);
        GameUI.uiLayer.add(GameUI.bestScoreTxt);
        GameUI.uiLayer.add(GameUI.gameTitleTxt);
        GameUI.uiLayer.add(GameUI.microsoft);
        SimpleGame.myGame.time.events.loop(1000, GameUI.onSecondTick, this);
        GameUI.reinitData();
        SimpleGame.myGame.time.events.add(7000, function() {}, this);
        GameUI.scoreTxt.text = "Score: " + GameUI.scoreTotal;
        GameUI.stepsText.text = "Moves: " + GameUI.moves;
        GameUI.scoreTxt.x = Math.round(GameUI.scoreTxt.x);
        GameUI.stepsText.x = Math.round(GameUI.stepsText.x);
        GameUI.scoreTxt.y = Math.round(GameUI.scoreTxt.y);
        GameUI.stepsText.y = Math.round(GameUI.stepsText.y);
        this.update();
        this.reinitData();
    };
    GameUI.initializeBackgroundBar = function() {
        console.log("initialize bg bar");
        GameUI.uiAreaBackground.clear();
        GameUI.uiAreaBackground1.clear();
        GameUI.uiAreaBackground.beginFill(0x40240b);
        GameUI.uiAreaBackground.drawRect(-ResizeManager.deviceWidth, 0, 2 * ResizeManager.deviceWidth, 40);
        GameUI.uiAreaBackground.endFill();
        GameUI.uiAreaBackground1.beginFill(0x000000);
        GameUI.uiAreaBackground1.drawRect(-ResizeManager.deviceWidth, 40, 2 * ResizeManager.deviceWidth, 1);
        GameUI.uiAreaBackground1.endFill();
        GameUI.uiAreaBackground.alpha = 0.7;
    };
    GameUI.resetMenuButton = function() {
        GameUI.menuButton.input.reset();
        GameUI.menuButton.inputEnabled = true;
        GameUI.menuButton.events.onInputDown.add(GameUI.onMenuButtonPressed, this);
        GameUI.menuButton.events.onInputOver.add(function() {
            SimpleGame.myGame.canvas.style.cursor = "pointer";
            console.log("show pointer");
        }, GameUI.menuButton);
        GameUI.menuButton.events.onInputOut.add(function() {
            SimpleGame.myGame.canvas.style.cursor = "default";
        }, GameUI.menuButton);
        GameUI.uiLayer.add(GameUI.menuButton);
    };
    GameUI.resetUI = function() {
        GameUI.reinitData();
    };
    GameUI.onSecondTick = function() {
        if (GameUI.gameStarted && GameUI.initialMoveMade && GameUI.promptLayer.children.length <= 0) {
            GameUI.time++;
            var currentTime = GameUI.gameTime - GameUI.time;
            if (currentTime <= 10 && currentTime >= 1) {}
        }
    };
    GameUI.reinitData = function() {
        GameUI.score = 500;
        GameUI.time = 0;
        GameUI.moves = 0;
        GameUI.scoreTotal = GameUI.score;
        GameUI.gameStarted = true;
        GameUI.initialMoveMade = false;
    };
    GameUI.update = function() {
        GameUI.scoreTotal = GameUI.score + 100 * CardUtil.getFreeFoundationIdx();
        var bonus = 750 - GameUI.time;
        if (bonus < 0)
            bonus = 0;
        GameUI.bonus = bonus;
        var currentTime = GameUI.time;
        var bestScore = Util.getStoragePerDifficulty("bestScore1", 0);
        if (bestScore < GameUI.scoreTotal) {
            Util.setStoragePerDifficulty("bestScore1", GameUI.scoreTotal);
        }
        if (ResizeManager.deviceWidth > 1000) {
            GameUI.bestScoreTxt.text = Language.best_score[Language.langIdx] + bestScore;
            GameUI.timeTxt.text = Language.TIME[Language.langIdx] + Util.convertToHHMMSS(currentTime);
            GameUI.scoreTxt.text = Language.SCORE[Language.langIdx] + GameUI.scoreTotal;
            GameUI.stepsText.text = Language.MOVES[Language.langIdx] + GameUI.moves;
        } else {
            GameUI.bestScoreTxt.text = "" + bestScore;
            GameUI.timeTxt.text = "" + Util.convertToHHMMSS(currentTime);
            GameUI.scoreTxt.text = "" + GameUI.scoreTotal;
            GameUI.stepsText.text = "" + GameUI.moves;
        }
        if (BoardManager.undoDisabled) {
            GameUI.undobut.disable();
        } else {
            GameUI.undobut.enable();
        }
    };
    GameUI.onMenuButtonPressed = function() {
        console.log("menu button is pressed");
        if (GameUI.gameStarted == false)
            return;
        var mainmenu = new MainMenu();
        GameUI.menuButton.input.reset();
        SimpleGame.myGame.canvas.style.cursor = "default";
        SoundManager.playClick();
    };
    GameUI.microsoftPressed = false;
    GameUI.gameStarted = false;
    GameUI.initialMoveMade = false;
    return GameUI;
}());

function onWindowClicked() {
    console.log("window clicked");
    if (GameUI.microsoftPressed) {}
    if (SimpleGame.myGame.device.android == true && SimpleGame.myGame.device.desktop == false && SimpleGame.myGame.scale.isFullScreen == false) {
        console.log("start full screen");
        SimpleGame.myGame.scale.startFullScreen(true, false);
        SimpleGame.myGame.scale.fullScreenScaleMode = Phaser.ScaleManager.RESIZE;
    }
    if (SimpleGame.myGame.input.activePointer.isMouse == false)
        SimpleGame.myGame.input.reset();
}

function onmicrosoftDown() {
    GameUI.microsoftPressed = true;
}

function onmicrosoftUp() {
    SimpleGame.myGame.time.events.add(350, function() {
        GameUI.microsoftPressed = false;
    });
}
var GameWonAnim = (function() {
    function GameWonAnim(parent, x, y) {
        this.colornum = 0;
        this.loopEvent1 = SimpleGame.myGame.time.events.loop(10, this.update1, this);
        this.text = SimpleGame.myGame.make.text(x, y, Language.YOUWONGAME[Language.langIdx], {
            font: "61px Arial",
            fill: "#000000",
            fontWeight: "600",
            align: "Right"
        });
        this.text.anchor.set(0.5, 0.5);
        parent.add(this.text);
    }
    GameWonAnim.prototype.update1 = function() {
        var colors = [
            [0, 167, 33],
            [21, 86, 165],
            [143, 29, 165],
            [255, 0, 0],
            [255, 255, 0]
        ];
        var color_speed = 300;
        this.colornum += 2;
        var t = this.colornum % (colors.length * color_speed);
        var next = (Math.ceil(t / color_speed) < colors.length) ? Math.ceil(t / color_speed) : 0;
        var previous = Math.floor(t / color_speed);
        var dr = (colors[next][0] - colors[previous][0]) / color_speed;
        var dg = (colors[next][1] - colors[previous][1]) / color_speed;
        var db = (colors[next][2] - colors[previous][2]) / color_speed;
        var r = Math.floor(colors[previous][0] + dr * (t % color_speed));
        var g = Math.floor(colors[previous][1] + dg * (t % color_speed));
        var b = Math.floor(colors[previous][2] + db * (t % color_speed));
        var color = this.rgb2hex(r, g, b);
        console.log(color);
        this.colornum = this.colornum % 0xffffff;
        this.text.addColor(color, 0);
    };
    GameWonAnim.prototype.rgb2hex = function(red, green, blue) {
        var rgb = blue | (green << 8) | (red << 16);
        return '#' + (0x1000000 + rgb).toString(16).slice(1);
    };
    return GameWonAnim;
}());
var Language = (function() {
    function Language() {}
    Language.initLanguage = function() {
        var url = location.href.toString();
        console.log(url);
        var languageStr = url.split("lang=")[1];
        if (languageStr == null) {
            languageStr = "en";
        }
        languageStr = languageStr.toUpperCase();
        console.log("Language str: " + languageStr);
        var langXml = SimpleGame.myGame.cache.getXML('language');
        console.log(langXml.getElementsByTagName("language"));
        console.log(langXml);
        Language.LanguageAbbrevations = [];
        Language.hint = [];
        Language.HOW_TO_PLAY_FULL = [];
        Language.NEW_GAME = [];
        Language.EASY = [];
        Language.NORMAL = [];
        Language.HARD = [];
        Language.PLAY = [];
        Language.TIME = [];
        Language.SCORE = [];
        Language.MENU = [];
        Language.RESUME = [];
        Language.RESTART = [];
        Language.YES = [];
        Language.NO = [];
        Language.KEEP_PLAYING = [];
        Language.ARE_YOU_SURE_RESTART = [];
        Language.ARE_YOU_SURE_NEW = [];
        Language.ARE_YOU_SURE_SHORT = [];
        Language.THERE_MUST_BE_AT_LEAST = [];
        Language.MORE_GAMES = [];
        Language.SOUND_ON = [];
        Language.SOUND_OFF = [];
        Language.MOVES = [];
        Language.YOUWONGAME = [];
        Language.DONTSHOWAGAIN = [];
        Language.STATISTICS = [];
        Language.SPIDER_SOLITAIRE = [];
        Language.ALLTIMESTATS = [];
        Language.playedgames = [];
        Language.wongames = [];
        Language.lostgames = [];
        Language.win_percentage = [];
        Language.top_score = [];
        Language.best_time = [];
        Language.ok = [];
        Language.with_a_score_of = [];
        Language.minutes_played = [];
        Language.themovesyoumade = [];
        Language.youralltimehigh = [];
        Language.replay = [];
        Language.clear = [];
        Language.level = [];
        Language.select_level = [];
        Language.congrats = [];
        Language.timebonus = [];
        Language.yourscore = [];
        Language.illegalmove = [];
        Language.best_score = [];
        Language.youlostgame = [];
        Language.totalscore = [];
        Language.difficulty = [];
        Language.restart_this_game = [];
        Language.difficulty_short = [];
        Language.undo = [];
        Language.least_moves = [];
        Language.highest_score = [];
        Language.cumulative_score = [];
        Language.average_score = [];
        Language.cumulative_time = [];
        Language.average_time = [];
        Language.least_moves_used = [];
        Language.cumulative_moves = [];
        Language.average_moves = [];
        Language.close = [];
        Language.reset = [];
        Language.are_you_sure_clear_stats = [];
        console.log("Language init done");
        for (var i = 0; i < langXml.getElementsByTagName("language").length; i++) {
            console.log("started for loop");
            Language.LanguageAbbrevations.push(langXml.getElementsByTagName("language")[i].attributes[0].nodeValue);
            Language.NEW_GAME.push(Language.getCorrectTranslation("new_game", langXml.getElementsByTagName("language")[i]));
            Language.hint.push(Language.getCorrectTranslation("hint", langXml.getElementsByTagName("language")[i]));
            Language.undo.push(Language.getCorrectTranslation("undo", langXml.getElementsByTagName("language")[i]));
            Language.EASY.push(Language.getCorrectTranslation("easy", langXml.getElementsByTagName("language")[i]));
            Language.NORMAL.push(Language.getCorrectTranslation("normal", langXml.getElementsByTagName("language")[i]));
            Language.HARD.push(Language.getCorrectTranslation("hard", langXml.getElementsByTagName("language")[i]));
            Language.TIME.push(Language.getCorrectTranslation("time", langXml.getElementsByTagName("language")[i]));
            Language.SCORE.push(Language.getCorrectTranslation("SCORE", langXml.getElementsByTagName("language")[i]));
            Language.NO.push(Language.getCorrectTranslation("no", langXml.getElementsByTagName("language")[i]));
            Language.RESTART.push(Language.getCorrectTranslation("restart", langXml.getElementsByTagName("language")[i]));
            Language.YES.push(Language.getCorrectTranslation("yes", langXml.getElementsByTagName("language")[i]));
            Language.NO.push(Language.getCorrectTranslation("no", langXml.getElementsByTagName("language")[i]));
            Language.ARE_YOU_SURE_RESTART.push(Language.getCorrectTranslation("are_you_sure_restart", langXml.getElementsByTagName("language")[i]));
            Language.ARE_YOU_SURE_NEW.push(Language.getCorrectTranslation("are_you_sure_new", langXml.getElementsByTagName("language")[i]));
            Language.ARE_YOU_SURE_NEW.push(Language.getCorrectTranslation("are_you_sure_new", langXml.getElementsByTagName("language")[i]));
            Language.THERE_MUST_BE_AT_LEAST.push(Language.getCorrectTranslation("there_must_be_at_least", langXml.getElementsByTagName("language")[i]));
            Language.SOUND_ON.push(Language.getCorrectTranslation("sound_on", langXml.getElementsByTagName("language")[i]));
            Language.SOUND_OFF.push(Language.getCorrectTranslation("sound_off", langXml.getElementsByTagName("language")[i]));
            Language.MOVES.push(Language.getCorrectTranslation("MOVES", langXml.getElementsByTagName("language")[i]));
            Language.YOUWONGAME.push(Language.getCorrectTranslation("youwongame", langXml.getElementsByTagName("language")[i]));
            Language.SPIDER_SOLITAIRE.push(Language.getCorrectTranslation("spider", langXml.getElementsByTagName("language")[i]));
            Language.difficulty.push(Language.getCorrectTranslation("difficulty", langXml.getElementsByTagName("language")[i]));
            Language.difficulty_short.push(Language.getCorrectTranslation("difficulty_short", langXml.getElementsByTagName("language")[i]));
            Language.restart_this_game.push(Language.getCorrectTranslation("restart_this_game", langXml.getElementsByTagName("language")[i]));
            Language.ok.push(Language.getCorrectTranslation("ok", langXml.getElementsByTagName("language")[i]));
            Language.minutes_played.push(Language.getCorrectTranslation("minutes_played", langXml.getElementsByTagName("language")[i]));
            Language.themovesyoumade.push(Language.getCorrectTranslation("themovesyoumade", langXml.getElementsByTagName("language")[i]));
            Language.yourscore.push(Language.getCorrectTranslation("yourscore", langXml.getElementsByTagName("language")[i]));
            Language.best_time.push(Language.getCorrectTranslation("best_time", langXml.getElementsByTagName("language")[i]));
            Language.least_moves.push(Language.getCorrectTranslation("least_moves", langXml.getElementsByTagName("language")[i]));
            Language.best_score.push(Language.getCorrectTranslation("best_score", langXml.getElementsByTagName("language")[i]));
            Language.STATISTICS.push(Language.getCorrectTranslation("statistics", langXml.getElementsByTagName("language")[i]));
            Language.playedgames.push(Language.getCorrectTranslation("games_played", langXml.getElementsByTagName("language")[i]));
            Language.wongames.push(Language.getCorrectTranslation("games_won", langXml.getElementsByTagName("language")[i]));
            Language.lostgames.push(Language.getCorrectTranslation("games_lost", langXml.getElementsByTagName("language")[i]));
            Language.highest_score.push(Language.getCorrectTranslation("highest_score", langXml.getElementsByTagName("language")[i]));
            Language.cumulative_score.push(Language.getCorrectTranslation("cumulative_score", langXml.getElementsByTagName("language")[i]));
            Language.average_score.push(Language.getCorrectTranslation("average_score", langXml.getElementsByTagName("language")[i]));
            Language.cumulative_time.push(Language.getCorrectTranslation("cumulative_time", langXml.getElementsByTagName("language")[i]));
            Language.average_time.push(Language.getCorrectTranslation("average_time", langXml.getElementsByTagName("language")[i]));
            Language.least_moves_used.push(Language.getCorrectTranslation("least_moves_used", langXml.getElementsByTagName("language")[i]));
            Language.cumulative_moves.push(Language.getCorrectTranslation("cumulative_moves", langXml.getElementsByTagName("language")[i]));
            Language.average_moves.push(Language.getCorrectTranslation("average_moves", langXml.getElementsByTagName("language")[i]));
            Language.close.push(Language.getCorrectTranslation("close", langXml.getElementsByTagName("language")[i]));
            Language.reset.push(Language.getCorrectTranslation("reset", langXml.getElementsByTagName("language")[i]));
            Language.DONTSHOWAGAIN.push(Language.getCorrectTranslation("DONTSHOWAGAIN", langXml.getElementsByTagName("language")[i]));
            Language.are_you_sure_clear_stats.push(Language.getCorrectTranslation("are_you_sure_clear_stats", langXml.getElementsByTagName("language")[i]));
        }
        Language.langIdx = Language.LanguageAbbrevations.indexOf(languageStr.toLowerCase());
    };
    Language.getCorrectTranslation = function(s, o) {
        console.log("get correct translation: " + s);
        return o.getElementsByTagName(s)[0].textContent;
    };
    Language.LanguageAbbrevations = ["EN", "NL", "FR", "DE", "IT", "PL"];
    Language.PLAY_SHORT = ["Play", "STARTEN", "JOUER", "Spielen", "Jugar", "Jucati"];
    Language.HOW_TO_PLAY_FULL = ["The goal in this Solitaire game is to move all the cards to the four empty stacks in order from ace to king. You can choose to deal 1 card at a time or 3."];
    return Language;
}());
var ResizeManager = (function() {
    function ResizeManager() {}
    ResizeManager.update = function() {
        var deviceWidth = window.innerWidth;
        var deviceHeight = window.innerHeight;
        if (SimpleGame.game_bg) {
            SimpleGame.game_bg.setScaleMinMax(1, 1, 10, 10);
            SimpleGame.game_bg.width = deviceWidth;
        }
        if (SimpleGame.myGame.device.desktop == false) {
            if (SimpleGame.myGame.width <= SimpleGame.myGame.height) {
                deviceWidth = window.screen.width;
                deviceHeight = window.screen.height;
            } else {
                deviceWidth = window.screen.height;
                deviceHeight = window.screen.width;
            }
            deviceWidth = SimpleGame.myGame.width;
            deviceHeight = SimpleGame.myGame.height;
        }
        this.deviceHeight = deviceHeight;
        this.deviceWidth = deviceWidth;
        var cardScaleFromWidth = 1;
        var cardScaleFromHeight = 1;
        if (this.deviceWidth > this.GAME_WIDTH_EXACT) {
            cardScaleFromWidth = 1;
            this.cardAreaBorderX = (this.deviceWidth - this.GAME_WIDTH_EXACT) * 0.5;
        } else {
            cardScaleFromWidth = this.deviceWidth / this.GAME_WIDTH_EXACT;
            this.cardAreaBorderX = 0;
        }
        if (this.deviceHeight > this.GAME_HEIGHT_EXACT) {
            cardScaleFromHeight = 1;
            this.cardAreaBorderY = (this.deviceHeight - this.GAME_HEIGHT_EXACT) * 0.5;
        } else {
            cardScaleFromHeight = this.deviceHeight / this.GAME_HEIGHT_EXACT;
            this.cardAreaBorderY = 0;
        }
        this.cardScaleFromWidthFlag = false;
        if (cardScaleFromWidth < cardScaleFromHeight) {
            this.cardScaleFromWidthFlag = true;
        }
        this.cardscale = Math.min(cardScaleFromWidth, cardScaleFromHeight);
        this.cardscale = cardScaleFromWidth;
        if (cardScaleFromWidth > cardScaleFromHeight) {
            this.cardscale = cardScaleFromWidth * 0.95 - 0.25 * (cardScaleFromWidth - cardScaleFromHeight);
        }
        this.cardScaleFinal = this.cardscale * this.cardscaleExact;
        if (this.deviceWidth > this.GAME_WIDTH_EXACT * this.cardscale) {
            this.cardAreaBorderX = (this.deviceWidth - this.GAME_WIDTH_EXACT * this.cardscale) * 0.5;
        } else {
            this.cardAreaBorderX = 0;
        }
        if (this.deviceHeight > this.GAME_HEIGHT_EXACT * this.cardscale) {
            this.cardAreaBorderY = (this.deviceHeight - this.GAME_HEIGHT_EXACT * this.cardscale) * 0.5;
        } else {
            this.cardAreaBorderY = 0;
        }
        this.manageCardCoordinates();
        this.manageButtonCoordinates();
        this.manageTxtCoordinates();
        this.managePromptCoordinates();
        var cardHeight = this.cardScaleFinal * 135;
        var deviceHeightCardArea = this.deviceHeight * 0.9 - 100;
        var numCards = deviceHeightCardArea / cardHeight;
        this.dynamicCardYDelta = numCards;
        if (GameUI.uiAreaBackground != null) {
            if (deviceWidth * 2 > GameUI.uiAreaBackground.width) {
                GameUI.initializeBackgroundBar();
            }
        }
        this.manageSocialButtons();
    };
    ResizeManager.manageSocialButtons = function() {
        document.getElementById("fblike").style.left = Math.round(this.deviceWidth * 0.5 - 50 - 33).toString() + "px";
        document.getElementById("bookmarkbut").style.left = Math.round(this.deviceWidth * 0.5 + 30 - 33 - 2).toString() + "px";
        document.getElementById("fblike").style.display = "block";
        document.getElementById("bookmarkbut").style.display = "block";
    };
    ResizeManager.managePromptCoordinates = function() {
        if (GameUI.promptLayer != null) {
            GameUI.promptLayer.scale.set(this.cardscale + 0.2 * (1 - this.cardscale));
            GameUI.promptLayer.x = this.deviceWidth / 2;
            GameUI.promptLayer.y = this.deviceHeight / 2;
        }
    };
    ResizeManager.manageCardCoordinates = function() {
        var itemDelta = 0;
        if (this.cardScaleFinal < 0.65) {
            itemDelta = (0.65 - this.cardScaleFinal) * 50;
        }
        if (Card.items != null) {
            Card.items.scale.set(this.cardScaleFinal);
            Card.items.x = this.cardAreaBorderX;
            Card.items.y = 9 + itemDelta;
            Card.backgroundLayer.scale.set(this.cardScaleFinal);
            Card.backgroundLayer.x = this.cardAreaBorderX;
            Card.backgroundLayer.y = 9 + itemDelta;
        }
        if (GameUI.topLayer != null) {
            GameUI.topLayer.scale.set(this.cardScaleFinal);
            GameUI.topLayer.x = this.cardAreaBorderX;
            GameUI.topLayer.y = 9 + itemDelta;
        }
        ResizeManager.manageDeltaMultiplier();
    };
    ResizeManager.manageDeltaMultiplier = function() {
        if (Card.cardArray != null && Card.cardArray.length > 0) {} else {
            return;
        }
        var maxTabPos = -1;
        var maxTabPosCard = null;
        var i = Card.cardArray.length;
        while (i-- > 0) {
            var c = Card.cardArray[i];
            if (c.myState != Card.STATE_TABLEU)
                continue;
            if (c.myState == Card.STATE_DRAGGED || c.selectedFlag)
                continue;
            if (c.tableuPosition > maxTabPos) {
                maxTabPos = c.tableuPosition;
                maxTabPosCard = c;
            }
        }
        if (maxTabPosCard == null)
            return;
        if (0.91 * ResizeManager.deviceHeight < (maxTabPosCard.cardImgFront.height / 2 + maxTabPosCard.cardImgFront.y + Card.items.y) * ResizeManager.cardScaleFinal) {
            console.log("WRONG!!");
            Card.deltaMultiplier *= 1.05;
        } else if (0.85 * ResizeManager.deviceHeight >= (maxTabPosCard.cardImgFront.height / 2 + maxTabPosCard.cardImgFront.y + Card.items.y) * ResizeManager.cardScaleFinal) {
            Card.deltaMultiplier *= 0.95;
        }
        if (Card.deltaMultiplier < 1) {
            Card.deltaMultiplier = 1;
        }
        if (Card.deltaMultiplier > 2) {
            Card.deltaMultiplier = 2;
        }
        console.log("Card delta mult: " + Card.deltaMultiplier);
    };
    ResizeManager.manageButtonCoordinates = function() {
        if (GameUI.uiLayerButtons != null) {
            GameUI.uiLayerButtons.scale.set(this.cardscale);
            GameUI.uiLayerButtons.x = this.deviceWidth / 2;
            GameUI.uiLayerButtons.y = 0.91 * this.deviceHeight;
            if (this.cardScaleFromWidthFlag == false) {}
        }
        var buttondelta = 327;
        var buttoninitx = -684;
        if (this.cardscale < 1) {
            var cardscaledelta = 1 - this.cardscale;
            buttoninitx = -684 + 100 * cardscaledelta;
            buttondelta = 327 - 100 * cardscaledelta;
        }
        buttoninitx += 6;
        if (GameUI.newgamebut != null) {
            if (buttondelta > GameUI.newgamebut.imgNormal.width + 14) {
                var pixelslost = buttondelta - (GameUI.newgamebut.imgNormal.width + 14);
                buttoninitx += pixelslost;
                buttondelta = GameUI.newgamebut.imgNormal.width + 14;
            }
            buttoninitx -= 4;
            GameUI.newgamebut.x = buttoninitx;
            GameUI.restartbut.x = buttoninitx + buttondelta;
            GameUI.statbut.x = buttoninitx + 2 * buttondelta;
            GameUI.undobut.x = buttoninitx + 4.12 * buttondelta;
            GameUI.hintbut.x = buttoninitx + 3 * buttondelta;
            GameUI.soundbut.soundOnBut.setXY(buttoninitx + 5.239 * buttondelta, GameUI.soundbut.soundOnBut.y);
            GameUI.soundbut.soundOffBut.setXY(buttoninitx + 5.239 * buttondelta, GameUI.soundbut.soundOnBut.y);
        }
    };
    ResizeManager.manageTxtCoordinates = function() {
        if (GameUI.uiLayer != null) {
            GameUI.uiLayer.scale.set(1);
            GameUI.uiLayer.x = 0;
            GameUI.uiLayer.y = 0;
        }
        var buttondelta = 290;
        var buttoninitx = -580;
        if (this.cardscale < 1) {
            var cardscaledelta = 1 - this.cardscale;
            buttoninitx = -580 + 100 * cardscaledelta;
            buttondelta = 290 - 100 * cardscaledelta;
        }
        if (GameUI.timeTxt != null) {
            GameUI.timeTxt.x = buttoninitx;
            GameUI.stepsText.x = buttoninitx + buttondelta;
            GameUI.gameTitleTxt.x = buttoninitx + 2 * buttondelta;
            GameUI.scoreTxt.x = buttoninitx + 3 * buttondelta;
            GameUI.bestScoreTxt.x = buttoninitx + 4 * buttondelta;
            GameUI.timeTxt.visible = GameUI.stepsText.visible = GameUI.scoreTxt.visible = GameUI.bestScoreTxt.visible = true;
            if (this.deviceWidth > 1000) {
                GameUI.timeTxt.fontSize = 22;
                GameUI.stepsText.fontSize = 22;
                GameUI.gameTitleTxt.fontSize = 26;
                GameUI.scoreTxt.fontSize = 22;
                GameUI.bestScoreTxt.fontSize = 22;
                GameUI.gameTitleTxt.visible = true;
                document.getElementById("fblike").style.zIndex = "5";
                document.getElementById("bookmarkbut").style.visibility = "visible";
                GameUI.timeTxt.x = 0.1 * this.deviceWidth + GameUI.timeTxt.width * 0.05;
                GameUI.stepsText.x = 0.3 * this.deviceWidth + GameUI.stepsText.width * 0.005;
                GameUI.gameTitleTxt.x = 0.5 * this.deviceWidth + GameUI.gameTitleTxt.width * 0.005;
                GameUI.scoreTxt.x = 0.7 * this.deviceWidth + GameUI.scoreTxt.width * 0.005;
                GameUI.bestScoreTxt.x = 0.9 * this.deviceWidth + GameUI.bestScoreTxt.width * 0.005;
                GameUI.gameTitleTxt.y = 23;
            } else if (this.deviceWidth > 600) {
                GameUI.timeTxt.fontSize = 18;
                GameUI.stepsText.fontSize = 18;
                GameUI.gameTitleTxt.fontSize = 22;
                GameUI.scoreTxt.fontSize = 18;
                GameUI.bestScoreTxt.fontSize = 18;
                GameUI.timeTxt.visible = GameUI.bestScoreTxt.visible = false;
                GameUI.gameTitleTxt.visible = true;
                document.getElementById("fblike").style.zIndex = "-1";
                document.getElementById("bookmarkbut").style.visibility = "hidden";
                GameUI.timeTxt.x = 0.1 * this.deviceWidth - GameUI.timeTxt.width * 0.005;
                GameUI.stepsText.x = 0.1 * this.deviceWidth + GameUI.stepsText.width * 0.005;
                GameUI.gameTitleTxt.x = 0.5 * this.deviceWidth + GameUI.gameTitleTxt.width * 0.005;
                GameUI.scoreTxt.x = 0.9 * this.deviceWidth + GameUI.scoreTxt.width * 0.005;
                GameUI.bestScoreTxt.x = 0.9 * this.deviceWidth + GameUI.bestScoreTxt.width * 0.005;
                GameUI.gameTitleTxt.y = 24;
            } else {
                GameUI.timeTxt.visible = GameUI.bestScoreTxt.visible = false;
                document.getElementById("fblike").style.zIndex = "-1";
                document.getElementById("bookmarkbut").style.visibility = "hidden";
                GameUI.timeTxt.x = 0.1 * this.deviceWidth - GameUI.timeTxt.width * 0.005;
                GameUI.stepsText.x = 0.1 * this.deviceWidth + GameUI.stepsText.width * 0.005;
                GameUI.gameTitleTxt.x = 0.5 * this.deviceWidth + GameUI.gameTitleTxt.width * 0.005;
                GameUI.scoreTxt.x = 0.9 * this.deviceWidth + GameUI.scoreTxt.width * 0.005;
                GameUI.bestScoreTxt.x = 0.9 * this.deviceWidth + GameUI.bestScoreTxt.width * 0.005;
                GameUI.gameTitleTxt.y = 24;
            }
        }
    };
    ResizeManager.getPointerInCardCoordinates = function() {
        var x = (SimpleGame.myGame.input.activePointer.x - this.cardAreaBorderX) / this.cardScaleFinal;
        var y = (SimpleGame.myGame.input.activePointer.y - this.cardAreaBorderY) / this.cardScaleFinal;
        return new Phaser.Point(x, y);
    };
    ResizeManager.cardscale = 1;
    ResizeManager.cardscaleExact = 1;
    ResizeManager.cardScaleFinal = 1;
    ResizeManager.cardAreaBorderX = 0;
    ResizeManager.cardAreaBorderY = 0;
    ResizeManager.GAME_WIDTH_EXACT = 1200;
    ResizeManager.GAME_HEIGHT_EXACT = 940;
    ResizeManager.dynamicCardYDelta = 1;
    ResizeManager.cardScaleFromWidthFlag = false;
    return ResizeManager;
}());
var SoundManager = (function() {
    function SoundManager() {}
    SoundManager.playClick = function() {
        if (SoundManager.canPlayClick) {
            console.log("play CLICK");
            SoundManager.click.play();
            SoundManager.canPlayClick = false;
            SimpleGame.myGame.time.events.add(100, function() {
                SoundManager.canPlayClick = true;
            }, this);
        }
    };
    SoundManager.init = function() {
        SoundManager.sManager = new Phaser.SoundManager(SimpleGame.myGame);
        SoundManager.dealcards.allowMultiple = true;
        SimpleGame.myGame.sound.volume = 0.7;
    };
    SoundManager.playGrabCard = function() {
        if (SoundManager.canPlayGrab && SoundManager.grabcard.mute == false) {
            SoundManager.grabcard.play();
            SoundManager.canPlayGrab = false;
            SimpleGame.myGame.time.events.add(100, function() {
                SoundManager.canPlayGrab = true;
            }, this);
        }
    };
    SoundManager.setMuteFlags = function(muteFlag) {
        SoundManager.clearrow.mute = muteFlag;
        SoundManager.click.mute = muteFlag;
        SoundManager.grabcard.mute = muteFlag;
        SoundManager.valid.mute = muteFlag;
        SoundManager.won.mute = muteFlag;
        SoundManager.dealcards.mute = muteFlag;
        SoundManager.hint.mute = muteFlag;
        SoundManager.noMoreHints.mute = muteFlag;
    };
    SoundManager.playDealRow = function() {
        SoundManager.timesToPlayDealSound = 10;
        SoundManager.playDealRowSound();
    };
    SoundManager.playDealRowSound = function() {
        SoundManager.dealcards.position = 200;
        SoundManager.dealcards.update();
        SoundManager.dealcards.play();
        SoundManager.timesToPlayDealSound--;
        if (SoundManager.timesToPlayDealSound > 0) {
            SimpleGame.myGame.time.events.add(80, function() {
                SoundManager.playDealRowSound();
            });
        }
    };
    SoundManager.timesToPlayDealSound = 10;
    SoundManager.canPlayClick = true;
    SoundManager.canPlayGrab = true;
    return SoundManager;
}());
var Spinner = (function() {
    function Spinner() {}
    Spinner.preload = function() {
        SimpleGame.myGame.load.atlasXML("spinner", "assets/spinner/spinner.png", "assets/spinner/spinner.xml");
    };
    return Spinner;
}());
var Trace = (function() {
    function Trace() {}
    Trace.TraceCardByIdxAndPos = function(tableIdx, tablePos) {
        var i = Card.cardArray.length;
        while (i-- > 0) {
            var c = Card.cardArray[i];
            if (c.tableuIdx == tableIdx && c.tableuPosition == tablePos) {
                var name = CardUtil.cardNameArray[c.suitIdx * CardUtil.NUM_CARDS_PER_SUIT + c.cardIdx];
                console.log(name);
            }
        }
    };
    return Trace;
}());
var OpenMenuBut = (function() {
    function OpenMenuBut() {
        SimpleGame.myGame.add.button();
    }
    return OpenMenuBut;
}());
var SoundButton = (function() {
    function SoundButton(parent, imgNormalName, imgNormalNameOff, imgOverName, imgOverNameOff, x, y) {
        var soundontxt = SimpleGame.myGame.make.text(0, 0, "", {
            font: "16px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        this.soundOnBut = new ButtonWithOverAndText(soundontxt, parent, imgNormalName, imgOverName, x, y, this.toggleSoundButton.bind(this));
        this.soundOnBut.setXY(x, y);
        if (Util.getStorage("soundFlag", 0) == 0) {
            SoundButton.soundFlag = false;
        } else {
            SoundButton.soundFlag = true;
        }
        SoundButton.soundFlagChecked = true;
        var soundofftxt = SimpleGame.myGame.make.text(0, 0, "", {
            font: "16px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        this.soundOffBut = new ButtonWithOverAndText(soundofftxt, parent, imgNormalNameOff, imgOverNameOff, x, y, this.toggleSoundButton.bind(this));
        this.soundOffBut.setXY(x, y);
        this.setCorrectButtonVisible(true);
        SoundManager.setMuteFlags(!SoundButton.soundFlag);
        SoundManager.setMuteFlags(!SoundButton.soundFlag);
    }
    SoundButton.prototype.toggleSoundButton = function() {
        SoundButton.soundFlag = !SoundButton.soundFlag;
        console.log("sound flag: " + SoundButton.soundFlag);
        this.setCorrectButtonVisible();
        SoundManager.setMuteFlags(!SoundButton.soundFlag);
        console.log("mute flag: " + SoundManager.sManager.mute);
    };
    SoundButton.prototype.setCorrectButtonVisible = function(skipButtonOver) {
        if (skipButtonOver === void 0) {
            skipButtonOver = false;
        }
        if (SoundButton.soundFlag) {
            this.soundOnBut.setVisible();
            this.soundOffBut.setInvisible();
            if (!skipButtonOver)
                this.soundOnBut.onButtonOver();
        } else {
            this.soundOnBut.setInvisible();
            this.soundOffBut.setVisible();
            if (!skipButtonOver)
                this.soundOffBut.onButtonOver();
        }
    };
    SoundButton.manageTextualSoundButtons = function(sOnBut, sOffBut) {
        if (this.soundFlag) {
            console.log("sound is on!!!");
            sOffBut.goInvisible();
            sOnBut.goVisible();
        } else {
            sOnBut.goInvisible();
            sOffBut.goVisible();
        }
    };
    SoundButton.soundFlag = false;
    SoundButton.soundFlagChecked = false;
    return SoundButton;
}());
var BoardData = (function() {
    function BoardData() {
        this.currentScore = 0;
        this.stockPile = new Array();
        this.foundationPile = new Array();
        this.foundationPile[0] = new Array();
        this.foundationPile[1] = new Array();
        this.foundationPile[2] = new Array();
        this.foundationPile[3] = new Array();
        this.foundationPile[4] = new Array();
        this.foundationPile[5] = new Array();
        this.foundationPile[6] = new Array();
        this.foundationPile[7] = new Array();
        this.tableuPile = new Array();
        this.tableuPile[0] = new Array();
        this.tableuPile[1] = new Array();
        this.tableuPile[2] = new Array();
        this.tableuPile[3] = new Array();
        this.tableuPile[4] = new Array();
        this.tableuPile[5] = new Array();
        this.tableuPile[6] = new Array();
        this.tableuPile[7] = new Array();
        this.tableuPile[8] = new Array();
        this.tableuPile[9] = new Array();
    }
    BoardData.prototype.addToBdata = function(card) {
        var cardData = new CardData(card.suitIdx, card.cardIdx, card.turned, card.deckIdx);
        var stockCards = 0;
        var tabCards = 0;
        if (card.myState == Card.STATE_STOCK) {
            this.stockPile[card.myStockIdx] = cardData;
        } else if (card.myState == Card.STATE_TABLEU) {
            this.tableuPile[card.tableuIdx][card.tableuPosition] = cardData;
        } else if (card.myState == Card.STATE_FOUNDATION) {
            this.foundationPile[card.foundationIdx][card.foundationPosition] = cardData;
        }
    };
    BoardData.prototype.fromSnapshotToBoard = function(skiplayerfixes) {
        this.justUndoedArray = new Array();
        this.manageStockpile();
        this.manageTableu();
        this.manageFoundation();
        if (!skiplayerfixes) {
            this.fixPostUndoLayering();
        }
    };
    BoardData.prototype.manageFoundation = function() {
        var i = this.foundationPile.length;
        while (i-- > 0) {
            var arr = this.foundationPile[i];
            var j = arr.length;
            while (j-- > 0) {
                var cData = this.foundationPile[i][j];
                if (cData == undefined)
                    continue;
                var card = CardUtil.getByCardAndSuitIdx(cData.suitIdx, cData.cardIdx, cData.deckIdx);
                if (card.myState == Card.STATE_FOUNDATION && card.foundationIdx == i && card.foundationPosition == j && card.turned == cData.turned) {} else {
                    this.justUndoedArray.push(card);
                }
                card.myState = Card.STATE_FOUNDATION;
                card.foundationIdx = i;
                card.foundationPosition = j;
                card.turned = cData.turned;
                card.isMoving = false;
                card.selectedFlag = false;
            }
        }
    };
    BoardData.prototype.manageStockpile = function() {
        var i = this.stockPile.length;
        while (i-- > 0) {
            var cdata = this.stockPile[i];
            if (cdata == null)
                continue;
            var card = CardUtil.getByCardAndSuitIdx(cdata.suitIdx, cdata.cardIdx, cdata.deckIdx);
            if (card.myState == Card.STATE_STOCK && card.myStockIdx == i && card.turned == cdata.turned) {} else {
                this.justUndoedArray.push(card);
            }
            card.myState = Card.STATE_STOCK;
            card.myStockIdx = i;
            card.turned = cdata.turned;
            card.isMoving = false;
            card.selectedFlag = false;
        }
    };
    BoardData.prototype.manageTableu = function() {
        var i = this.tableuPile.length;
        while (i-- > 0) {
            var arr = this.tableuPile[i];
            var j = arr.length;
            while (j-- > 0) {
                var cData = this.tableuPile[i][j];
                var card = CardUtil.getByCardAndSuitIdx(cData.suitIdx, cData.cardIdx, cData.deckIdx);
                if (card.myState == Card.STATE_TABLEU && card.tableuIdx == i && card.tableuPosition == j && card.turned == cData.turned) {} else {
                    this.justUndoedArray.push(card);
                }
                if (card.tableuIdx != i || card.tableuPosition != j) {} else {}
                card.myState = Card.STATE_TABLEU;
                card.tableuIdx = i;
                card.tableuPosition = j;
                card.turned = cData.turned;
                card.isMoving = false;
                card.selectedFlag = false;
            }
        }
    };
    BoardData.prototype.fixPostUndoLayering = function() {
        this.justUndoedArray.sort(function(x, y) {
            if (x.foundationPosition > y.foundationPosition) {
                return 1;
            } else if (x.foundationPosition == y.foundationPosition) {
                return 0;
            } else {
                return -1;
            }
        });
        var i = this.justUndoedArray.length;
        while (i-- > 0) {}
    };
    BoardData.isBdataChanged = function(data1, data2) {
        if (this.isArrayIdentical(data1.foundationPile[0], data2.foundationPile[0]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[1], data2.foundationPile[1]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[2], data2.foundationPile[2]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[3], data2.foundationPile[3]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[4], data2.foundationPile[4]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[5], data2.foundationPile[5]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[6], data2.foundationPile[6]) == false)
            return true;
        if (this.isArrayIdentical(data1.foundationPile[7], data2.foundationPile[7]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[0], data2.tableuPile[0]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[1], data2.tableuPile[1]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[2], data2.tableuPile[2]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[3], data2.tableuPile[3]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[4], data2.tableuPile[4]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[5], data2.tableuPile[5]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[6], data2.tableuPile[6]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[7], data2.tableuPile[7]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[8], data2.tableuPile[8]) == false)
            return true;
        if (this.isArrayIdentical(data1.tableuPile[9], data2.tableuPile[9]) == false)
            return true;
        if (this.isArrayIdentical(data1.stockPile, data2.stockPile) == false) {
            return true;
        }
        return false;
    };
    BoardData.isFreeCellArrayIdentical = function(arr1, arr2) {
        if (arr1.length != arr2.length)
            return false;
        var retVal = true;
        var i = arr1.length;
        while (i-- > 0) {
            if (arr1[i] == null || arr2[i] == null)
                return false;
            if (arr1[i].cardIdx != arr2[i].cardIdx || arr1[i].suitIdx != arr2[i].suitIdx || arr1[i].turned != arr2[i].turned) {
                return false;
            }
        }
        return true;
    };
    BoardData.isArrayIdentical = function(arr1, arr2) {
        if (arr1.length != arr2.length)
            return false;
        var retVal = true;
        var i = arr1.length;
        while (i-- > 0) {
            if (arr1[i] == null || arr2[i] == null)
                return false;
            if (arr1[i].deckIdx != arr2[i].deckIdx || arr1[i].cardIdx != arr2[i].cardIdx || arr1[i].suitIdx != arr2[i].suitIdx || arr1[i].turned != arr2[i].turned) {
                return false;
            }
        }
        return true;
    };
    BoardData.boardDataIdx = -1;
    return BoardData;
}());
var CardData = (function() {
    function CardData(suitIdx, cardIdx, turned, deckIdx) {
        this.turned = turned;
        this.cardIdx = cardIdx;
        this.suitIdx = suitIdx;
        this.deckIdx = deckIdx;
    }
    return CardData;
}());
var BoardManager = (function() {
    function BoardManager() {}
    BoardManager.HintReset = function() {
        BoardManager.hintState = 0;
        BoardManager.currentObservedColumn = -1;
    };
    BoardManager.Hint = function() {
        if (BoardManager.currentObservedColumn == -1) {
            BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        }
        var isInitialHint = false;
        if (BoardManager.hintState == 0 && BoardManager.currentObservedColumn == BoardManager.NUM_TABLEU_COLUMNS) {
            isInitialHint = true;
        }
        BoardManager.hintSuccess = false;
        BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        isInitialHint = true;
        var respectSuitIdx = true;
        console.log("is initial: " + isInitialHint);
        console.log("current observed column: ", BoardManager.currentObservedColumn);
        if (BoardManager.hintState == BoardManager.HINT_STATE_TRY_FIRST_CARD_ONLY_HINT) {
            console.log("try first state only, respect suit");
            var i = BoardManager.currentObservedColumn;
            BoardManager.hintSuccess = false;
            while (i-- > 0) {
                BoardManager.TryToHintColumn(i, true, true);
                BoardManager.currentObservedColumn = i;
                if (BoardManager.hintSuccess) {
                    SoundManager.hint.play();
                    console.log("hint successwith first card only, i: " + BoardManager.currentObservedColumn);
                    return;
                }
            }
            BoardManager.hintState++;
            BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        }
        if (BoardManager.hintState == BoardManager.HINT_STATE_TRY_ANY_CARD_HINT) {
            console.log("try second state, respect suit");
            var i = BoardManager.currentObservedColumn;
            BoardManager.hintSuccess = false;
            while (i-- > 0) {
                BoardManager.TryToHintColumn(i, false, true);
                BoardManager.currentObservedColumn = i;
                if (BoardManager.hintSuccess) {
                    SoundManager.hint.play();
                    return;
                }
            }
            BoardManager.hintState++;
            BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        }
        if (BoardManager.hintState == BoardManager.HINT_STATE_FIRST_CARD_ONLY_NORESPECT) {
            console.log("try first state only, no respect");
            var i = BoardManager.currentObservedColumn;
            BoardManager.hintSuccess = false;
            while (i-- > 0) {
                BoardManager.TryToHintColumn(i, true);
                BoardManager.currentObservedColumn = i;
                if (BoardManager.hintSuccess) {
                    SoundManager.hint.play();
                    console.log("hint successwith first card only, i: " + BoardManager.currentObservedColumn);
                    return;
                }
            }
            BoardManager.hintState++;
            BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        }
        if (BoardManager.hintState == BoardManager.HINT_STATE_ANY_CARD_ONLY_NORESPECT) {
            console.log("try second state, no respect");
            var i = BoardManager.currentObservedColumn;
            BoardManager.hintSuccess = false;
            while (i-- > 0) {
                BoardManager.TryToHintColumn(i, false);
                BoardManager.currentObservedColumn = i;
                if (BoardManager.hintSuccess) {
                    SoundManager.hint.play();
                    return;
                }
            }
            BoardManager.hintState++;
            BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        }
        if (BoardManager.hintState == BoardManager.HINT_STATE_TRY_EMPTY_COLUMN) {
            console.log("try empty column state, currently observed: ", BoardManager.currentObservedColumn);
            var i = BoardManager.currentObservedColumn;
            BoardManager.hintSuccess = false;
            while (i-- > 0) {
                BoardManager.TryToHintToEmptyColumn(i);
                BoardManager.currentObservedColumn = i;
                if (BoardManager.hintSuccess) {
                    SoundManager.hint.play();
                    return;
                }
            }
            BoardManager.hintState = 0;
            BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
        }
        if (BoardManager.hintSuccess) {
            SoundManager.hint.play();
        } else {
            if (isInitialHint) {
                SoundManager.noMoreHints.play();
            } else {
                console.log("try with initial hint");
                BoardManager.hintState = 0;
                BoardManager.currentObservedColumn = BoardManager.NUM_TABLEU_COLUMNS;
                BoardManager.Hint();
            }
        }
    };
    BoardManager.TryToHintToEmptyColumnBackup = function(tabIdx) {
        var i = BoardManager.NUM_TABLEU_COLUMNS;
        var emptyExists = false;
        var emptyIdx = -1;
        while (i-- > 0) {
            var idx = 9 - i;
            if (CardUtil.checkIfTabEmpty(idx)) {
                emptyIdx = idx;
                emptyExists = true;
                break;
            }
        }
        if (!emptyExists)
            return;
        var cardOnTopOfInitialColumn = CardUtil.getCardOnTop(tabIdx);
        if (cardOnTopOfInitialColumn == null)
            return;
        cardOnTopOfInitialColumn.invertFrontColors();
        BoardManager.hintSuccess = true;
        var hintMarker = SimpleGame.myGame.make.graphics(0, 0);
        hintMarker.beginFill(0x000000);
        console.log("add hint marker");
        hintMarker.drawRoundedRect(Card.CARD_TAB_POS_X_INIT + emptyIdx * Card.CARD_TAB_POS_X_DELTA - 81 / 2, Card.CARD_TAB_POS_Y_INIT - 113 / 2, 81, 113, 4);
        hintMarker.alpha = 0.75;
        hintMarker.endFill();
        SimpleGame.myGame.time.events.add(Consts.timeToHint, function() {
            Card.items.add(hintMarker);
        }, this);
        SimpleGame.myGame.time.events.add(1000, function() {
            Card.items.remove(hintMarker, true);
        }, this);
    };
    BoardManager.TryToHintToEmptyColumn = function(tabIdx) {
        console.log("try to hint empty: ", tabIdx);
        var i = BoardManager.NUM_TABLEU_COLUMNS;
        var emptyExists = false;
        var emptyIdx = -1;
        while (i-- > 0) {
            var idx = 9 - i;
            console.log("check if tab empty: " + idx);
            if (CardUtil.checkIfTabEmpty(idx)) {
                emptyIdx = idx;
                emptyExists = true;
                break;
            }
        }
        console.log("empty doesn't exist");
        if (!emptyExists)
            return;
        var cardOnBotOfInitialColumn = CardUtil.getByTabIdxAndPos(tabIdx, 0);
        if (cardOnBotOfInitialColumn == null)
            return;
        if (CardUtil.isValidMoveStack(cardOnBotOfInitialColumn)) {
            return;
        }
        var c2 = null;
        var deltaPos = 0;
        do {
            deltaPos++;
            c2 = CardUtil.getByTabIdxAndPos(tabIdx, deltaPos);
            if (CardUtil.isValidMoveStack(c2)) {
                break;
            }
        } while (c2 != null);
        if (c2 == null)
            return;
        console.log("got to hint marker part");
        c2.invertFrontColors();
        BoardManager.hintSuccess = true;
        var hintMarker = SimpleGame.myGame.make.graphics(0, 0);
        hintMarker.beginFill(0x000000);
        hintMarker.drawRoundedRect(Card.CARD_TAB_POS_X_INIT + emptyIdx * Card.CARD_TAB_POS_X_DELTA - 100 / 2, Card.CARD_TAB_POS_Y_INIT - 139 / 2, 100, 139, 4);
        hintMarker.alpha = 0.75;
        console.log("add hint marker");
        hintMarker.endFill();
        SimpleGame.myGame.time.events.add(Consts.timeToHint, function() {
            Card.items.add(hintMarker);
        }, this);
        SimpleGame.myGame.time.events.add(2 * Consts.timeToHint, function() {
            Card.items.remove(hintMarker, true);
        }, this);
    };
    BoardManager.TryToHintToEmptyColumnOld = function(tabIdx) {
        var i = BoardManager.NUM_TABLEU_COLUMNS;
        var emptyExists = false;
        var emptyIdx = -1;
        while (i-- > 0) {
            var idx = 9 - i;
            console.log("check if tab empty: " + idx);
            if (CardUtil.checkIfTabEmpty(idx)) {
                emptyIdx = idx;
                emptyExists = true;
                break;
            }
        }
        console.log("return");
        if (!emptyExists)
            return;
        var cardOnTopOfInitialColumn = CardUtil.getCardOnTop(tabIdx);
        if (cardOnTopOfInitialColumn == null)
            return;
        var cardOnTopOfInitialMinusOne = CardUtil.getByTabIdxAndPos(tabIdx, cardOnTopOfInitialColumn.tableuPosition - 1);
        if (cardOnTopOfInitialMinusOne == null)
            return;
        if (cardOnTopOfInitialMinusOne.turned == true) {
            if (CardUtil.isCardIdxFollowing(cardOnTopOfInitialMinusOne, cardOnTopOfInitialColumn))
                return;
        }
        cardOnTopOfInitialColumn.invertFrontColors();
        BoardManager.hintSuccess = true;
        var hintMarker = SimpleGame.myGame.make.graphics(0, 0);
        hintMarker.beginFill(0x000000);
        console.log("add hint marker");
        hintMarker.drawRoundedRect(Card.CARD_TAB_POS_X_INIT + emptyIdx * Card.CARD_TAB_POS_X_DELTA - 81 / 2, Card.CARD_TAB_POS_Y_INIT - 113 / 2, 81, 113, 4);
        hintMarker.alpha = 0.75;
        hintMarker.endFill();
        SimpleGame.myGame.time.events.add(Consts.timeToHint, function() {
            Card.items.add(hintMarker);
        }, this);
        SimpleGame.myGame.time.events.add(2 * Consts.timeToHint, function() {
            Card.items.remove(hintMarker, true);
        }, this);
    };
    BoardManager.TryToHintColumn = function(tabIdx, firstCardOnly, respectSuit) {
        if (respectSuit === void 0) {
            respectSuit = false;
        }
        var initPos = CardUtil.getFirstTurnedCardIdx(tabIdx);
        do {
            var cardPlaced = CardUtil.getByTabIdxAndPos(tabIdx, initPos);
            if (cardPlaced == null) {
                return;
            }
            if (CardUtil.isValidMoveStack(cardPlaced)) {
                var cardPlacedMinusOne = CardUtil.getByTabIdxAndPos(tabIdx, initPos - 1);
                var j = BoardManager.NUM_TABLEU_COLUMNS;
                var tabIdxCurrent = cardPlaced.tableuIdx;
                while (j-- > 0) {
                    tabIdxCurrent++;
                    if (tabIdxCurrent % BoardManager.NUM_TABLEU_COLUMNS == tabIdx)
                        continue;
                    var cardTableu = CardUtil.getCardOnTop(tabIdxCurrent % BoardManager.NUM_TABLEU_COLUMNS);
                    if (cardTableu == null) {
                        continue;
                    }
                    if (respectSuit) {
                        if (cardTableu.suitIdx != cardPlaced.suitIdx) {
                            continue;
                        }
                    }
                    if (cardTableu.cardIdx != CardUtil.CARD_IDX_A && (cardPlaced.cardIdx == CardUtil.CARD_IDX_A && cardTableu.cardIdx == CardUtil.CARD_IDX_02 || cardPlaced.cardIdx + 1 == cardTableu.cardIdx)) {
                        if (cardPlacedMinusOne != null) {
                            if (cardPlacedMinusOne.turned && cardPlacedMinusOne.cardIdx == cardTableu.cardIdx) {
                                if (cardTableu.suitIdx == cardPlaced.suitIdx && BoardManager.resultsInFullstack(cardTableu) && BoardManager.resultsInFullstackDownwards(cardPlaced)) {
                                    BoardManager.hintSuccess = true;
                                    break;
                                } else {
                                    continue;
                                }
                            } else {
                                BoardManager.hintSuccess = true;
                                break;
                            }
                        } else {
                            BoardManager.hintSuccess = true;
                            break;
                        }
                    }
                }
            }
            if (BoardManager.hintSuccess) {
                cardPlaced.invertFrontColors();
                SimpleGame.myGame.time.events.add(Consts.timeToHint, function() {
                    cardTableu.invertFrontColors();
                }, this);
                return;
            }
            if (firstCardOnly) {
                return;
            } else {
                initPos++;
            }
        } while (cardPlaced != null);
    };
    BoardManager.resultsInFullstackDownwards = function(cardObserved) {
        Trace.TraceCardByIdxAndPos(cardObserved.tableuIdx, cardObserved.tableuPosition);
        if (cardObserved.cardIdx == CardUtil.CARD_IDX_A) {
            return true;
        }
        var cminusone = CardUtil.getByTabIdxAndPos(cardObserved.tableuIdx, cardObserved.tableuPosition + 1);
        if (cminusone == null) {
            return false;
        }
        if (CardUtil.isCardIdxFollowing(cardObserved, cminusone, true) == false) {
            return false;
        }
        return BoardManager.resultsInFullstackDownwards(cminusone);
    };
    BoardManager.resultsInFullstack = function(cardObserved) {
        if (cardObserved.cardIdx == CardUtil.CARD_IDX_K) {
            return true;
        }
        var cminusone = CardUtil.getByTabIdxAndPos(cardObserved.tableuIdx, cardObserved.tableuPosition - 1);
        if (cminusone == null) {
            return false;
        }
        if (CardUtil.isCardIdxFollowing(cminusone, cardObserved, true) == false) {
            return false;
        }
        return BoardManager.resultsInFullstack(cminusone);
    };
    BoardManager.InitializeBoard = function() {
        if (SimpleGame.myGame.load.hasLoaded == false) {
            SimpleGame.spinnerAnim.visible = true;
            var group = SimpleGame.myGame.add.group();
            SimpleGame.spinnerAnim.x = SimpleGame.myGame.width * 0.5;
            SimpleGame.spinnerAnim.y = SimpleGame.myGame.height * 0.5;
            SimpleGame.myGame.time.events.add(50, function() {
                BoardManager.InitializeBoard();
            }, this);
            return;
        }
        SimpleGame.spinnerAnim.visible = false;
        console.log("initialize board called");
        BoardManager.removeAllCards();
        BoardData.boardDataArray = new Array();
        console.log("generate cards");
        BoardManager.GenerateCards();
        console.log("generate stock");
        BoardManager.GenerateStock();
        console.log("generate tableu");
        BoardManager.GenerateTableu();
        console.log("generate snapshot");
        BoardManager.actuallyGenerateSnapshot();
        console.log("sort");
        BoardManager.sortImmediately();
        console.log("tween initial");
        BoardManager.initialTween();
        if (GameUI.initialMoveMade) {
            var cumulativeScore = Util.getStoragePerDifficulty("cumulativeScore", 0);
            cumulativeScore += GameUI.scoreTotal;
            Util.setStoragePerDifficulty("cumulativeScore", cumulativeScore);
            Util.setStoragePerDifficulty("cumulativeTime", (Util.getStoragePerDifficulty("cumulativeTime", 0) + GameUI.time));
            Util.setStoragePerDifficulty("cumulativeMoves", (Util.getStoragePerDifficulty("cumulativeMoves", 0) + GameUI.moves));
        }
        GameUI.reinitData();
        console.log("total cards: " + Card.cardArray.length);
    };
    BoardManager.initialTween = function() {
        console.log("initial tween called");
        SimpleGame.myGame.time.events.add(Phaser.Timer.SECOND * 0.25, SoundManager.playDealRow);
        var arr = Card.cardArray;
        var i = arr.length;
        var initTweenIdx = 0;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_TABLEU && c.turned) {
                c.initTween(initTweenIdx++);
            }
        }
    };
    BoardManager.removeAllCards = function() {
        var cArr = Card.cardArray;
        var i = cArr.length;
        while (i-- > 0) {
            var c = Card.cardArray[i];
            c.markForKill = true;
            c.remove();
        }
        while (Card.cardArray.pop());
        Card.cardArray = new Array();
        console.log("cardarr len: " + Card.cardArray.length);
    };
    BoardManager.increaseGameCount = function() {
        var gamesPlayed = Util.getStoragePerDifficulty("gamesPlayed");
        gamesPlayed++;
        Util.setStoragePerDifficulty("gamesPlayed", gamesPlayed);
    };
    BoardManager.resetBoard = function() {
        if (GameUI.initialMoveMade) {
            var cumulativeScore = Util.getStoragePerDifficulty("cumulativeScore", 0);
            cumulativeScore += GameUI.scoreTotal;
            Util.setStoragePerDifficulty("cumulativeScore", cumulativeScore);
            Util.setStoragePerDifficulty("cumulativeTime", (Util.getStoragePerDifficulty("cumulativeTime", 0) + GameUI.time));
            Util.setStoragePerDifficulty("cumulativeMoves", (Util.getStoragePerDifficulty("cumulativeMoves", 0) + GameUI.moves));
        }
        GameUI.resetUI();
        BoardManager.fromSnapshotToBoard(BoardData.boardDataArray[0]);
        BoardData.boardDataArray = new Array();
        BoardManager.actuallyGenerateSnapshot();
    };
    BoardManager.update = function() {
        BoardManager.sort();
        if (BoardManager.checkForGameOver() && GameUI.gameStarted) {
            var gamewon = new GameWonPrompt2();
        }
        if (BoardData.boardDataArray) {}
    };
    BoardManager.checkForGameOver = function() {
        var arr = Card.cardArray;
        var i = arr.length;
        if (arr.length <= 0)
            return false;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState != Card.STATE_FOUNDATION) {
                return false;
            }
        }
        return true;
    };
    BoardManager.sort = function() {
        SimpleGame.myGame.time.events.add(50, function() {
            BoardManager.sortImmediately();
        });
    };
    BoardManager.sortImmediately = function() {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.selectedFlag || c.myState == Card.STATE_DRAGGED) {
                c.cardImgFront.z = 3000 + c.tableuPosition;
            } else if (c.isMoving) {
                c.cardImgFront.z = 2000 + c.tableuPosition;
                var j = 50;
                while (j-- > 1) {
                    var c1 = CardUtil.getByTabIdxAndPos(c.tableuIdx, c.tableuPosition + j);
                    if (c1 != null) {
                        c1.cardImgFront.z = 2000 + c1.tableuPosition;
                    }
                }
            } else if (c.myState == Card.STATE_TABLEU) {} else if (c.myState == Card.STATE_STOCK) {
                c.cardImgBack.z = c.myStockIdx;
            }
        }
        if (BoardManager.areAllCardsStatic()) {
            var arr = Card.cardArray;
            var i = arr.length;
            var totalStockCards = 0;
            while (i-- > 0) {
                var c = arr[i];
                if (c.myState == Card.STATE_TABLEU) {
                    c.cardImgBack.z = c.cardImgFront.z = c.tableuPosition;
                }
                if (c.myState == Card.STATE_STOCK) {
                    c.cardImgBack.z = c.myStockIdx;
                    totalStockCards++;
                }
                if (c.myState == Card.STATE_FOUNDATION) {
                    c.foundationPosition = 11 - c.cardIdx;
                    if (c.foundationPosition < 0) {
                        c.foundationPosition = 12;
                    }
                    c.cardImgFront.z = 10000 + c.foundationPosition + 13 * c.foundationIdx;
                }
            }
        }
        Card.items.sort();
        Card.stock.sort();
        GameUI.topLayer.sort();
    };
    BoardManager.areAllCardsStatic = function() {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.isMoving == true || c.myState == Card.STATE_DRAGGED || c.selectedFlag) {
                return false;
            }
        }
        return true;
    };
    BoardManager.generateBoardSnapshot = function(skipundoenable) {
        if (skipundoenable === void 0) {
            skipundoenable = false;
        }
        SimpleGame.myGame.time.events.add(100, function() {
            BoardManager.actuallyGenerateSnapshot();
        });
        if (skipundoenable == false) {}
    };
    BoardManager.actuallyGenerateSnapshot = function() {
        if (CardUtil.getCompletedStack() != null)
            return;
        console.log("generate board snapshot");
        if (BoardData.boardDataArray == null) {
            BoardData.boardDataArray = new Array();
            BoardData.boardDataIdx = 0;
        }
        var bData = new BoardData();
        var i = Card.cardArray.length;
        while (i-- > 0) {
            bData.addToBdata(Card.cardArray[i]);
        }
        console.log("stocklen: " + bData.stockPile.length);
        if (BoardData.boardDataArray.length >= 2) {
            if (BoardManager.isBdataChanged(bData, BoardData.boardDataArray[BoardData.boardDataArray.length - 1])) {
                BoardData.boardDataArray.push(bData);
                BoardData.boardDataIdx = BoardData.boardDataArray.length - 1;
            }
        } else {
            BoardData.boardDataArray.push(bData);
            BoardData.boardDataIdx = BoardData.boardDataArray.length - 1;
        }
        console.log("board data arr idx: " + BoardData.boardDataIdx);
        var i = BoardData.boardDataArray.length;
        while (i-- > 0) {
            console.log(BoardData.boardDataArray[i].tableuPile[9].length);
        }
    };
    BoardManager.isBdataChanged = function(bData, boardData) {
        return BoardData.isBdataChanged(bData, boardData);
    };
    BoardManager.Undo = function() {
        if (BoardData.boardDataIdx == -1)
            return;
        if (this.undoDisabled)
            return;
        SoundManager.playClick();
        console.log("undo called and enabled");
        if (BoardData.boardDataArray.length > 1) {
            var bData = BoardData.boardDataArray.pop();
            BoardManager.fromSnapshotToBoard(BoardData.boardDataArray[BoardData.boardDataArray.length - 1]);
            GameUI.score--;
            GameUI.moves++;
        } else {
            BoardManager.fromSnapshotToBoard(BoardData.boardDataArray[0]);
        }
        BoardManager.sort();
        var i = Card.cardArray.length;
        while (i-- > 0) {
            Card.cardArray[i].update();
        }
        BoardManager.sortImmediately();
        this.undoDisabled = true;
        console.log("undo done!");
    };
    BoardManager.fromSnapshotToBoard = function(bData, skiplayerfixes) {
        if (skiplayerfixes === void 0) {
            skiplayerfixes = false;
        }
        bData.fromSnapshotToBoard(skiplayerfixes);
    };
    BoardManager.GenerateCards = function() {
        Card.cardArray = new Array();
        var i = CardUtil.NUM_SUITS;
        while (i-- > 0) {
            var j = CardUtil.NUM_CARDS_PER_SUIT;
            while (j-- > 0) {
                var card = new Card((i % CardUtil.NUM_SUIT_COLORS), j, i);
            }
        }
        Phaser.ArrayUtils.shuffle(Card.cardArray);
    };
    BoardManager.GenerateTableu = function() {
        var totalCards = CardUtil.NUM_SUITS * CardUtil.NUM_CARDS_PER_SUIT;
        var i = totalCards - 50;
        while (i-- > 0) {
            var tableuIdx = i % 10;
            var tableuPosition = Math.floor(i / 10);
            var card = Card.cardArray[i];
            card.tableuIdx = tableuIdx;
            card.tableuPosition = tableuPosition;
            card.setToTableu(true);
            card.setTableuZCoords();
            if (CardUtil.isOnTableuTop(card)) {
                card.cardImgBack.visible = false;
                card.cardImgFront.visible = true;
                card.turned = true;
            } else {
                card.cardImgBack.visible = true;
                card.cardImgFront.visible = false;
                card.turned = false;
            }
        }
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_TABLEU) {
                c.setToTableu(true);
            }
        }
    };
    BoardManager.GenerateStock = function() {
        var totalCards = CardUtil.NUM_SUITS * CardUtil.NUM_CARDS_PER_SUIT;
        var i = totalCards;
        var stockIdx = 0;
        while (i-- > totalCards - 50) {
            var card = Card.cardArray[i];
            card.setToStock(stockIdx++);
        }
    };
    BoardManager.NUM_TABLEU_COLUMNS = 10;
    BoardManager.undoDisabled = true;
    BoardManager.sortCounter = 0;
    BoardManager.hintSuccess = false;
    BoardManager.hintState = 0;
    BoardManager.HINT_STATE_TRY_FIRST_CARD_ONLY_HINT = 0;
    BoardManager.HINT_STATE_TRY_ANY_CARD_HINT = 1;
    BoardManager.HINT_STATE_FIRST_CARD_ONLY_NORESPECT = 2;
    BoardManager.HINT_STATE_ANY_CARD_ONLY_NORESPECT = 3;
    BoardManager.HINT_STATE_TRY_EMPTY_COLUMN = 4;
    BoardManager.HINT_STATE_TRY_EMPTY_BACKUP = 5;
    BoardManager.currentObservedColumn = -1;
    return BoardManager;
}());
var Card = (function() {
    function Card(suitIdx, cardIdx, deckIdx) {
        this.STOCK_SCALE = 0.76;
        this.initTweenFlag = false;
        this.completedStackCheckedFlag = false;
        this.selectedFlag = false;
        this.turned = false;
        this.isMoving = false;
        this.stockPosition = -1;
        this.lastFrameWasOutsideOfScreen = false;
        this.banInputDown = false;
        this.colorInvertedFlag = false;
        this.initFoundationTweenFlag = false;
        this.markForKill = false;
        console.log("card created!");
        this.suitIdx = suitIdx;
        this.cardIdx = cardIdx;
        this.deckIdx = deckIdx;
        SimpleGame.myGame.stage.smoothed = true;
        SimpleGame.myGame.antialias = true;
        this.cardImgFront = SimpleGame.myGame.make.sprite(-500, -500, CardUtil.getCardImgName(suitIdx, cardIdx));
        this.cardImgFront.inputEnabled = true;
        this.cardImgFront.events.onInputDown.add(this.onCardImgFrontDown, this, 200);
        this.cardImgFront.events.onInputUp.add(function() {
            this.banInputDown = true;
            this.cardImgFront.game.time.events.add(Consts.DELAY_BETWEEN_EVENTS_TOUCH, function() {
                this.banInputDown = false;
            }, this);
        }, this, 100);
        this.cardimgfrontupsignal = this.cardImgFront.events.onInputUp.add(this.onCardImgFrontUp, this);
        this.cardImgFront.events.onInputOver.add(function() {
            console.log("card img over");
        }, this);
        this.cardImgBack = SimpleGame.myGame.make.sprite(-100, -100, 'backside');
        this.cardImgBack.inputEnabled = true;
        this.cardImgBack.events.onInputDown.add(this.onCardImgBackDown, this);
        Card.items.add(this.cardImgFront);
        Card.items.add(this.cardImgBack);
        this.cardImgFront.anchor.set(0.5, 0.5);
        this.cardImgBack.anchor.set(0.5, 0.5);
        SimpleGame.myGame.renderer.renderSession.roundPixels = true;
        Card.cardArray.push(this);
        SimpleGame.myGame.time.events.add(3000, function() {}, this);
    }
    Card.prototype.createInvertedSprite = function() {
        var bmd = SimpleGame.myGame.make.bitmapData();
        bmd.load(CardUtil.getCardImgName(this.suitIdx, this.cardIdx));
        bmd.processPixelRGB(function(pixel) {
            pixel.r = 255 - pixel.r;
            pixel.g = 255 - pixel.g;
            pixel.b = 255 - pixel.b;
            return pixel;
        }, this);
        this.invertedSprite = SimpleGame.myGame.make.sprite(this.cardImgFront.x, this.cardImgFront.y + 50, bmd);
        this.invertedSprite.z = this.cardImgFront.z;
        this.invertedSprite.visible = false;
        Card.items.add(this.invertedSprite);
    };
    Card.prototype.invertFrontColors = function() {
        if (this.invertedSprite == null) {
            this.createInvertedSprite();
        }
        this.colorInvertedFlag = true;
        this.cardImgFront.visible = false;
        this.invertedSprite.z = this.cardImgFront.z;
        this.invertedSprite.y = 400;
        SimpleGame.myGame.time.events.add(Consts.timeToHint, function() {
            this.colorInvertedFlag = false;
        }, this);
        var nextCard = CardUtil.getByTabIdxAndPos(this.tableuIdx, this.tableuPosition + 1);
        if (nextCard != null) {
            nextCard.invertFrontColors();
        }
    };
    Card.prototype.onCardImgBackDown = function() {
        if (Card.disableSelect == true)
            return;
        if (this.myState != Card.STATE_STOCK)
            return;
        if (CardUtil.canUncoverStock()) {
            CardUtil.uncoverStock(this.stockPosition);
            GameUI.gameStarted = true;
            GameUI.initialMoveMade = true;
        } else {
            var cannotuncoverstock = new CannotUncoverStock();
        }
        SoundManager.playClick();
    };
    Card.prototype.update = function() {
        if (this.markForKill) {
            console.log("mark for kill!");
            this.remove();
            return;
        }
        if (this.selectedFlag) {
            if (Math.abs(this.lastSelectedPosX - this.cardImgFront.x) > 10) {
                this.autoclickEnabled = false;
            }
            this.cardImgFront.x = SimpleGame.myGame.input.activePointer.x - this.dragDeltaX;
            this.cardImgFront.x = ResizeManager.getPointerInCardCoordinates().x - this.dragDeltaX;
            this.cardImgFront.y = SimpleGame.myGame.input.activePointer.y - this.dragDeltaY;
            this.cardImgFront.y = ResizeManager.getPointerInCardCoordinates().y - this.dragDeltaY;
            console.log(ResizeManager.getPointerInCardCoordinates().x, ResizeManager.getPointerInCardCoordinates().y);
            var i = Card.cardArray.length;
            while (i-- > 0) {
                var c = Card.cardArray[i];
                if (c.myState == Card.STATE_DRAGGED) {
                    c.update();
                }
            }
            this.lastSelectedPosX = this.cardImgFront.x;
            this.lastSelectedPosY = this.cardImgFront.y;
        }
        this.cardImgFront.alpha = 1;
        if (SimpleGame.myGame.input.activePointer.withinGame == false && (this.selectedFlag)) {
            this.lastFrameWasOutsideOfScreen = true;
        }
        if (this.selectedFlag) {}
        if (this.selectedFlag && SimpleGame.pointerDown == false && (((SimpleGame.myGame.device.tridentVersion != 0 || window.navigator.userAgent.indexOf("Edge") > -1) && SimpleGame.myGame.input.activePointer.targetObject != null) || SimpleGame.myGame.input.activePointer.withinGame || SimpleGame.myGame.input.mousePointer.withinGame) && SimpleGame.myGame.input.activePointer.isUp) {
            if (this.cardImgFront.parent) {
                console.log("new card created!");
                this.cardImgFront.parent.removeChild(this.cardImgFront);
                this.cardImgFront = SimpleGame.myGame.make.sprite(-500, -500, CardUtil.getCardImgName(this.suitIdx, this.cardIdx));
                this.cardImgFront.inputEnabled = true;
                this.cardImgFront.events.onInputDown.add(this.onCardImgFrontDown, this, 101);
                this.cardImgFront.events.onInputDown.add(function() {
                    this.banInputDown = true;
                    this.cardImgFront.game.time.events.add(Consts.DELAY_BETWEEN_EVENTS_TOUCH, function() {
                        this.banInputDown = false;
                    }, this);
                }, this, 100);
                this.cardimgfrontupsignal = this.cardImgFront.events.onInputUp.add(this.onCardImgFrontUp, this);
                this.setToTableu(true);
                Card.items.add(this.cardImgFront);
                var arr = Card.cardArray;
                var i = arr.length;
                while (i-- > 0) {
                    var c = arr[i];
                    if (c.myState == Card.STATE_DRAGGED) {
                        Card.items.add(c.cardImgFront);
                        c.setToTableu(true);
                    }
                }
                this.cardImgFront.anchor.set(0.5, 0.5);
            }
            this.onCardImgFrontUp();
        }
        if (this.myState != Card.STATE_STOCK && this.myState != Card.STATE_FOUNDATION && this.cardImgFront.scale.x < 1) {
            this.cardImgFront.scale.x += 0.02;
            this.cardImgFront.scale.y += 0.02;
        } else {
            if (this.myState != Card.STATE_FOUNDATION) {
                this.cardImgFront.scale.x = 1;
                this.cardImgFront.scale.y = 1;
            }
        }
        if (this.initTweenFlag) {
            return;
        }
        if (this.myState == Card.STATE_STOCK) {
            this.updateStock();
        }
        if (this.myState == Card.STATE_TABLEU) {
            this.updateTableu();
            this.initFoundationTweenFlag = false;
        }
        if (this.myState == Card.STATE_DRAGGED) {
            this.updateDragged();
        }
        if (this.myState == Card.STATE_STOCK_TO_TAB) {
            return;
        }
        if (this.turned == false) {
            this.cardImgBack.visible = true;
            this.cardImgFront.visible = false;
        } else {
            this.cardImgBack.visible = false;
            this.cardImgFront.visible = true;
            if (this.invertedSprite != null) {
                if (this.colorInvertedFlag) {
                    this.cardImgFront.visible = false;
                    this.invertedSprite.position.set(this.cardImgFront.x, this.cardImgFront.y);
                    this.invertedSprite.anchor.set(0.5, 0.5);
                    this.invertedSprite.z = this.cardImgFront.z;
                    this.invertedSprite.visible = true;
                } else {
                    this.invertedSprite.visible = false;
                }
            }
        }
        if (this.selectedFlag) {
            this.cardImgFront.x = Math.floor(this.cardImgFront.x);
            this.cardImgFront.y = Math.floor(this.cardImgFront.y);
        }
        if (this.myState == Card.STATE_FOUNDATION) {
            this.updateFoundation();
        }
        this.setIsMovingFlag();
    };
    Card.prototype.updateFoundation = function() {
        if (this.initFoundationTweenFlag == false) {
            this.initFoundationTweenFlag = true;
            this.cardImgFront.z += 10000;
            if (this.cardIdx == CardUtil.CARD_IDX_K) {
                this.cardImgFront.z += 100000;
            }
        } else {
            this.cardImgBack.position.set(this.cardImgFront.x, this.cardImgFront.y);
            return;
        }
        var tween3 = SimpleGame.myGame.add.tween(this.cardImgFront.scale).to({
            x: Card.FOUNDATION_SCALE,
            y: Card.FOUNDATION_SCALE
        }, 200, Phaser.Easing.Default, true);
        var tween1 = SimpleGame.myGame.add.tween(this.cardImgFront).to({
            y: Card.CARD_FOUND_POS_Y_INIT
        }, 200, Phaser.Easing.Default, true);
        var tween2 = SimpleGame.myGame.add.tween(this.cardImgFront).to({
            x: Math.floor(Card.CARD_FOUND_POS_X_INIT) - Math.floor(Card.CARD_FOUND_POS_X_DELTA) * (7 - this.foundationIdx)
        }, 200, Phaser.Easing.Default, true);
        tween2.onComplete.add(function() {
            if (this.cardIdx != CardUtil.CARD_IDX_K) {
                this.cardImgFront.y = 4000;
            }
        }, this);
    };
    Card.prototype.updateDragged = function() {
        var c = CardUtil.getSelectedCard();
        if (c != null) {
            this.cardImgFront.x = Math.round(c.cardImgFront.x - this.draggedDeltaX);
            this.cardImgFront.y = Math.round(c.cardImgFront.y - this.draggedDeltaY);
        }
    };
    Card.prototype.updateTableu = function() {
        this.cardImgBack.position.set(this.cardImgFront.x, this.cardImgFront.y);
        if (this.selectedFlag == false) {
            this.setToTableu();
        }
    };
    Card.prototype.updateStock = function() {
        if (Card.initTweenFlag == false) {
            var deltaX = 0.5 * (Card.CARD_STOCK_POSITION_X_INIT + this.stockPosition * Card.CARD_STOCK_POSITION_X_DELTA - this.cardImgBack.x);
            this.cardImgBack.position.set(this.cardImgBack.x + deltaX, Card.CARD_STOCK_POSITION_Y_INIT);
            this.cardImgBack.scale.set(this.STOCK_SCALE);
            this.cardImgFront.scale.set(this.cardImgBack.scale.x);
        } else {
            this.cardImgBack.position.set(Card.CARD_STOCK_POSITION_X_INIT + 0 * Card.CARD_STOCK_POSITION_X_DELTA, Card.CARD_STOCK_POSITION_Y_INIT);
        }
        this.cardImgFront.position.set(this.cardImgBack.x, this.cardImgBack.y);
    };
    Card.prototype.manageInvalidMovingStackSelection = function() {
        this.peekedFlag = true;
    };
    Card.prototype.onCardImgFrontDown = function() {
        BoardManager.HintReset();
        console.log("card is pressed");
        if (CardUtil.checkIfSelectedCardExists())
            return;
        if (Card.disableSelect == true)
            return;
        if (this.myState == Card.STATE_FOUNDATION)
            return;
        if (this.banInputDown) {
            console.log("input is banned");
            return;
        }
        if (CardUtil.isValidMoveStack(this) == false) {
            this.manageInvalidMovingStackSelection();
            return;
        }
        console.log("card clicked:");
        Trace.TraceCardByIdxAndPos(this.tableuIdx, this.tableuPosition);
        this.banInputDown = true;
        this.cardImgFront.game.time.events.add(Consts.DELAY_BETWEEN_EVENTS_TOUCH, function() {
            this.banInputDown = false;
        }, this);
        SoundManager.playGrabCard();
        GameUI.gameStarted = true;
        this.cardImgFront.z = 1000;
        var deltaY = 3;
        this.cardImgFront.y -= deltaY;
        var deltax = 0;
        this.cardImgFront.x -= deltax;
        this.cardImgFront.worldPosition.x;
        this.dragDeltaX = SimpleGame.myGame.input.activePointer.x - this.cardImgFront.x;
        this.dragDeltaX = ResizeManager.getPointerInCardCoordinates().x - this.cardImgFront.x;
        this.dragDeltaY = SimpleGame.myGame.input.activePointer.y - this.cardImgFront.y;
        this.dragDeltaY = ResizeManager.getPointerInCardCoordinates().y - this.cardImgFront.y;
        this.autoclickEnabled = true;
        this.selectedFlag = true;
        this.lastSelectedPosX = this.cardImgFront.x;
        this.lastSelectedPosY = this.cardImgFront.y;
        SimpleGame.myGame.time.events.add(250, function() {
            this.autoclickEnabled = false;
        }, this);
        GameUI.topLayer.add(this.cardImgFront);
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_TABLEU) {
                if (c.tableuIdx == this.tableuIdx) {
                    if (c.tableuPosition > this.tableuPosition) {
                        c.myState = Card.STATE_DRAGGED;
                        c.draggedDeltaX = 0;
                        c.draggedDeltaY = -Card.CARD_TAB_POS_Y_DELTA * (c.tableuPosition - this.tableuPosition);
                        c.cardImgFront.z = c.tableuPosition - this.tableuPosition + this.cardImgFront.z;
                        GameUI.topLayer.add(c.cardImgFront);
                    }
                }
            }
        }
        BoardManager.sort();
        BoardManager.sortImmediately();
    };
    Card.prototype.onCardImgFrontUp = function() {
        console.log("card is unpressed");
        if (this.peekedFlag == true) {
            this.peekedFlag = false;
        }
        this.lastFrameWasOutsideOfScreen = false;
        if (this.selectedFlag == false)
            return;
        this.cardImgFront.input.disableDrag();
        CardUtil.cardDeselected(this);
        if (this.autoclickEnabled == true && CardUtil.droppedOnTableuSuccess == false) {
            console.log("try to autoclick");
            CardUtil.tryToAutoclick(this);
            this.selectedFlag = false;
        } else {}
        CardUtil.returnUnplacedTabCards();
        CardUtil.tryToPlaceCardsOnFoundation();
        BoardManager.generateBoardSnapshot();
        BoardManager.sort();
        BoardManager.sortImmediately();
    };
    Card.prototype.setIsMovingFlag = function() {
        if (this.myState == Card.STATE_TABLEU) {
            var newX = Card.CARD_TAB_POS_X_INIT + this.tableuIdx * Card.CARD_TAB_POS_X_DELTA;
            if (Math.abs(newX - this.cardImgFront.x) > 3 || Math.abs(this.newY - this.cardImgFront.y) > 3) {
                this.isMoving = true;
            } else {
                this.isMoving = false;
            }
        } else if (this.myState == Card.STATE_STOCK || this.myState == Card.STATE_FOUNDATION) {
            this.isMoving = false;
        }
    };
    Card.prototype.setToTableu = function(immediately) {
        if (immediately === void 0) {
            immediately = false;
        }
        Card.CARD_TAB_POS_Y_DELTA = 9 * ResizeManager.dynamicCardYDelta;
        if (Card.CARD_TAB_POS_Y_DELTA > 26) {
            Card.CARD_TAB_POS_Y_DELTA = 26;
        }
        var closedCardsDelta = Math.floor(Card.CARD_TAB_POS_Y_DELTA * 0.45);
        var firstTurnedCardIdx = CardUtil.getFirstTurnedCardIdx(this.tableuIdx);
        var newX = Card.CARD_TAB_POS_X_INIT + this.tableuIdx * Card.CARD_TAB_POS_X_DELTA;
        this.newX = newX;
        if (firstTurnedCardIdx <= this.tableuPosition) {
            var newY = Math.floor(Card.CARD_TAB_POS_Y_INIT) + firstTurnedCardIdx * Math.floor(Card.CARD_TAB_POS_Y_DELTA - closedCardsDelta) + (this.tableuPosition - firstTurnedCardIdx) * Math.floor(Card.CARD_TAB_POS_Y_DELTA);
        } else {
            var newY = Math.floor(Card.CARD_TAB_POS_Y_INIT) + this.tableuPosition * Math.floor(Card.CARD_TAB_POS_Y_DELTA - closedCardsDelta);
        }
        if (this.tableuIdx == 0) {}
        if (Math.abs(newX - this.cardImgFront.x) > 5) {
            this.isMoving = true;
            var cMinusOne = CardUtil.getByTabIdxAndPos(this.tableuIdx, this.tableuPosition - 1);
            if (cMinusOne != null) {
                if (cMinusOne.isMoving) {
                    this.isMoving = false;
                }
            }
        } else {
            if (this.isMoving == true) {}
            this.isMoving = false;
        }
        var peekedPosition = CardUtil.getPeekedPosition(this.tableuIdx);
        var peekDelta = this.tableuPosition - peekedPosition;
        if (peekedPosition < 0) {
            peekDelta = -1;
        }
        var deltaMultiplier = Card.deltaMultiplier;
        var deltaReducer = 0.965;
        var cardsUntilReducing = 1.05 * ResizeManager.dynamicCardYDelta * 2 + 0.2 * ResizeManager.dynamicCardYDelta * ResizeManager.dynamicCardYDelta + 0.02 * ResizeManager.dynamicCardYDelta * ResizeManager.dynamicCardYDelta * ResizeManager.dynamicCardYDelta;
        var maxIdx = CardUtil.getMaxTableuPosition(this.tableuIdx);
        if (maxIdx > cardsUntilReducing) {
            var delta = maxIdx - cardsUntilReducing;
            if (firstTurnedCardIdx <= this.tableuPosition) {
                if (peekDelta > 0) {
                    var newY = Card.CARD_TAB_POS_Y_INIT + firstTurnedCardIdx * (Card.CARD_TAB_POS_Y_DELTA - closedCardsDelta) + (deltaMultiplier * delta * (Math.pow(deltaReducer, delta))) + (this.tableuPosition - firstTurnedCardIdx) * (Card.CARD_TAB_POS_Y_DELTA - deltaMultiplier * delta * (Math.pow(deltaReducer, delta)));
                } else {
                    var newY = Card.CARD_TAB_POS_Y_INIT + firstTurnedCardIdx * (Card.CARD_TAB_POS_Y_DELTA - closedCardsDelta) + (this.tableuPosition - firstTurnedCardIdx) * (Card.CARD_TAB_POS_Y_DELTA - deltaMultiplier * delta * (Math.pow(deltaReducer, delta)));
                }
            } else {
                var newY = Card.CARD_TAB_POS_Y_INIT + this.tableuPosition * (Card.CARD_TAB_POS_Y_DELTA - closedCardsDelta);
            }
        }
        if (this.selectedFlag || this.myState == Card.STATE_DRAGGED) {
            var newY = Card.CARD_TAB_POS_Y_INIT + this.tableuPosition * (Card.CARD_TAB_POS_Y_DELTA - closedCardsDelta);
        }
        newY = Math.floor(newY);
        if (immediately) {
            this.cardImgFront.x = newX;
            this.cardImgFront.y = newY;
        } else {
            var deltaX = (newX - this.cardImgFront.x) * 0.25;
            var deltaY = (newY - this.cardImgFront.y) * 0.25;
            if (Math.abs(deltaX) < 0) {
                this.cardImgFront.x = newX;
            } else {
                this.cardImgFront.x += deltaX;
            }
            if (Math.abs(deltaY) < 0) {
                this.cardImgFront.y = newY;
            } else {
                this.cardImgFront.y += deltaY;
            }
        }
        if (Math.abs(newX - this.cardImgFront.x) < 0.3 && Math.abs(newX - this.cardImgFront.x) >= 0) {
            this.cardImgFront.x = Math.round(this.cardImgFront.x);
        }
        if (Math.abs(newY - this.cardImgFront.y) < 0.3 && Math.abs(newY - this.cardImgFront.y) >= 0) {
            this.cardImgFront.y = Math.round(this.cardImgFront.y);
        }
        if (this.turned) {
            this.cardImgBack.visible = false;
            this.cardImgFront.visible = true;
        }
        this.myState = Card.STATE_TABLEU;
    };
    Card.prototype.setFromStockToTabStart = function(myTabIdx) {
        this.myTabIdx = myTabIdx;
        this.cardImgBack.visible = false;
        this.myState = Card.STATE_STOCK_TO_TAB;
        SimpleGame.myGame.time.events.add(myTabIdx * 80, this.setFromStockToTab, this);
        this.updateStock();
        this.cardImgFront.z = 10000 - myTabIdx;
    };
    Card.prototype.setFromStockToTab = function() {
        console.log("setfromstocktotab" + this);
        this.tableuPosition = 1 + CardUtil.getMaxTableuPosition(this.myTabIdx);
        this.myState = Card.STATE_TABLEU;
        this.tableuIdx = this.myTabIdx;
        SimpleGame.myGame.time.events.add(100, function() {
            this.setToTableu();
            this.flipcard(true);
        }, this);
        this.cardImgFront.z = 1000;
        this.cardImgFront.x = Card.CARD_STOCK_POSITION_X_INIT + this.stockPosition * Card.CARD_STOCK_POSITION_X_DELTA;
        this.cardImgFront.y = Card.CARD_STOCK_POSITION_Y_INIT;
        Card.items.add(this.cardImgFront);
    };
    Card.prototype.flipcard = function(withAnim) {
        if (withAnim === void 0) {
            withAnim = false;
        }
        if (this.turned)
            return;
        withAnim = false;
        if (withAnim) {
            SimpleGame.myGame.time.events.add(200, function() {
                this.cardImgFront.scale.x = 1;
            }, this);
        }
        this.turned = true;
        if (withAnim) {
            SimpleGame.myGame.time.events.add(0, function() {
                this.cardImgFront.scale.x = 0.05;
                var scaleTween = SimpleGame.myGame.add.tween(this.cardImgFront.scale).to({
                    x: 1,
                    y: 1
                }, 100, Phaser.Easing.Linear.None);
                var scaleTween1 = SimpleGame.myGame.add.tween(this.cardImgBack.scale).to({
                    x: 1,
                    y: 1
                }, 200, Phaser.Easing.Linear.None);
                scaleTween.start();
                scaleTween1.start();
                console.log("tween added");
            }, this);
            if (withAnim) {
                var scaleTween2 = SimpleGame.myGame.add.tween(this.cardImgBack.scale).to({
                    x: 0.05,
                    y: 1
                }, 60);
            } else {
                this.turned = true;
                this.cardImgBack.visible = false;
                this.cardImgFront.visible = true;
            }
        }
    };
    Card.prototype.setTableuZCoords = function() {
        this.cardImgBack.z = this.tableuPosition;
        this.cardImgFront.z = this.tableuPosition;
    };
    Card.prototype.setToStock = function(stockIdx) {
        this.myState = Card.STATE_STOCK;
        this.cardImgFront.visible = false;
        this.cardImgBack.visible = true;
        this.myStockIdx = stockIdx;
        this.stockPosition = Math.floor(stockIdx / 10);
        Card.items.add(this.cardImgBack);
        Card.items.add(this.cardImgFront);
        this.cardImgFront.z = stockIdx;
        this.cardImgBack.z = stockIdx;
        this.updateStock();
    };
    Card.prototype.initTween = function(idx) {
        console.log("init tween call");
        this.initTweenFlag = true;
        this.tweenIdx = idx;
        Card.initTweenFlag = true;
        idx = this.tableuIdx * 6 + this.tableuPosition;
        idx = this.tableuPosition * 10 + this.tableuIdx;
        idx = this.tableuIdx;
        this.cardImgBack.x = this.cardImgFront.x;
        this.cardImgBack.y = this.cardImgFront.y;
        this.cardImgBackXOld = this.cardImgFront.x;
        this.cardImgFront.y += ResizeManager.deviceHeight * 1.2;
        this.cardImgBack.y += ResizeManager.deviceHeight * 1.2;
        this.cardImgBack.x = this.cardImgFront.x = 880;
        SimpleGame.myGame.time.events.add(160 + 80 * idx, function() {
            this.isMoving = true;
            SimpleGame.myGame.time.events.add(0, function() {
                console.log("tween started");
                if (this.tweenIdx % 2 == 0 || true) {}
            }, this);
            this.tweenComplete();
        }, this);
        if (CardUtil.isOnTableuTop(this) == false) {
            this.cardImgBack.visible = true;
        }
    };
    Card.prototype.tweenComplete = function() {
        if (this.tweenIdx == 9) {
            SimpleGame.myGame.time.events.add(500, function() {
                Card.initTweenFlag = false;
            });
        }
        this.initTweenFlag = false;
        this.isMoving = false;
        Card.items.add(this.cardImgFront);
        Card.items.add(this.cardImgBack);
    };
    Card.prototype.remove = function() {
        console.log("remove called!");
        if (this.cardImgFront.parent) {
            this.cardImgFront.parent.removeChild(this.cardImgFront);
        }
        if (this.cardImgBack.parent) {
            this.cardImgBack.parent.removeChild(this.cardImgBack);
        }
        Card.items.remove(this.cardImgFront);
        Card.items.remove(this.cardImgBack);
        Card.cardArray.slice(Card.cardArray.indexOf(this, 0), 1);
        this.cardImgFront.destroy();
        this.cardImgBack.destroy();
        console.log(Card.cardArray.length);
    };
    Card.Init = function() {
        console.log("static fun");
        Card.cardArray = new Array();
        Card.backgroundLayer = SimpleGame.myGame.add.group();
        Card.stock = SimpleGame.myGame.add.group();
        Card.items = SimpleGame.myGame.add.group();
    };
    Card.preload = function() {
        SimpleGame.myGame.load.image('backside', 'assets/CARDS/backside.png');
        var i = CardUtil.NUM_CARDS_PER_SUIT * 4;
        while (i-- > 0) {
            SimpleGame.myGame.load.image(CardUtil.cardNameArray[i], CardUtil.getCardNameURLs()[i]);
        }
    };
    Card.FOUNDATION_SCALE = 0.76;
    Card.CARD_STOCK_POSITION_X_INIT = 76 * 0.6 + 54;
    Card.CARD_STOCK_POSITION_Y_INIT = 185 * 0.6 - 6;
    Card.CARD_STOCK_POSITION_X_DELTA = 25 * 0.6;
    Card.CARD_TAB_POS_X_INIT = 102 * 0.6 + 50;
    Card.CARD_TAB_POS_X_DELTA = 106;
    Card.CARD_TAB_POS_Y_INIT = 435 * 0.6 - 16;
    Card.CARD_TAB_POS_Y_DELTA = 26;
    Card.CARD_FOUND_POS_X_INIT = Math.ceil((102 + 9 * 195 + 20) * 0.6 - 52) + 2;
    Card.CARD_FOUND_POS_X_DELTA = 190 * 0.74 * 0.6;
    Card.CARD_FOUND_POS_Y_INIT = 185 * 0.6 - 6;
    Card.STATE_INIT_TWEEN = -1;
    Card.STATE_TABLEU = 0;
    Card.STATE_STOCK = 1;
    Card.STATE_FOUNDATION = 2;
    Card.STATE_DRAGGED = 3;
    Card.STATE_STOCK_TO_TAB = 4;
    Card.initTweenFlag = false;
    Card.disableSelect = false;
    Card.deltaMultiplier = 1;
    return Card;
}());
var CardUtil = (function() {
    function CardUtil() {}
    CardUtil.getByCardAndSuitIdx = function(suitidx, cardidx, deckidx) {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.suitIdx == suitidx && c.cardIdx == cardidx && c.deckIdx == deckidx) {
                return c;
            }
        }
        return null;
    };
    CardUtil.getFirstTurnedCardIdx = function(tabIdx) {
        var i = -1;
        do {
            i++;
            var c = CardUtil.getByTabIdxAndPos(tabIdx, i);
            if (c == null) {
                break;
            }
        } while (c.turned == false);
        return i;
    };
    CardUtil.cardDeselected = function(card) {
        CardUtil.returnToTableuLayer();
        CardUtil.playInvalidSound = false;
        CardUtil.droppedOnTableuSuccess = false;
        CardUtil.checkIfDroppedOnTableu(card);
        if (CardUtil.droppedOnTableuSuccess == false) {
            CardUtil.checkIfDroppedOnEmptyTableu(card);
        }
        if (CardUtil.droppedOnTableuSuccess) {
            GameUI.initialMoveMade = true;
            GameUI.moves++;
            BoardManager.undoDisabled = false;
            SimpleGame.myGame.time.events.add(150, function() {
                GameUI.score--;
            });
            SoundManager.valid.play();
        } else {
            if (CardUtil.playInvalidSound) {}
        }
    };
    CardUtil.returnToTableuLayer = function() {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            if (arr[i].myState == Card.STATE_DRAGGED || arr[i].selectedFlag) {
                Card.items.add(arr[i].cardImgFront);
            }
        }
    };
    CardUtil.getCardOnTop = function(tabIdx) {
        var i = -1;
        do {
            i++;
            var c = CardUtil.getByTabIdxAndPos(tabIdx, i);
            if (c == null) {
                return null;
            } else {}
            if (c.myState != Card.STATE_TABLEU) {
                continue;
            }
            if (CardUtil.isOnTableuTop(c)) {
                return c;
            }
        } while (c != null);
        return null;
    };
    CardUtil.tryToAutoclick = function(card) {
        CardUtil.returnToTableuLayer();
        CardUtil.autoclickMode = true;
        var j = 10;
        CardUtil.tabIdxCurrent = card.tableuIdx;
        while (j-- > 0) {
            CardUtil.tabIdxCurrent++;
            if (CardUtil.tabIdxCurrent >= 10) {
                CardUtil.tabIdxCurrent = 0;
            }
            CardUtil.droppedOnTableuSuccess = false;
            var arr = Card.cardArray;
            var i = arr.length;
            while (i-- > 0) {
                var c = arr[i];
                if (CardUtil.isOnTableuTop(c) && c.tableuIdx == CardUtil.tabIdxCurrent && c.suitIdx == card.suitIdx) {
                    if (c.tableuIdx != card.tableuIdx) {
                        CardUtil.droppedOnTableu(card, c);
                    }
                    if (CardUtil.droppedOnTableuSuccess) {
                        break;
                    }
                }
            }
            if (CardUtil.droppedOnTableuSuccess) {
                break;
            }
        }
        if (CardUtil.droppedOnTableuSuccess == false) {
            var j = 10;
            CardUtil.tabIdxCurrent = card.tableuIdx;
            while (j-- > 0) {
                CardUtil.tabIdxCurrent++;
                if (CardUtil.tabIdxCurrent >= 10) {
                    CardUtil.tabIdxCurrent = 0;
                }
                CardUtil.droppedOnTableuSuccess = false;
                var arr = Card.cardArray;
                var i = arr.length;
                while (i-- > 0) {
                    var c = arr[i];
                    if (CardUtil.isOnTableuTop(c) && c.tableuIdx == CardUtil.tabIdxCurrent) {
                        if (c.tableuIdx != card.tableuIdx) {
                            CardUtil.droppedOnTableu(card, c);
                        }
                        if (CardUtil.droppedOnTableuSuccess) {
                            break;
                        }
                    }
                }
                if (CardUtil.droppedOnTableuSuccess) {
                    break;
                }
            }
        }
        if (CardUtil.droppedOnTableuSuccess == false) {
            var i = BoardManager.NUM_TABLEU_COLUMNS;
            while (i-- > 0) {
                var idx = 9 - i;
                if (CardUtil.checkIfTabEmpty(idx) && idx != card.tableuIdx) {
                    CardUtil.dropOnEmptyTableu(card, idx);
                    CardUtil.droppedOnTableuSuccess = true;
                    break;
                }
            }
        }
        if (CardUtil.droppedOnTableuSuccess) {
            GameUI.initialMoveMade = true;
            GameUI.moves++;
            BoardManager.undoDisabled = false;
            SimpleGame.myGame.time.events.add(150, function() {
                GameUI.score--;
            });
            SoundManager.valid.play();
        }
        CardUtil.autoclickMode = false;
        card.selectedFlag = false;
    };
    CardUtil.returnUnplacedTabCards = function() {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_DRAGGED) {
                c.myState = Card.STATE_TABLEU;
            }
        }
    };
    CardUtil.getFreeFoundationIdx = function() {
        var freeFoundPos = 0;
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_FOUNDATION) {
                if (c.foundationIdx >= freeFoundPos) {
                    freeFoundPos = c.foundationIdx + 1;
                }
            }
        }
        return freeFoundPos;
    };
    CardUtil.tryToPlaceCardsOnFoundation = function() {
        SimpleGame.myGame.time.events.add(250, function() {
            var stack = CardUtil.getCompletedStack();
            if (stack == null)
                return;
            GameUI.score++;
            var freeFoundPos = CardUtil.getFreeFoundationIdx();
            var i = stack.length;
            while (i-- > 0) {
                var c = stack[i];
                c.myState = Card.STATE_FOUNDATION;
                c.foundationIdx = freeFoundPos;
                c.foundationPosition = 11 - c.cardIdx;
                if (c.foundationPosition < 0) {
                    c.foundationPosition = 12;
                }
            }
            CardUtil.uncoverTableu(c);
            SoundManager.clearrow.play();
            BoardManager.generateBoardSnapshot();
            BoardManager.undoDisabled = true;
            BoardManager.sort();
        });
    };
    CardUtil.getCompletedStack = function() {
        var arr = Card.cardArray;
        var i = arr.length;
        var retArr = [];
        while (i-- > 0) {
            var c = arr[i];
            if (c.cardIdx == CardUtil.CARD_IDX_K && c.turned && c.myState == Card.STATE_TABLEU) {
                var j = CardUtil.NUM_CARDS_PER_SUIT;
                retArr = [];
                retArr.push(c);
                do {
                    var c1 = CardUtil.getByTabIdxAndPos(c.tableuIdx, c.tableuPosition + 1);
                    if (c1 == null || CardUtil.isCardIdxFollowing(c, c1, true) == false) {
                        break;
                    }
                    retArr.push(c1);
                    c = c1;
                } while (j-- > 1);
                if (retArr.length == CardUtil.NUM_CARDS_PER_SUIT) {
                    return retArr;
                }
            }
        }
        return null;
    };
    CardUtil.isValidMoveStack = function(card) {
        var c = CardUtil.getByTabIdxAndPos(card.tableuIdx, card.tableuPosition + 1);
        if (c != null) {
            if (c.suitIdx != card.suitIdx) {
                return false;
            } else if (CardUtil.isCardIdxFollowing(card, c) == false) {
                return false;
            } else {
                return CardUtil.isValidMoveStack(c);
            }
        } else {
            return true;
        }
    };
    CardUtil.getPeekedPosition = function(tabidx) {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.tableuIdx == tabidx && c.peekedFlag) {
                return c.tableuPosition;
            }
        }
        return -1;
    };
    CardUtil.isCardIdxFollowing = function(card1, card2, respectSuit) {
        if (respectSuit === void 0) {
            respectSuit = false;
        }
        if (respectSuit) {
            if (card1.suitIdx != card2.suitIdx)
                return false;
        }
        if (card2.cardIdx <= CardUtil.CARD_IDX_Q && card1.cardIdx == card2.cardIdx + 1) {
            return true;
        } else if (card2.cardIdx == CardUtil.CARD_IDX_A && card1.cardIdx == CardUtil.CARD_IDX_02) {
            return true;
        }
        return false;
    };
    CardUtil.getByTabIdxAndPos = function(tabIdx, tabPos) {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_TABLEU && c.tableuIdx == tabIdx && c.tableuPosition == tabPos) {
                return c;
            }
        }
        return null;
    };
    CardUtil.uncoverStock = function(stockPos) {
        SoundManager.playDealRow();
        GameUI.score--;
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.stockPosition > stockPos && c.myState == Card.STATE_STOCK) {
                stockPos = c.stockPosition;
            }
        }
        var arr = Card.cardArray;
        var i = arr.length;
        var totalCardsOnStock = 0;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_STOCK)
                totalCardsOnStock++;
            if (c.myState == Card.STATE_STOCK && stockPos == c.stockPosition) {
                var myTabIdx = c.myStockIdx % 10;
                c.cardImgFront.y = 60;
                c.cardImgFront.x = 30;
                c.setFromStockToTabStart(myTabIdx);
            }
        }
        SimpleGame.myGame.time.events.add(1000, BoardManager.generateBoardSnapshot, this);
        CardUtil.getMaxTableuPosition(0);
        BoardManager.undoDisabled = true;
        Card.disableSelect = true;
        SimpleGame.myGame.time.events.add(750, function() {
            Card.disableSelect = false;
            CardUtil.tryToPlaceCardsOnFoundation();
        });
    };
    CardUtil.getMaxTableuPosition = function(idx) {
        var arr = Card.cardArray;
        var size = -1;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_TABLEU && c.tableuIdx == idx && c.tableuPosition > size) {
                size = c.tableuPosition;
            }
        }
        return size;
    };
    CardUtil.checkIfDroppedOnEmptyTableu = function(card) {
        var cardimgfrontX = card.cardImgFront.x;
        CardUtil.checkIfDroppedOnEmptyTableuCoords(card);
        if (CardUtil.droppedOnTableuSuccess == false) {
            card.cardImgFront.x += 70;
            CardUtil.checkIfDroppedOnEmptyTableuCoords(card);
        }
        card.cardImgFront.x = cardimgfrontX;
    };
    CardUtil.checkIfDroppedOnEmptyTableuCoords = function(card) {
        var img = card.cardImgFront;
        var myTableuoIdx = Math.ceil((card.cardImgFront.x - card.cardImgFront.width - Card.CARD_TAB_POS_X_INIT) / Card.CARD_TAB_POS_X_DELTA);
        if (myTableuoIdx < 0 || myTableuoIdx > 9)
            return;
        if (CardUtil.checkIfTabEmpty(myTableuoIdx)) {
            CardUtil.dropOnEmptyTableu(card, myTableuoIdx);
            CardUtil.droppedOnTableuSuccess = true;
            card.isMoving = true;
            BoardManager.sortImmediately();
        }
    };
    CardUtil.dropOnEmptyTableu = function(card, myTableuoIdx) {
        CardUtil.uncoverTableu(card);
        card.tableuIdx = myTableuoIdx;
        card.tableuPosition = 0;
        card.myState = Card.STATE_TABLEU;
        CardUtil.manageDragged(card);
    };
    CardUtil.checkIfTabEmpty = function(idx) {
        var tabEmpty = true;
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.tableuIdx == idx && c.myState == Card.STATE_TABLEU) {
                tabEmpty = false;
            }
        }
        return tabEmpty;
    };
    CardUtil.checkIfDroppedOnTableu = function(card) {
        var arr = Card.cardArray;
        if (card.newX > card.cardImgFront.x) {
            arr.sort(function(a, b) {
                if (a.tableuIdx > b.tableuIdx) {
                    return -1;
                } else if (a.tableuIdx < b.tableuIdx) {
                    return 1;
                }
                return 0;
            });
        } else {
            arr.sort(function(a, b) {
                if (a.tableuIdx > b.tableuIdx) {
                    return 1;
                } else if (a.tableuIdx < b.tableuIdx) {
                    return -1;
                }
                return 0;
            });
        }
        CardUtil.manageMultipleOverlaps(card);
        var multipleOverlaps = false;
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (CardUtil.overlapping(c.cardImgFront, card.cardImgFront)) {
                if (c.myState == Card.STATE_TABLEU) {}
            }
        }
    };
    CardUtil.manageMultipleOverlaps = function(card) {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (CardUtil.overlapping(c.cardImgFront, card.cardImgFront)) {
                if (arr[i].myState == Card.STATE_TABLEU) {
                    if (CardUtil.droppedOnTableuSuccess == false) {
                        CardUtil.droppedOnTableu(card, c);
                    }
                }
            }
            if (CardUtil.droppedOnTableuSuccess) {
                break;
            }
        }
        card.selectedFlag = false;
    };
    CardUtil.overlapsMouse = function(card) {
        if (card.getBounds().contains(SimpleGame.myGame.input.x, SimpleGame.myGame.input.y)) {
            return true;
        }
        return false;
    };
    CardUtil.getSelectedCard = function() {
        var i = Card.cardArray.length;
        while (i-- > 0) {
            if (Card.cardArray[i].selectedFlag) {
                return Card.cardArray[i];
            }
        }
        return null;
    };
    CardUtil.droppedOnTableu = function(cardPlaced, cardTableu) {
        if (CardUtil.isOnTableuTop(cardTableu)) {
            return CardUtil.tryToPlaceonTableu(cardPlaced, cardTableu);
        } else {}
    };
    CardUtil.tryToPlaceonTableu = function(cardPlaced, cardTableu) {
        if (cardTableu.cardIdx != CardUtil.CARD_IDX_A && (cardPlaced.cardIdx == CardUtil.CARD_IDX_A && cardTableu.cardIdx == CardUtil.CARD_IDX_02 || cardPlaced.cardIdx + 1 == cardTableu.cardIdx)) {
            return CardUtil.placeOnTableu(cardPlaced, cardTableu);
        } else {
            if (CardUtil.droppedOnTableuSuccess == false && CardUtil.autoclickMode == false) {
                CardUtil.playInvalidSound = true;
            }
        }
        return null;
    };
    CardUtil.placeOnTableu = function(cardPlaced, cardTableu) {
        console.log("place on tableu called");
        CardUtil.droppedOnTableuSuccess = true;
        CardUtil.uncoverTableu(cardPlaced);
        cardPlaced.myState = Card.STATE_TABLEU;
        cardPlaced.tableuIdx = cardTableu.tableuIdx;
        cardPlaced.tableuPosition = cardTableu.tableuPosition + 1;
        cardPlaced.selectedFlag = false;
        cardPlaced.setToTableu(false);
        Card.items.add(cardPlaced.cardImgFront);
        CardUtil.manageDragged(cardPlaced);
        BoardManager.sort();
    };
    CardUtil.manageDragged = function(cardTableu) {
        var arr = Card.cardArray;
        var i = arr.length;
        var minPos = 999;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_DRAGGED) {
                if (c.tableuPosition < minPos) {
                    minPos = c.tableuPosition;
                }
            }
        }
        i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c.myState == Card.STATE_DRAGGED) {
                if (minPos == c.tableuPosition) {
                    CardUtil.placeOnTableu(c, cardTableu);
                }
            }
        }
    };
    CardUtil.uncoverTableu = function(cardPlaced) {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            if (arr[i].myState == Card.STATE_TABLEU) {
                if (arr[i].tableuIdx == cardPlaced.tableuIdx) {
                    if (arr[i].tableuPosition + 1 == cardPlaced.tableuPosition) {
                        if (arr[i].flipcard(true)) {}
                    }
                }
            }
        }
    };
    CardUtil.overlapping = function(rect1, rect2) {
        if (rect1 == rect2)
            return false;
        if (rect1.x < rect2.x + rect2.width + 1 && rect1.x + rect1.width + 1 > rect2.x && rect1.y < rect2.y + rect2.height + 1 && rect1.height + 1 + rect1.y > rect2.y) {
            return true;
        }
        return false;
    };
    CardUtil.getCardImgName = function(suitidx, cardidx) {
        return CardUtil.cardNameArray[suitidx * CardUtil.NUM_CARDS_PER_SUIT + cardidx];
    };
    CardUtil.getCardNameURLs = function() {
        CardUtil.cardNameArrayUrl = new Array();
        var i = CardUtil.cardNameArray.length;
        while (i-- > 0) {
            var str = CardUtil.cardNameArray[i];
            var strURL = "assets/CARDS/" + str + ".png";
            CardUtil.cardNameArrayUrl[i] = strURL;
        }
        return CardUtil.cardNameArrayUrl;
    };
    CardUtil.isOnTableuTop = function(card) {
        if (card.myState != Card.STATE_TABLEU) {
            return false;
        }
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c == card)
                continue;
            if (c.myState == Card.STATE_TABLEU) {
                if (c.tableuIdx == card.tableuIdx) {
                    if (c.tableuPosition > card.tableuPosition) {
                        return false;
                    }
                }
            }
        }
        return true;
    };
    CardUtil.canUncoverStock = function() {
        var i = 10;
        while (i-- > 0) {
            if (CardUtil.checkIfTabEmpty(i)) {
                return false;
            }
        }
        return true;
    };
    CardUtil.checkIfSelectedCardExists = function() {
        var i = Card.cardArray.length;
        while (i-- > 0) {
            var c = Card.cardArray[i];
            if (c.selectedFlag) {
                return true;
            }
        }
        return false;
    };
    CardUtil.isMovingCardWithSmallestZ = function(card) {
        var arr = Card.cardArray;
        var i = arr.length;
        while (i-- > 0) {
            var c = arr[i];
            if (c != card && c.isMoving) {
                if (c.tableuPosition < card.tableuPosition) {
                    return false;
                }
            }
        }
        return true;
    };
    CardUtil.cardNameArray = ["spades_02", "spades_03", "spades_04", "spades_05", "spades_06", "spades_07", "spades_08", "spades_09", "spades_10", "spades_jack", "spades_queen", "spades_king", "spades_ace", "hearts_02", "hearts_03", "hearts_04", "hearts_05", "hearts_06", "hearts_07", "hearts_08", "hearts_09", "hearts_10", "hearts_jack", "hearts_queen", "hearts_king", "hearts_ace", "diamonds_02", "diamonds_03", "diamonds_04", "diamonds_05", "diamonds_06", "diamonds_07", "diamonds_08", "diamonds_09", "diamonds_10", "diamonds_jack", "diamonds_queen", "diamonds_king", "diamonds_ace", "clubs_02", "clubs_03", "clubs_04", "clubs_05", "clubs_06", "clubs_07", "clubs_08", "clubs_09", "clubs_10", "clubs_jack", "clubs_queen", "clubs_king", "clubs_ace"];
    CardUtil.NUM_CARDS_PER_SUIT = 13;
    CardUtil.NUM_SUITS = 8;
    CardUtil.NUM_SUIT_COLORS = 1;
    CardUtil.CARD_IDX_02 = 0;
    CardUtil.CARD_IDX_03 = 1;
    CardUtil.CARD_IDX_04 = 2;
    CardUtil.CARD_IDX_05 = 3;
    CardUtil.CARD_IDX_06 = 4;
    CardUtil.CARD_IDX_07 = 5;
    CardUtil.CARD_IDX_08 = 6;
    CardUtil.CARD_IDX_09 = 7;
    CardUtil.CARD_IDX_10 = 8;
    CardUtil.CARD_IDX_J = 9;
    CardUtil.CARD_IDX_Q = 10;
    CardUtil.CARD_IDX_K = 11;
    CardUtil.CARD_IDX_A = 12;
    CardUtil.tabIdxCurrent = -1;
    CardUtil.autoclickMode = false;
    CardUtil.playInvalidSound = false;
    return CardUtil;
}());
var AreYouSurePrompt = (function() {
    function AreYouSurePrompt(type) {
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(-2048, -2048, 4096, 4096);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.7;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_difficulty');
        this.menuBG.x = 0;
        this.menuBG.y = -0.1 * ResizeManager.deviceHeight;
        GameUI.promptLayer.add(this.menuBG);
        this.menuBG.anchor.set(0.5, 0.5);
        var yesText = SimpleGame.myGame.make.text(0, 0, "" + Language.YES[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var noText = SimpleGame.myGame.make.text(0, 0, "" + Language.NO[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var areyousurfull = Language.ARE_YOU_SURE_NEW[Language.langIdx];
        var fullText = SimpleGame.myGame.make.text(0, 0, "" + areyousurfull, {
            font: "22px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Center"
        });
        fullText.y = this.menuBG.y - 70;
        fullText.wordWrap = true;
        fullText.wordWrapWidth = 450;
        fullText.x = 0;
        fullText.anchor.set(0.5, 0.5);
        GameUI.promptLayer.add(fullText);
        if (type == AreYouSurePrompt.TYPE_NEW_GAME) {
            var yesBut = new ButtonWithOverAndText(yesText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
                console.log("yes clicked game");
                console.log(this.startNewFlag);
                GameUI.promptLayer.removeAll(true);
                console.log("start new game");
                BoardManager.removeAllCards();
                BoardManager.increaseGameCount();
                var newgame = new NewGamePrompt();
            });
        } else if (type == AreYouSurePrompt.TYPE_CLEAR_STATS) {
            var yesBut = new ButtonWithOverAndText(yesText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
                console.log("clear stats");
                Util.clearStoragePerDifficulty();
                GameUI.promptLayer.removeAll(true);
                var stats = new StatisticsPrompt(true);
            });
            fullText.text = Language.are_you_sure_clear_stats[Language.langIdx] + " for " + CardUtil.NUM_SUIT_COLORS + " suit game?";
        } else {
            var yesBut = new ButtonWithOverAndText(yesText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
                console.log("yes clicked game");
                console.log(this.startNewFlag);
                GameUI.promptLayer.removeAll(true);
                BoardManager.increaseGameCount();
                BoardManager.resetBoard();
            });
            fullText.text = Language.ARE_YOU_SURE_RESTART[Language.langIdx];
        }
        var keepPlayBut = new ButtonWithOverAndText(noText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("yes clicked game");
            GameUI.promptLayer.removeAll(true);
        });
        keepPlayBut.setXY(this.menuBG.x * 0.5 - keepPlayBut.imgNormal.width * 0.5 - 130, this.menuBG.y + 75);
        yesBut.setXY(this.menuBG.x * 0.5 - yesBut.imgNormal.width * 0.5 + 131, this.menuBG.y + 75);
        fullText.text = fullText.text.toUpperCase();
    }
    AreYouSurePrompt.TYPE_NEW_GAME = 0;
    AreYouSurePrompt.TYPE_RESTART_GAME = 1;
    AreYouSurePrompt.TYPE_CLEAR_STATS = 2;
    return AreYouSurePrompt;
}());
var CannotUncoverStock = (function() {
    function CannotUncoverStock() {
        if (CannotUncoverStock.shownAlready)
            return;
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(-2048, -2048, 4096, 4096);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.7;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_difficulty');
        this.menuBG.x = 0;
        this.menuBG.y = -0.1 * ResizeManager.deviceHeight;
        GameUI.promptLayer.add(this.menuBG);
        this.menuBG.anchor.set(0.5, 0.5);
        this.menuText = SimpleGame.myGame.make.text(0, 0, "" + Language.THERE_MUST_BE_AT_LEAST[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Center"
        });
        this.menuText.y = this.menuBG.y - 50;
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 450;
        this.menuText.x = 0;
        this.menuText.anchor.set(0.5, 0.5);
        GameUI.promptLayer.add(this.menuText);
        var yesText = SimpleGame.myGame.make.text(0, 0, "OK", {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var yesBut = new ButtonWithOverAndText(yesText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("ok clicked game");
            GameUI.promptLayer.removeAll(true);
        });
        yesBut.setXY(this.menuBG.x * 0.5 - yesBut.imgNormal.width * 0.5 - 130, this.menuBG.y + 80);
        yesBut.textYDelta = 1;
        var dontText = SimpleGame.myGame.make.text(0, 0, Language.DONTSHOWAGAIN[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var dontBut = new ButtonWithOverAndText(dontText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("ok clicked game");
            GameUI.promptLayer.removeAll(true);
            console.log("checkbox is checked!!");
            CannotUncoverStock.shownAlready = true;
        });
        dontBut.setXY(this.menuBG.x * 0.5 - dontBut.imgNormal.width * 0.5 + 130, this.menuBG.y + 80);
    }
    CannotUncoverStock.shownAlready = false;
    return CannotUncoverStock;
}());
var GameWonPrompt = (function() {
    function GameWonPrompt(gameWon) {
        if (gameWon === void 0) {
            gameWon = true;
        }
        var gameswon = Util.getStoragePerDifficulty("gamesWon");
        if (gameWon) {
            SoundManager.won.play();
            gameswon++;
            Util.setStoragePerDifficulty("gamesWon", gameswon);
        } else {}
        GameUI.gameStarted = false;
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(0, 41, 880, 600);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.9;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_bg_levels_won');
        this.menuBG.x = (SimpleGame.myGame.width - this.menuBG.width) * 0.5;
        this.menuBG.y = 70;
        GameUI.promptLayer.add(this.menuBG);
        this.menuBG.visible = false;
        this.mainText = SimpleGame.myGame.make.text(0, 0, "" + Language.congrats[Language.langIdx], {
            font: "65px Open Sans",
            fill: "#dfe0e4",
            fontWeight: "600",
            align: "Center"
        });
        this.mainText.y = this.menuBG.y + 71;
        this.mainText.wordWrap = true;
        this.mainText.wordWrapWidth = 650;
        this.mainText.x = this.menuBG.x + (this.menuBG.width) * 0.5 - this.mainText.width * 0.5;
        this.menuText.y = this.menuBG.y + 7;
        GameUI.promptLayer.add(this.menuText);
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 650;
        this.menuText.x = this.menuBG.x + (this.menuBG.width) * 0.5 - this.menuText.width * 0.5;
        var bestTime = Util.getStoragePerDifficulty("bestTime", 99999999999999999);
        if (bestTime > GameUI.time) {
            bestTime = GameUI.time;
        }
        if (bestTime == 0) {
            bestTime = GameUI.time;
        }
        Util.setStoragePerDifficulty("bestTime", bestTime);
        var bestScore = Util.getStoragePerDifficulty("bestScore1", 0);
        if (bestScore < GameUI.scoreTotal) {
            console.log("new best score!");
            Util.setStoragePerDifficulty("bestScore1", GameUI.scoreTotal);
        }
        var points = "" + GameUI.scoreTotal;
        var bonus = GameUI.gameTime - GameUI.time;
        var pointsTotal = GameUI.scoreTotal + bonus;
        var timeplayed = Util.convertToHHMMSS(GameUI.time);
        this.timescoreTxt = SimpleGame.myGame.make.text(0, 0, "" + Language.yourscore[Language.langIdx] + (GameUI.scoreTotal) + "\n" + Language.timebonus[Language.langIdx] + "" + bonus + "\n" + Language.totalscore[Language.langIdx] + pointsTotal + "\n\n" + Language.playedgames[Language.langIdx] + Util.getStoragePerDifficulty("gamesPlayed") + "\n" + Language.wongames[Language.langIdx] + " " + gameswon + "\n" + Language.best_score[Language.langIdx] + Util.getStoragePerDifficulty("bestScore1", 0) + "\n" + Language.best_time[Language.langIdx] + Util.convertToHHMMSS(Util.getStoragePerDifficulty("bestTime")), {
            font: "24px Open Sans",
            fill: "#c1cbec",
            fontWeight: "600",
            align: "Center"
        });
        this.timescoreTxt.text = this.timescoreTxt.text.toUpperCase();
        this.timescoreTxt.y = this.menuBG.y + 91;
        GameUI.promptLayer.add(this.timescoreTxt);
        this.timescoreTxt.wordWrap = true;
        this.timescoreTxt.wordWrapWidth = 420;
        this.timescoreTxt.x = this.menuBG.x + (this.menuBG.width) * 0.5 - this.timescoreTxt.width * 0.5;
        this.timescoreTxt.lineSpacing = -5;
        var newGameText = SimpleGame.myGame.make.text(0, 0, Language.NEW_GAME[Language.langIdx].toUpperCase(), {
            font: "20px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        var newGameBut = new ButtonWithOverAndText(newGameText, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("newgame clicked game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptLayer.removeAll(true);
            BoardManager.InitializeBoard();
        });
        newGameBut.setXY(this.menuBG.x + (this.menuBG.width - newGameBut.imgNormal.width) * 0.50, this.menuBG.y + 333 + 30);
        var restartText = SimpleGame.myGame.make.text(0, 0, "" + Language.RESTART[Language.langIdx].toUpperCase(), {
            font: "20px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        var restartBut = new ButtonWithOverAndText(restartText, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("yes clicked game");
            GameUI.promptLayer.removeAll(true);
            BoardManager.resetBoard();
        });
        restartBut.setXY(this.menuBG.x + (this.menuBG.width - restartBut.imgNormal.width) * 0.5, this.menuBG.y + 409 + 30);
    }
    return GameWonPrompt;
}());
var GameWonPrompt2 = (function() {
    function GameWonPrompt2(gameWon) {
        if (gameWon === void 0) {
            gameWon = true;
        }
        console.log("Game Won Prompt!!");
        var cumulativeScore = Util.getStoragePerDifficulty("cumulativeScore", 0);
        cumulativeScore += GameUI.scoreTotal;
        Util.setStoragePerDifficulty("cumulativeScore", cumulativeScore);
        Util.setStoragePerDifficulty("cumulativeTime", (Util.getStoragePerDifficulty("cumulativeTime", 0) + GameUI.time));
        Util.setStoragePerDifficulty("cumulativeMoves", (Util.getStoragePerDifficulty("cumulativeMoves", 0) + GameUI.moves));
        var gameswon = Util.getStoragePerDifficulty("gamesWon");
        if (gameWon) {
            SoundManager.won.play();
            gameswon++;
            Util.setStoragePerDifficulty("gamesWon", gameswon);
        } else {}
        var curBestScore = Util.getStoragePerDifficulty("bestScore", 0);
        if (curBestScore < GameUI.scoreTotal) {
            curBestScore = GameUI.scoreTotal;
            Util.setStoragePerDifficulty("bestScore", curBestScore);
        }
        var bestTime = Util.getStoragePerDifficulty("bestTime", 999999999999999999);
        if (bestTime == 0)
            bestTime = 99999999999999999;
        if (bestTime > GameUI.time) {
            bestTime = GameUI.time;
            console.log("set best time to: " + bestTime);
            Util.setStoragePerDifficulty("bestTime", bestTime);
        }
        var leastMoves = Util.getStoragePerDifficulty("leastMoves", 999999999999999);
        if (leastMoves == 0)
            leastMoves = 9999999999999;
        if (leastMoves > GameUI.moves) {
            leastMoves = GameUI.moves;
            console.log("set least moves to: " + leastMoves);
            Util.setStoragePerDifficulty("leastMoves", leastMoves);
        } else {
            console.log(leastMoves, GameUI.moves);
        }
        GameUI.gameStarted = false;
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(-2048, -2048, 4096, 4096);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.7;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'won_bg');
        this.menuBG.x = 0;
        this.menuBG.y = -0.1 * ResizeManager.deviceHeight;
        GameUI.promptLayer.add(this.menuBG);
        this.menuBG.anchor.set(0.5, 0.5);
        this.mainText = SimpleGame.myGame.make.text(0, 0, "" + Language.YOUWONGAME[Language.langIdx], {
            font: "26px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Center"
        });
        this.mainText.y = this.menuBG.y - 151;
        this.mainText.wordWrap = true;
        this.mainText.wordWrapWidth = 650;
        this.mainText.x = 0;
        this.mainText.anchor.set(0.5, 0.5);
        GameUI.promptLayer.add(this.mainText);
        this.timescoreTxt = SimpleGame.myGame.make.text(0, 0, "", {
            font: "20px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Left"
        });
        this.timescoreTxt.y = this.menuBG.y - 20;
        this.timescoreTxt.wordWrap = true;
        this.timescoreTxt.wordWrapWidth = 650;
        this.timescoreTxt.x = 60 - this.menuBG.width * 0.5 + 20;
        this.timescoreTxt.anchor.set(0, 0.5);
        GameUI.promptLayer.add(this.timescoreTxt);
        this.timescoreTxt.text = "" + Language.yourscore[Language.langIdx] + "\n" + Language.minutes_played[Language.langIdx] + "\n" + Language.themovesyoumade[Language.langIdx] + "\n\n" + Language.best_score[Language.langIdx] + "\n" + Language.best_time[Language.langIdx] + "\n" + Language.least_moves[Language.langIdx];
        this.timescoreTxtRight = SimpleGame.myGame.make.text(0, 0, "", {
            font: "20px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Right"
        });
        this.timescoreTxtRight.y = this.menuBG.y - 20;
        this.timescoreTxtRight.wordWrap = true;
        this.timescoreTxtRight.wordWrapWidth = 650;
        this.timescoreTxtRight.x = this.menuBG.width * 0.5 - 80;
        this.timescoreTxtRight.anchor.set(1, 0.5);
        GameUI.promptLayer.add(this.timescoreTxtRight);
        this.timescoreTxtRight.text = "" + GameUI.scoreTotal + "\n" + Util.convertToHHMMSS(GameUI.time) + "\n" + GameUI.moves + "\n\n" + curBestScore + "\n" + Util.convertToHHMMSS(bestTime) + "\n" + leastMoves;
        GameUI.initialMoveMade = false;
        var newGameText = SimpleGame.myGame.make.text(0, 0, Language.NEW_GAME[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var newGameBut = new ButtonWithOverAndText(newGameText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("newgame clicked game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptLayer.removeAll(true);
            GameUI.initialMoveMade = false;
            var newgameprompt = new NewGamePrompt();
        });
        var restartText = SimpleGame.myGame.make.text(0, 0, "" + Language.RESTART[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var restartBut = new ButtonWithOverAndText(restartText, GameUI.promptLayer, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("yes clicked game");
            GameUI.promptLayer.removeAll(true);
            GameUI.initialMoveMade = false;
            BoardManager.resetBoard();
        });
        BoardManager.increaseGameCount();
        restartBut.setXY(this.menuBG.x * 0.5 - restartBut.imgNormal.width * 0.5 - 130, this.menuBG.y + 111);
        newGameBut.setXY(this.menuBG.x * 0.5 - restartBut.imgNormal.width * 0.5 + 131, this.menuBG.y + 111);
        console.log("read cumulative score: " + Util.getStoragePerDifficulty("cumulativeScore"));
    }
    return GameWonPrompt2;
}());
var InitMenuPrompt = (function() {
    function InitMenuPrompt(firstGame) {
        if (firstGame === void 0) {
            firstGame = true;
        }
        console.log("init menu added");
        var initmenugroup = SimpleGame.myGame.add.group();
        if (firstGame) {
            SimpleGame.myGame.input.reset();
        }
        this.gamebg = SimpleGame.myGame.add.sprite(0, 0, 'game_bg');
        initmenugroup.add(this.gamebg);
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(0, 0, 880, 700);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.7;
        this.blackbg.inputEnabled = true;
        SimpleGame.myGame.time.events.add(250, function() {
            this.blackbg.events.onInputUp.add(function() {
                SimpleGame.myGame.input.mspointer.capture = false;
                if (GameUI.promptLayer != null) {
                    GameUI.promptLayer.removeAll(true);
                }
            });
        }, this);
        initmenugroup.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_bg_levels_empty_slots');
        this.menuBG.x = (SimpleGame.myGame.width - this.menuBG.width) * 0.5;
        this.menuBG.y = 120;
        initmenugroup.add(this.menuBG);
        var leveltxt = SimpleGame.myGame.make.text(0, 0, "" + Language.NEW_GAME[Language.langIdx].toUpperCase(), {
            font: "24px Open Sans",
            fill: "#6993d1",
            fontWeight: "800"
        });
        initmenugroup.add(leveltxt);
        leveltxt.anchor.set(0.5);
        leveltxt.x = 440;
        leveltxt.y = 144;
        var selleveltxt = SimpleGame.myGame.make.text(0, 0, "", {
            font: "21px Open Sans",
            fill: "#263b5b",
            fontWeight: "600"
        });
        initmenugroup.add(selleveltxt);
        selleveltxt.anchor.set(0.5);
        selleveltxt.x = 440;
        selleveltxt.y = 200;
        var easyText = SimpleGame.myGame.make.text(0, 0, "" + Language.EASY[Language.langIdx], {
            font: "20px Open Sans",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var easyButton = new ButtonWithOverAndText(easyText, initmenugroup, 'prompt_button', 'prompt_button_over', 0, 500, function() {
            GameUI.gameStarted = false;
            CardUtil.NUM_SUIT_COLORS = 1;
            initmenugroup.removeAll(true);
            SimpleGame.startGame(firstGame);
            InitMenuPrompt.startFullScreen = true;
            SimpleGame.myGame.time.events.add(350, function() {
                InitMenuPrompt.startFullScreen = false;
            }, this);
        });
        easyButton.setXY(440 - easyButton.imgNormal.width * 0.5, 230 - 3);
        var normalText = SimpleGame.myGame.make.text(0, 0, "" + Language.NORMAL[Language.langIdx], {
            font: "20px Open Sans",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var normalButton = new ButtonWithOverAndText(normalText, initmenugroup, 'prompt_button', 'prompt_button_over', 0, 500, function() {
            GameUI.gameStarted = false;
            CardUtil.NUM_SUIT_COLORS = 2;
            initmenugroup.removeAll(true);
            SimpleGame.startGame(false);
            InitMenuPrompt.startFullScreen = true;
            SimpleGame.myGame.time.events.add(350, function() {
                InitMenuPrompt.startFullScreen = false;
            }, this);
        });
        normalButton.setXY(440 - normalButton.imgNormal.width * 0.5, 305 - 3 + 1);
        var hardText = SimpleGame.myGame.make.text(0, 0, "" + Language.HARD[Language.langIdx], {
            font: "20px Open Sans",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var hardButton = new ButtonWithOverAndText(hardText, initmenugroup, 'prompt_button', 'prompt_button_over', 0, 500, function() {
            GameUI.gameStarted = false;
            CardUtil.NUM_SUIT_COLORS = 4;
            initmenugroup.removeAll(true);
            SimpleGame.startGame(firstGame);
            InitMenuPrompt.startFullScreen = true;
            SimpleGame.myGame.time.events.add(350, function() {
                InitMenuPrompt.startFullScreen = false;
            }, this);
        });
        hardButton.setXY(440 - hardButton.imgNormal.width * 0.5, 380 - 3 + 2);
        SimpleGame.myGame.renderer.renderSession.roundPixels = true;
    };
    InitMenuPrompt.prototype.onTweenComplete = function() {};
    return InitMenuPrompt;
}());
var InitMenuPrompt2 = (function() {
    function InitMenuPrompt2(firstGame) {
        if (firstGame === void 0) {
            firstGame = true;
        }
        var initmenugroup = SimpleGame.myGame.add.group();
        SimpleGame.myGame.input.reset();
        this.menuBG = SimpleGame.myGame.make.sprite(0, 0, 'menu_bg');
        this.menuBG.x = this.menuBG.y = 0;
        initmenugroup.add(this.menuBG);
        this.menuText = SimpleGame.myGame.make.text(0, 0, Language.HOW_TO_PLAY_FULL[Language.langIdx], {
            font: "23px Open Sans",
            fill: "#e3e8f6",
            fontWeight: "400"
        });
        this.menuText.y = this.menuBG.y + 270;
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 450;
        this.menuText.align = "CENTER";
        initmenugroup.add(this.menuText);
        this.menuText.x = this.menuBG.x + (this.menuBG.width - this.menuText.width) * 0.5;
        this.menuText.x = Math.round(this.menuText.x);
        this.menuText.y = Math.round(this.menuText.y);
        this.menuText.smoothed = true;
        if (this.menuText.text.length % 2 == 1) {
            this.menuText.text += " ";
        }
        var microsoft;
        microsoft = SimpleGame.myGame.make.graphics(0, 0);
        microsoft.beginFill(0xffffff);
        microsoft.drawRect(SimpleGame.myGame.width * 0.5 - 190, SimpleGame.myGame.height - 40, 330, 40);
        microsoft.endFill();
        microsoft.inputEnabled = true;
        microsoft.events.onInputDown.add(onmicrosoftDown, this);
        microsoft.events.onInputUp.add(onmicrosoftUp);
        microsoft.alpha = 0.01;
        initmenugroup.add(microsoft);
        microsoft.input.useHandCursor = true;
        window.addEventListener("click", onWindowClicked);
        var easyText = SimpleGame.myGame.make.text(0, 0, "" + Language.EASY[Language.langIdx], {
            font: "19px Open Sans",
            fill: "#ffffff",
            fontWeight: "500"
        });
        var easyButton = new ButtonWithOverAndText(easyText, initmenugroup, 'menu1', 'menu1_over', 0, 500, function() {
            CardUtil.NUM_SUIT_COLORS = 1;
            initmenugroup.removeAll(true);
            SimpleGame.startGame(firstGame);
            GameUI.gameTime = Consts.GAMETIME_EASY;
            InitMenuPrompt.startFullScreen = true;
            SimpleGame.myGame.time.events.add(350, function() {
                InitMenuPrompt.startFullScreen = false;
            }, this);
        });
        easyButton.setXY(240 - easyButton.imgNormal.width * 0.5, 370);
        easyButton.textYDelta += 31;
        var normalText = SimpleGame.myGame.make.text(0, 0, "" + Language.NORMAL[Language.langIdx], {
            font: "19px Open Sans",
            fill: "#ffffff",
            fontWeight: "500"
        });
        var normalButton = new ButtonWithOverAndText(normalText, initmenugroup, 'menu2', 'menu2_over', 0, 500, function() {
            CardUtil.NUM_SUIT_COLORS = 2;
            initmenugroup.removeAll(true);
            SimpleGame.startGame(firstGame);
            GameUI.gameTime = Consts.GAMETIME_MEDIUM;
            InitMenuPrompt.startFullScreen = true;
            SimpleGame.myGame.time.events.add(350, function() {
                InitMenuPrompt.startFullScreen = false;
            }, this);
        });
        normalButton.setXY(440 - normalButton.imgNormal.width * 0.5, 370);
        normalButton.textYDelta += 31;
        var hardText = SimpleGame.myGame.make.text(0, 0, "" + Language.HARD[Language.langIdx], {
            font: "19px Open Sans",
            fill: "#ffffff",
            fontWeight: "500"
        });
        var hardButton = new ButtonWithOverAndText(hardText, initmenugroup, 'menu3', 'menu3_over', 0, 500, function() {
            CardUtil.NUM_SUIT_COLORS = 4;
            initmenugroup.removeAll(true);
            SimpleGame.startGame(firstGame);
            GameUI.gameTime = Consts.GAMETIME_HARD;
            InitMenuPrompt.startFullScreen = true;
            SimpleGame.myGame.time.events.add(350, function() {
                InitMenuPrompt.startFullScreen = false;
            }, this);
        });
        hardButton.setXY(640 - hardButton.imgNormal.width * 0.5, 370);
        hardButton.textYDelta += 31;
        SimpleGame.myGame.renderer.renderSession.roundPixels = true;
    };
    InitMenuPrompt2.prototype.onTweenComplete = function() {};
    return InitMenuPrompt2;
}());
var MainMenu = (function() {
    function MainMenu() {
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(0, 0, 880, 700);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.9;
        this.blackbg.inputEnabled = true;
        SimpleGame.myGame.time.events.add(250, function() {
            this.blackbg.events.onInputUp.add(function() {
                GameUI.promptLayer.removeAll(true);
                GameUI.resetMenuButton();
            });
        }, this);
        GameUI.promptLayer.add(this.blackbg);
        GameUI.promptLayer.y -= 100;
        SimpleGame.myGame.add.tween(GameUI.promptLayer).to({
            y: GameUI.promptLayer.y + 100
        }, 100, Phaser.Easing.Default, true);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_bg_menu');
        this.menuBG.x = (SimpleGame.myGame.width - this.menuBG.width) * 0.5;
        this.menuBG.y = 60;
        GameUI.promptLayer.add(this.menuBG);
        this.menuBG.inputEnabled = true;
        this.menuBG.visible = false;
        this.menuText = SimpleGame.myGame.make.text(0, 0, "" + Language.MENU[Language.langIdx].toUpperCase(), {
            font: "24px Open Sans",
            fill: "#252525",
            fontWeight: "800"
        });
        this.menuText.anchor.set(0, 0.5);
        this.menuText.x = this.menuBG.x + (this.menuBG.width - this.menuText.width) * 0.5;
        this.menuText.y = this.menuBG.y + 23;
        GameUI.promptLayer.add(this.menuText);
        this.menuText.visible = false;
        var resumeText = SimpleGame.myGame.make.text(0, 0, "" + Language.RESUME[Language.langIdx].toUpperCase(), {
            font: "16px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        var resumeBut = new ButtonWithOverAndText(resumeText, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("resume game");
            GameUI.promptLayer.removeAll(true);
            SimpleGame.myGame.input.mspointer.capture = false;
            GameUI.resetMenuButton();
        });
        resumeBut.setXY(this.menuBG.x + (this.menuBG.width - resumeBut.imgNormal.width) * 0.5, this.menuBG.y + 72 - 5);
        resumeBut.text.y -= 1;
        var newgametexteasy = SimpleGame.myGame.make.text(0, 0, "" + Language.NEW_GAME[Language.langIdx].toUpperCase(), {
            font: "16px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        var newgamebuteasy = new ButtonWithOverAndText(newgametexteasy, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("new game clicked");
            SimpleGame.myGame.input.mspointer.capture = false;
            CardUtil.NUM_SUIT_COLORS = 1;
            GameUI.promptLayer.removeAll(true);
            console.log("start new game");
            BoardManager.removeAllCards();
            var initprompt = new InitMenuPrompt2(false);
        });
        newgamebuteasy.setXY(this.menuBG.x + (this.menuBG.width - newgamebuteasy.imgNormal.width) * 0.5, resumeBut.imgNormal.y + 76);
        var resetgametext = SimpleGame.myGame.make.text(0, 0, "" + Language.RESTART[Language.langIdx].toUpperCase(), {
            font: "16px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        var resetgamebut = new ButtonWithOverAndText(resetgametext, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("reset game clicked");
            GameUI.promptLayer.removeAll(true);
            SimpleGame.myGame.input.mspointer.capture = false;
            BoardManager.resetBoard();
            GameUI.resetMenuButton();
        });
        resetgamebut.setXY(this.menuBG.x + (this.menuBG.width - resetgamebut.imgNormal.width) * 0.5, newgamebuteasy.imgNormal.y + 76);
        var moregamestext = SimpleGame.myGame.make.text(0, -10, "" + Language.MORE_GAMES[Language.langIdx].toUpperCase(), {
            font: "16px Open Sans",
            fill: "#252525",
            fontWeight: "700"
        });
        var moregamesbut = new ButtonWithOverAndText(moregamestext, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("more games clicked");
            onmicrosoftUp();
        });
        moregamesbut.imgNormal.events.onInputDown.add(onmicrosoftDown, this);
        moregamesbut.imgNormal.events.onInputUp.add(onmicrosoftUp, this);
        console.log(moregamestext.height, newgametexteasy.height);
    }
    MainMenu.prototype.remove = function() {};
    return MainMenu;
}());
var NewGamePrompt = (function() {
    function NewGamePrompt(showXBut) {
        if (showXBut === void 0) {
            showXBut = false;
        }
        GameUI.promptHolder.removeAll();
        SimpleGame.myGame.renderer.renderSession.roundPixels = true;
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(-2048, -2048, 4096, 4096);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.7;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_difficulty');
        this.menuBG.x = 0;
        this.menuBG.y = -0.1 * ResizeManager.deviceHeight;
        this.menuBG.anchor.set(0.5, 0.5);
        GameUI.promptHolder.add(this.menuBG);
        console.log(this.menuBG.x, this.menuBG.y);
        var spidersol = Language.difficulty[Language.langIdx];
        this.menuText = SimpleGame.myGame.make.text(0, 0, "" + spidersol, {
            font: "22px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Center"
        });
        this.menuText.y = GameUI.promptHolder.add(this.menuText);
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 380;
        this.menuText.x = 0;
        this.menuText.anchor.set(0.5, 0.5);
        this.menuText.y = -120 + this.menuBG.y;
        this.menuText = SimpleGame.myGame.make.text(0, 0, Language.difficulty[Language.langIdx], {
            font: "14px Arial",
            fill: "#000000",
            fontWeight: "400"
        });
        this.menuText.x = this.menuBG.x + (this.menuBG.width - this.menuText.width) * 0.5;
        this.menuText.y = this.menuBG.y + 380;
        GameUI.promptLayer.add(GameUI.promptHolder);
        this.addButtons(GameUI.promptHolder);
        GameUI.promptHolder.scale.set(0.8);
        var tweenE = SimpleGame.myGame.add.tween(GameUI.promptHolder.scale).to({
            x: 1,
            y: 1
        }, 200, Phaser.Easing.Quadratic.Out, true, 0);
        SimpleGame.myGame.time.events.add(200, function() {
            this.addButtons(GameUI.promptLayer);
        }, this);
    }
    NewGamePrompt.prototype.addButtons = function(parent) {
        var easyText = SimpleGame.myGame.make.text(0, 0, Language.NEW_GAME[Language.langIdx].toUpperCase() + " (" + Language.EASY[Language.langIdx].toUpperCase() + ")", {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var easyBut = new ButtonWithOverAndText(easyText, parent, "button_newgame", "button_newgame_over", this.menuBG.x + (this.menuBG.width - 80) * 0.5, this.menuBG.y + 313, function() {
            console.log("easy game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptHolder.removeAll(true);
            CardUtil.NUM_SUIT_COLORS = 1;
            BoardManager.InitializeBoard();
        });
        var normalText = SimpleGame.myGame.make.text(0, 0, Language.NEW_GAME[Language.langIdx].toUpperCase() + " (" + Language.NORMAL[Language.langIdx].toUpperCase() + ")", {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var normalBut = new ButtonWithOverAndText(normalText, parent, "button_newgame", "button_newgame_over", this.menuBG.x + (this.menuBG.width - 80) * 0.5, this.menuBG.y + 303, function() {
            console.log("normal game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptHolder.removeAll(true);
            CardUtil.NUM_SUIT_COLORS = 2;
            BoardManager.InitializeBoard();
        });
        var hardText = SimpleGame.myGame.make.text(0, 0, Language.NEW_GAME[Language.langIdx].toUpperCase() + " (" + Language.HARD[Language.langIdx].toUpperCase() + ")", {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var hardBut = new ButtonWithOverAndText(hardText, parent, "button_newgame", "button_newgame_over", this.menuBG.x + (this.menuBG.width - 80) * 0.5, this.menuBG.y + 303, function() {
            console.log("hard game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptHolder.removeAll(true);
            CardUtil.NUM_SUIT_COLORS = 4;
            BoardManager.InitializeBoard();
        });
        easyBut.setXY(-easyBut.imgNormal.width / 2, -180 + 90 + this.menuBG.y);
        normalBut.setXY(-easyBut.imgNormal.width / 2, -100 + 90 + this.menuBG.y);
        hardBut.setXY(-easyBut.imgNormal.width / 2, -20 + 90 + this.menuBG.y);
    };
    return NewGamePrompt;
}());
var NewGamePrompt2 = (function() {
    function NewGamePrompt2() {
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(0, 0, 880, 600);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.001;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_rest');
        this.menuBG.x = (SimpleGame.myGame.width - this.menuBG.width) * 0.5;
        this.menuBG.y = 0;
        GameUI.promptHolder.add(this.menuBG);
        this.mainText = SimpleGame.myGame.make.text(0, 0, "" + Language.NEW_GAME[Language.langIdx], {
            font: "16px Arial",
            fill: "#ffffff",
            fontWeight: "600",
            align: "Center"
        });
        this.mainText.y = this.menuBG.y + 220;
        GameUI.promptLayer.add(this.mainText);
        this.mainText.wordWrap = true;
        this.mainText.wordWrapWidth = 650;
        this.mainText.x = 290;
        var wongameTxt = Language.YOUWONGAME[Language.langIdx];
        this.menuText = SimpleGame.myGame.make.text(0, 0, "" + Language.ARE_YOU_SURE_NEW[Language.langIdx], {
            font: "15px Open Sans",
            fill: "#000000",
            fontWeight: "500",
            align: "Center"
        });
        this.menuText.y = this.menuBG.y + 270;
        GameUI.promptHolder.add(this.menuText);
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 250;
        this.menuText.x = this.menuBG.x + (this.menuBG.width) * 0.5 - this.menuText.width * 0.5;
        this.addButtons(GameUI.promptHolder);
        GameUI.promptHolder.scale.set(0.8);
        var tweenE = SimpleGame.myGame.add.tween(GameUI.promptHolder.scale).to({
            x: 1,
            y: 1
        }, 600, Phaser.Easing.Elastic.Out, true, 0);
        tweenE.onComplete.add(function() {}, this);
    }
    NewGamePrompt2.prototype.addButtons = function(parent) {
        var newGameText = SimpleGame.myGame.make.text(0, 0, Language.YES[Language.langIdx], {
            font: "15px Arial",
            fill: "#000000",
            fontWeight: "500"
        });
        var newGameBut = new ButtonWithOverAndText(newGameText, parent, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("newgame clicked game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptLayer.removeAll(true);
            BoardManager.InitializeBoard();
        });
        newGameBut.setXY(this.menuBG.x + (this.menuBG.width - newGameBut.imgNormal.width) * 0.50 - 50, this.menuBG.y + 340);
        var restartText = SimpleGame.myGame.make.text(0, 0, "" + Language.NO[Language.langIdx], {
            font: "15px Arial",
            fill: "#000000",
            fontWeight: "500"
        });
        var restartBut = new ButtonWithOverAndText(restartText, parent, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("yes clicked game");
            GameUI.promptLayer.removeAll(true);
        });
        restartBut.setXY(this.menuBG.x + (this.menuBG.width - restartBut.imgNormal.width) * 0.5 + 50, this.menuBG.y + 340);
        var removeButton = new ButtonWithOverState(GameUI.promptLayer, "prompt_close", "prompt_close_over", 576, 219, function() {
            GameUI.promptLayer.removeAll(true);
        });
    };
    return NewGamePrompt2;
}());
var RestartGamePrompt = (function() {
    function RestartGamePrompt() {
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(0, 0, 880, 600);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.001;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'prompt_rest');
        this.menuBG.x = (SimpleGame.myGame.width - this.menuBG.width) * 0.5;
        this.menuBG.y = 0;
        GameUI.promptLayer.add(this.menuBG);
        this.mainText = SimpleGame.myGame.make.text(0, 0, "" + Language.restart_this_game[Language.langIdx], {
            font: "16px Arial",
            fill: "#ffffff",
            fontWeight: "600",
            align: "Left"
        });
        this.mainText.y = this.menuBG.y + 220;
        GameUI.promptLayer.add(this.mainText);
        this.mainText.wordWrap = true;
        this.mainText.wordWrapWidth = 650;
        this.mainText.x = 290;
        var wongameTxt = Language.YOUWONGAME[Language.langIdx];
        this.menuText = SimpleGame.myGame.make.text(0, 0, "" + Language.ARE_YOU_SURE_RESTART[Language.langIdx], {
            font: "15px Open Sans",
            fill: "#000000",
            fontWeight: "500",
            align: "Center"
        });
        this.menuText.y = this.menuBG.y + 270;
        GameUI.promptLayer.add(this.menuText);
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 250;
        this.menuText.x = this.menuBG.x + (this.menuBG.width) * 0.5 - this.menuText.width * 0.5;
        var newGameText = SimpleGame.myGame.make.text(0, 0, Language.YES[Language.langIdx], {
            font: "15px Arial",
            fill: "#000000",
            fontWeight: "500"
        });
        var newGameBut = new ButtonWithOverAndText(newGameText, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("newgame clicked game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptLayer.removeAll(true);
            BoardManager.resetBoard();
        });
        newGameBut.setXY(this.menuBG.x + (this.menuBG.width - newGameBut.imgNormal.width) * 0.50 - 50, this.menuBG.y + 340);
        var restartText = SimpleGame.myGame.make.text(0, 0, "" + Language.NO[Language.langIdx], {
            font: "15px Arial",
            fill: "#000000",
            fontWeight: "500"
        });
        var restartBut = new ButtonWithOverAndText(restartText, GameUI.promptLayer, "prompt_button", "prompt_button_over", 0, 0, function() {
            console.log("yes clicked game");
            GameUI.promptLayer.removeAll(true);
        });
        restartBut.setXY(this.menuBG.x + (this.menuBG.width - restartBut.imgNormal.width) * 0.5 + 50, this.menuBG.y + 340);
        var removeButton = new ButtonWithOverState(GameUI.promptLayer, "prompt_close", "prompt_close_over", 576, 219, function() {
            GameUI.promptLayer.removeAll(true);
        });
    }
    return RestartGamePrompt;
}());
var StatisticsPrompt = (function() {
    function StatisticsPrompt(skipTween) {
        if (skipTween === void 0) {
            skipTween = false;
        }
        this.yDelta = 35;
        GameUI.promptHolder.removeAll();
        var gamesPlayedC = Util.getStoragePerDifficulty("gamesPlayed");
        if (gamesPlayedC < 0) {
            gamesPlayedC = 0;
        }
        var difficultyStr;
        if (CardUtil.NUM_SUIT_COLORS == 4) {
            difficultyStr = Language.HARD[Language.langIdx];
        } else if (CardUtil.NUM_SUIT_COLORS == 2) {
            difficultyStr = Language.NORMAL[Language.langIdx];
        } else {
            difficultyStr = Language.EASY[Language.langIdx];
        }
        difficultyStr = difficultyStr.toUpperCase();
        var gamesWonC = Util.getStoragePerDifficulty("gamesWon");
        var gamesLostC = gamesPlayedC - gamesWonC;
        if (gamesLostC < 0) {
            gamesLostC = 0;
        }
        var gamesPlayedCount1 = gamesPlayedC;
        if (gamesPlayedCount1 == 0) {
            gamesPlayedCount1 = 1;
        }
        var winPerc = Math.round(gamesWonC / gamesPlayedC * 100);
        if (isNaN(winPerc)) {
            winPerc = 0;
        }
        var topScore = Util.getStoragePerDifficulty("bestScore");
        var cumulativeScore = Util.getStoragePerDifficulty("cumulativeScore");
        if (gamesPlayedCount1 == 1 && cumulativeScore > topScore)
            cumulativeScore = topScore;
        var averageScore = cumulativeScore / gamesPlayedCount1;
        if (isNaN(averageScore)) {
            averageScore = 0;
        }
        var bestTime = Util.convertToHHMMSS(Util.getStoragePerDifficulty("bestTime"));
        var cumulativeTime = Util.convertToHHMMSS(Util.getStoragePerDifficulty("cumulativeTime"));
        var averageTime = Util.convertToHHMMSS(Math.floor(Util.getStoragePerDifficulty("cumulativeTime") / gamesPlayedCount1));
        if (isNaN(Math.floor(Util.getStoragePerDifficulty("cumulativeTime") / gamesPlayedC))) {
            averageTime = Util.convertToHHMMSS(0);
        }
        var leastMoves = Util.getStoragePerDifficulty("leastMoves", 0);
        var cumulativeMoves = Util.getStoragePerDifficulty("cumulativeMoves");
        var averageMoves = cumulativeMoves / (gamesPlayedCount1);
        this.blackbg = SimpleGame.myGame.make.graphics(0, 0);
        this.blackbg.beginFill(0x000000);
        this.blackbg.drawRect(-2048, -2048, 4096, 4096);
        this.blackbg.endFill();
        this.blackbg.alpha = 0.7;
        this.blackbg.inputEnabled = true;
        GameUI.promptLayer.add(this.blackbg);
        this.menuBG = SimpleGame.myGame.add.sprite(0, 0, 'statics_bg');
        this.menuBG.x = 0;
        this.menuBG.y = 0;
        GameUI.promptHolder.add(this.menuBG);
        this.menuBG.anchor.set(0.5, 0.5);
        this.menuText = SimpleGame.myGame.make.text(0, 0, Language.STATISTICS[Language.langIdx].toUpperCase() + " " + difficultyStr, {
            font: "26px Arimo",
            fill: "#694014",
            fontWeight: "700"
        });
        this.menuText.y = GameUI.promptHolder.add(this.menuText);
        this.menuText.wordWrap = true;
        this.menuText.wordWrapWidth = 380;
        this.menuText.x = 0;
        this.menuText.anchor.set(0.5, 0.5);
        this.menuText.y = -230 + this.menuBG.y + 5;
        this.timescoreTxt = SimpleGame.myGame.make.text(0, 0, "", {
            font: "20px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Left"
        });
        this.timescoreTxt.y = this.menuBG.y - 20;
        this.timescoreTxt.wordWrap = true;
        this.timescoreTxt.wordWrapWidth = 650;
        this.timescoreTxt.x = 60 - this.menuBG.width * 0.5 + 20;
        this.timescoreTxt.anchor.set(0, 0.5);
        GameUI.promptHolder.add(this.timescoreTxt);
        this.timescoreTxt.text = "" + Language.playedgames[Language.langIdx] + "\n" + Language.wongames[Language.langIdx] + "\n" + Language.lostgames[Language.langIdx] + "\n" + Language.highest_score[Language.langIdx] + "\n" + Language.cumulative_score[Language.langIdx] + "\n" + Language.average_score[Language.langIdx] + "\n" + Language.best_time[Language.langIdx] + "\n" + Language.cumulative_time[Language.langIdx] + "\n" + Language.average_time[Language.langIdx] + "\n" + Language.least_moves_used[Language.langIdx] + "\n" + Language.cumulative_moves[Language.langIdx] + "\n" + Language.average_moves[Language.langIdx];
        this.timescoreTxtRight = SimpleGame.myGame.make.text(0, 0, "", {
            font: "20px Arimo",
            fill: "#694014",
            fontWeight: "700",
            align: "Right"
        });
        this.timescoreTxtRight.y = this.menuBG.y - 20;
        this.timescoreTxtRight.wordWrap = true;
        this.timescoreTxtRight.wordWrapWidth = 650;
        this.timescoreTxtRight.x = this.menuBG.width * 0.5 - 80;
        this.timescoreTxtRight.anchor.set(1, 0.5);
        GameUI.promptHolder.add(this.timescoreTxtRight);
        this.timescoreTxtRight.text = "" + gamesPlayedC + "\n" + gamesWonC + "\n" + gamesLostC + "\n" + topScore + "\n" + cumulativeScore + "\n" + Math.ceil(averageScore) + "\n" + bestTime + "\n" + cumulativeTime + "\n" + averageTime + "\n" + leastMoves + "\n" + cumulativeMoves + "\n" + Math.ceil(averageMoves);
        GameUI.promptLayer.add(GameUI.promptHolder);
        if (skipTween) {
            this.addButtons(GameUI.promptLayer);
            return;
        }
        this.addButtons(GameUI.promptHolder);
        GameUI.promptHolder.scale.set(0.8);
        var tweenE = SimpleGame.myGame.add.tween(GameUI.promptHolder.scale).to({
            x: 1,
            y: 1
        }, 200, Phaser.Easing.Quadratic.Out, true, 0);
        SimpleGame.myGame.time.events.add(200, function() {
            this.addButtons(GameUI.promptLayer);
        }, this);
    }
    StatisticsPrompt.prototype.addButtons = function(parent) {
        var clearText = SimpleGame.myGame.make.text(0, 0, Language.close[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var clearBut = new ButtonWithOverAndText(clearText, parent, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("ok clicked game");
            GameUI.promptLayer.removeAll(true);
            GameUI.promptHolder.removeAll(true);
        });
        clearBut.setXY(this.menuBG.x * 0.5 - clearBut.imgNormal.width * 0.5 - 130, this.menuBG.y + 170 + 12);
        var resetText = SimpleGame.myGame.make.text(0, 0, Language.reset[Language.langIdx].toUpperCase(), {
            font: "22px Arimo",
            fill: "#ffffff",
            fontWeight: "700"
        });
        var resetBut = new ButtonWithOverAndText(resetText, parent, "button_prompt", "button_prompt_over", 0, 0, function() {
            console.log("ok clicked game");
            GameUI.promptLayer.removeAll(true);
            var areyousure = new AreYouSurePrompt(AreYouSurePrompt.TYPE_CLEAR_STATS);
        });
        resetBut.setXY(this.menuBG.x * 0.5 - resetBut.imgNormal.width * 0.5 + 131, this.menuBG.y + 170 + 12);
    };
    return StatisticsPrompt;
}());
var ButtonTextOnly = (function() {
    function ButtonTextOnly(parent, x, y, width, height, text, onClickFunction) {
        if (onClickFunction === void 0) {
            onClickFunction = function() {};
        }
        this.disabled = false;
        this.isVisible = true;
        this.parent = parent;
        this.text = text;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.onClickFunction = onClickFunction;
        this.buttonText = SimpleGame.myGame.make.text(x, y, this.text, {
            font: "14px Arial",
            fill: "#000000",
            fontWeight: "400",
            align: "Right"
        });
        this.buttonText.inputEnabled = true;
        this.buttonText.anchor.set(0, 0.5);
        this.underline = SimpleGame.myGame.make.graphics(this.buttonText.left, this.buttonText.bottom - 5);
        this.underline.lineStyle(2, 0x000000);
        this.underline.moveTo(0, 0);
        this.underline.lineTo(this.buttonText.width, 0);
        this.buttonText.events.onInputDown.add(this.executeOnClickFunction, this);
        this.buttonText.events.onInputOver.add(this.addUnderline, this);
        this.buttonText.events.onInputOut.add(this.removeUnderline, this);
        this.buttonText.input.useHandCursor = true;
        this.underline.visible = false;
        parent.add(this.underline);
        parent.add(this.buttonText);
        console.log(this.underline);
    }
    ButtonTextOnly.prototype.executeOnClickFunction = function() {
        if (this.disabled)
            return;
        if (this.isVisible == false)
            return;
        console.log("execute on click function");
        this.onClickFunction();
        SimpleGame.myGame.input.reset();
    };
    ButtonTextOnly.prototype.addUnderline = function() {
        if (this.disabled)
            return;
        if (SimpleGame.myGame.device.touch)
            return;
        this.underline.visible = true;
    };
    ButtonTextOnly.prototype.removeUnderline = function() {
        this.underline.visible = false;
    };
    ButtonTextOnly.prototype.disable = function() {
        this.disabled = true;
        this.removeUnderline();
        this.buttonText.addColor("#87888b", 0);
    };
    ButtonTextOnly.prototype.enable = function() {
        this.disabled = false;
        this.buttonText.addColor("#000000", 0);
    };
    ButtonTextOnly.prototype.goInvisible = function() {
        console.log("go invisible called: " + this.buttonText.text);
        this.parent.remove(this.underline);
        this.parent.remove(this.buttonText);
        this.isVisible = false;
    };
    ButtonTextOnly.prototype.goVisible = function() {
        console.log("go visible called: " + this.buttonText.text);
        this.parent.add(this.underline);
        this.parent.add(this.buttonText);
        SimpleGame.myGame.time.events.add(50, function() {
            this.isVisible = true;
        }, this);
    };
    return ButtonTextOnly;
}());
var ButtonWithOverState = (function() {
    function ButtonWithOverState(parent, imgNormalName, imgOverName, x, y, onClickFunction) {
        if (onClickFunction === void 0) {
            onClickFunction = function() {};
        }
        this.onClickExecuted = false;
        this.skipClickSound = false;
        this.skipMouseOver = false;
        this.imgnormalnamestr = imgNormalName;
        this.parent = parent;
        this.imgNormalName = imgNormalName;
        this.imgOverName = imgOverName;
        this.x = x;
        this.y = y;
        this.imgNormal = SimpleGame.myGame.make.sprite(this.x, this.y, imgNormalName);
        this.imgOver = SimpleGame.myGame.make.sprite(this.x, this.y, imgOverName);
        parent.add(this.imgNormal);
        parent.add(this.imgOver);
        this.imgNormal.inputEnabled = this.imgOver.inputEnabled = false;
        this.imgOver.inputEnabled = false;
        this.imgNormal.events.onInputOver.add(this.onButtonOver, this, 0);
        this.imgNormal.events.onInputUp.add(this.banInput, this, 100);
        this.imgNormal.events.onInputDown.add(this.onButtonClicked, this, 2);
        this.imgNormal.events.onInputOut.add(this.onButtonOut, this, 1);
        this.imgOver.events.onInputOut.add(this.onButtonOut, this, 1);
        this.imgOver.events.onInputUp.add(this.onButtonOut, this, 4);
        this.imgNormal.events.onInputDown.add(function() {
            console.log("normal image clicked");
        }, this);
        this.imgOver.events.onInputDown.add(function() {
            console.log("over image clicked");
        }, this);
        this.onClickFunction = onClickFunction;
        this.imgOver.visible = false;
        this.loopEvent = SimpleGame.myGame.time.events.loop(100, this.update, this);
        this.loopEvent1 = SimpleGame.myGame.time.events.loop(10, this.update1, this);
        console.log("button created");
        SimpleGame.myGame.time.events.add(150, function() {
            this.imgNormal.inputEnabled = true;
            if (GameUI.promptLayer != null) {
                if (GameUI.promptLayer.countLiving() <= 0) {
                    this.imgNormal.input.useHandCursor = true;
                } else {
                    this.imgNormal.input.useHandCursor = true;
                }
            } else {
                this.imgNormal.input.useHandCursor = true;
            }
            console.log("input enabled");
        }, this);
        SimpleGame.myGame.input.onTap.add(function() {});
        this.imgNormal.events.onInputUp.add(function() {});
    }
    ButtonWithOverState.prototype.update = function() {
        if (this.imgNormal.input != null) {
            if (this.skipMouseOver) {
                console.log("remove hand cursor");
                this.imgOver.visible = false;
            } else {}
        }
        if (this.imgOver.parent) {
            if (!this.imgOver.getBounds().contains(SimpleGame.myGame.input.x, SimpleGame.myGame.input.y)) {} else {}
        } else {
            SimpleGame.myGame.time.events.remove(this.loopEvent);
        }
        this.setXY(this.x, this.y);
    };
    ButtonWithOverState.prototype.update1 = function() {
        this.setXY(this.x, this.y);
    };
    ButtonWithOverState.prototype.banInput = function() {
        this.onClickExecuted = true;
        SimpleGame.myGame.time.events.add(50, function() {
            this.onClickExecuted = false;
        }, this);
    };
    ButtonWithOverState.prototype.onButtonOver = function() {
        console.log("button over");
        this.imgNormal.input.useHandCursor = true;
        if (this.skipMouseOver) {
            console.log("skip mouse over is true!!");
            return;
        }
        this.imgOver.visible = true;
        this.imgNormal.alpha = 0.00001;
        SimpleGame.myGame.canvas.style.cursor = "pointer";
        console.log("mouse set to pointer");
        if (SimpleGame.myGame.device.touch) {}
    };
    ButtonWithOverState.prototype.onButtonOut = function() {
        if (this.imgnormalnamestr == "open_menu2") {}
        this.imgOver.visible = false;
        this.imgNormal.alpha = 1;
    };
    ButtonWithOverState.prototype.onButtonClicked = function(evt) {
        if (this.onClickExecuted == false) {
            this.onClickExecuted = true;
            SimpleGame.myGame.time.events.add(60, function() {
                this.onClickExecuted = false;
            }, this);
            this.onClickFunction();
            SoundManager.playClick();
        } else {}
        SimpleGame.myGame.input.enabled = false;
        SimpleGame.myGame.time.events.add(60, function() {
            SimpleGame.myGame.input.enabled = true;
            SimpleGame.myGame.input.reset();
        });
    };
    ButtonWithOverState.prototype.setXY = function(x, y) {
        this.imgNormal.x = x;
        this.imgOver.x = x;
        this.x = x;
        this.imgNormal.y = y;
        this.imgOver.y = y;
        this.y = y;
    };
    return ButtonWithOverState;
}());
var ButtonWithOverAndText = (function(_super) {
    __extends(ButtonWithOverAndText, _super);

    function ButtonWithOverAndText(text, parent, imgNormalName, imgOverName, x, y, onClickFunction) {
        if (onClickFunction === void 0) {
            onClickFunction = function() {};
        }
        var _this = _super.call(this, parent, imgNormalName, imgOverName, x, y, onClickFunction) || this;
        _this.fixedTxtCoords = false;
        _this.fixedTxtX = 0;
        _this.fixedTxtY = 0;
        _this.textY = 0;
        _this.textX = 0;
        _this.textYDelta = 0;
        _this.text = text;
        parent.add(text);
        return _this;
    }
    ButtonWithOverAndText.prototype.changeParent = function(parent) {
        this.parent = parent;
        parent.add(this.imgNormal);
        parent.add(this.imgOver);
        parent.add(this.text);
    };
    ButtonWithOverAndText.prototype.setXY = function(x, y) {
        _super.prototype.setXY.call(this, x, y);
        if (this.fixedTxtCoords) {
            this.text.x = this.imgNormal.x + this.fixedTxtX;
            this.text.y = this.imgNormal.y + this.fixedTxtY;
        } else {
            this.text.x = this.imgNormal.x + 0.5 * (this.imgNormal.width - this.text.width);
            this.text.y = this.imgNormal.y + 0.5 * (this.imgNormal.height - 0.85 * this.text.height) + 1;
        }
        this.textX = this.text.x;
        this.textY = this.text.y + this.textYDelta;
        if (this.imgOver.visible) {
            this.text.y = this.textY;
        } else {
            this.text.y = this.textY;
        }
        if (navigator.platform.toUpperCase().indexOf('MAC') >= 0) {
            this.text.y = this.textY - 2;
        }
    };
    ButtonWithOverAndText.prototype.update = function() {
        _super.prototype.update.call(this);
        if (this.imgOver.visible) {
            this.text.y = this.textY;
            if (SimpleGame.myGame.device.macOS) {
                this.text.y = this.textY - 2;
            }
        } else {
            this.text.y = this.textY;
            if (SimpleGame.myGame.device.macOS) {
                this.text.y = this.textY - 2;
            }
        }
    };
    ButtonWithOverAndText.prototype.setVisible = function() {
        console.log("set visible");
        this.parent.add(this.imgNormal);
        this.parent.add(this.imgOver);
        this.parent.add(this.text);
    };
    ButtonWithOverAndText.prototype.setInvisible = function() {
        this.parent.remove(this.imgNormal);
        this.parent.remove(this.imgOver);
        this.parent.remove(this.text);
    };
    return ButtonWithOverAndText;
}(ButtonWithOverState));
var UndoBut = (function(_super) {
    __extends(UndoBut, _super);

    function UndoBut(text, parent, imgNormalName, imgOverName, x, y, onClickFunction, secondaryTextColor, imdDisabledName) {
        if (onClickFunction === void 0) {
            onClickFunction = function() {};
        }
        if (secondaryTextColor === void 0) {
            secondaryTextColor = "#d15d10";
        }
        if (imdDisabledName === void 0) {
            imdDisabledName = "button_undo_no_undo";
        }
        var _this = _super.call(this, text, parent, imgNormalName, imgOverName, x, y, onClickFunction) || this;
        _this.primaryTextColor = _this.text.colors[0];
        _this.secondaryTextColor = secondaryTextColor;
        _this.imgDisabled = SimpleGame.myGame.make.sprite(_this.x, _this.y, imdDisabledName);
        parent.add(_this.imgDisabled);
        _this.imgDisabled.inputEnabled = false;
        parent.add(text);
        return _this;
    }
    UndoBut.prototype.disable = function() {
        this.parent.remove(this.imgNormal);
        this.parent.remove(this.imgOver);
        this.text.addColor(this.secondaryTextColor, 0);
        this.parent.add(this.imgDisabled);
        this.parent.addChild(this.text);
    };
    UndoBut.prototype.enable = function() {
        this.parent.add(this.imgNormal);
        this.parent.add(this.imgOver);
        this.text.addColor(this.primaryTextColor, 0);
        this.parent.remove(this.imgDisabled);
        this.parent.addChild(this.text);
    };
    UndoBut.prototype.setVisible = function() {
        console.log("set visible");
        this.parent.add(this.imgNormal);
        this.parent.add(this.imgOver);
        this.parent.add(this.imgDisabled);
        this.parent.add(this.text);
    };
    UndoBut.prototype.setInvisible = function() {
        this.parent.remove(this.imgNormal);
        this.parent.remove(this.imgOver);
        this.parent.remove(this.imgDisabled);
        this.parent.remove(this.text);
    };
    UndoBut.prototype.changeParent = function(parent) {
        this.parent = parent;
        parent.add(this.imgNormal);
        parent.add(this.imgOver);
        parent.add(this.imgDisabled);
        parent.add(this.text);
    };
    UndoBut.prototype.setXY = function(x, y) {
        _super.prototype.setXY.call(this, x, y);
        this.imgDisabled.x = this.imgNormal.x;
        this.imgDisabled.y = this.imgNormal.y;
    };
    return UndoBut;
}(ButtonWithOverAndText));
var CheckboxControl = (function() {
    function CheckboxControl(parent, uncheckedImageName, checkedImageName, x, y) {
        this.isChecked = false;
        this.x = x;
        this.y = y;
        var uncheckedImage = SimpleGame.myGame.make.sprite(x, y, uncheckedImageName);
        parent.add(uncheckedImage);
        uncheckedImage.inputEnabled = true;
        uncheckedImage.events.onInputDown.add(this.switchState, this);
        var checkedImage = SimpleGame.myGame.make.sprite(x, y, checkedImageName);
        parent.add(checkedImage);
        checkedImage.inputEnabled = true;
        checkedImage.events.onInputDown.add(this.switchState, this);
        this.uncheckedImage = uncheckedImage;
        this.checkedImage = checkedImage;
        this.update();
    }
    CheckboxControl.prototype.update = function() {
        if (this.isChecked) {
            this.uncheckedImage.visible = false;
            this.checkedImage.visible = true;
        } else {
            this.uncheckedImage.visible = true;
            this.checkedImage.visible = false;
        }
    };
    CheckboxControl.prototype.switchState = function() {
        this.isChecked = !this.isChecked;
        this.update();
    };
    return CheckboxControl;
}());
var Utils;
(function(Utils) {
    var ScreenMetrics = (function() {
        function ScreenMetrics() {}
        return ScreenMetrics;
    }());
    Utils.ScreenMetrics = ScreenMetrics;
    var Orientation;
    (function(Orientation) {
        Orientation[Orientation["PORTRAIT"] = 0] = "PORTRAIT";
        Orientation[Orientation["LANDSCAPE"] = 1] = "LANDSCAPE";
    })(Orientation = Utils.Orientation || (Utils.Orientation = {}));;
    var ScreenUtils = (function() {
        function ScreenUtils() {}
        ScreenUtils.calculateScreenMetrics = function(aDefaultWidth, aDefaultHeight, aOrientation, aMaxGameWidth, aMaxGameHeight) {
            if (aOrientation === void 0) {
                aOrientation = Orientation.LANDSCAPE;
            }
            var windowWidth = window.innerWidth;
            var windowHeight = window.innerHeight;
            if ((windowWidth < windowHeight && aOrientation === Orientation.LANDSCAPE) || (windowHeight < windowWidth && aOrientation === Orientation.PORTRAIT)) {
                var tmp = windowWidth;
                windowWidth = windowHeight;
                windowHeight = tmp;
            }
            if (typeof aMaxGameWidth === "undefined" || typeof aMaxGameHeight === "undefined") {
                if (aOrientation === Orientation.LANDSCAPE) {
                    aMaxGameWidth = Math.round(aDefaultWidth * 1420 / 1280);
                    aMaxGameHeight = Math.round(aDefaultHeight * 960 / 800);
                } else {
                    aMaxGameWidth = Math.round(aDefaultWidth * 960 / 800);
                    aMaxGameHeight = Math.round(aDefaultHeight * 1420 / 1280);
                }
            }
            var defaultAspect = (aOrientation === Orientation.LANDSCAPE) ? 1280 / 800 : 800 / 1280;
            var windowAspect = windowWidth / windowHeight;
            var offsetX = 0;
            var offsetY = 0;
            var gameWidth = 0;
            var gameHeight = 0;
            if (windowAspect > defaultAspect) {
                gameHeight = aDefaultHeight;
                gameWidth = Math.ceil((gameHeight * windowAspect) / 2.0) * 2;
                gameWidth = Math.min(gameWidth, aMaxGameWidth);
                offsetX = (gameWidth - aDefaultWidth) / 2;
                offsetY = 0;
            } else {
                gameWidth = aDefaultWidth;
                gameHeight = Math.ceil((gameWidth / windowAspect) / 2.0) * 2;
                gameHeight = Math.min(gameHeight, aMaxGameHeight);
                offsetX = 0;
                offsetY = (gameHeight - aDefaultHeight) / 2;
            }
            var scaleX = windowWidth / gameWidth;
            var scaleY = windowHeight / gameHeight;
            this.screenMetrics = new ScreenMetrics();
            this.screenMetrics.windowWidth = windowWidth;
            this.screenMetrics.windowHeight = windowHeight;
            this.screenMetrics.defaultGameWidth = aDefaultWidth;
            this.screenMetrics.defaultGameHeight = aDefaultHeight;
            this.screenMetrics.maxGameWidth = aMaxGameWidth;
            this.screenMetrics.maxGameHeight = aMaxGameHeight;
            this.screenMetrics.gameWidth = gameWidth;
            this.screenMetrics.gameHeight = gameHeight;
            this.screenMetrics.scaleX = scaleX;
            this.screenMetrics.scaleY = scaleY;
            this.screenMetrics.offsetX = offsetX;
            this.screenMetrics.offsetY = offsetY;
            return this.screenMetrics;
        };
        return ScreenUtils;
    }());
    Utils.ScreenUtils = ScreenUtils;
})(Utils || (Utils = {}));
var Util = (function() {
    function Util() {}
    Util.convertToHHMMSS = function(seconds) {
        var s = seconds % 60;
        var m = Math.floor((seconds % 3600) / 60);
        var h = Math.floor(seconds / (60 * 60));
        var hourStr = (false) ? "" : Util.doubleDigitFormat(h) + ":";
        var minuteStr = Util.doubleDigitFormat(m) + ":";
        var secondsStr = Util.doubleDigitFormat(s);
        return hourStr + minuteStr + secondsStr;
    };
    Util.convertToMMSS = function(seconds) {
        var s = seconds % 60;
        var m = Math.floor((seconds) / 60);
        var h = Math.floor(seconds / (60 * 60));
        var hourStr = (false) ? "" : Util.doubleDigitFormat(h) + ":";
        var minuteStr = Util.doubleDigitFormat(m) + ":";
        var secondsStr = Util.doubleDigitFormat(s);
        return minuteStr + secondsStr;
    };
    Util.doubleDigitFormat = function(num) {
        if (num < 10) {
            return ("0" + num);
        }
        return "" + num;
    };
    Util.getStorage = function(s, defaultRetValue) {
        if (defaultRetValue === void 0) {
            defaultRetValue = 0;
        }
        var storageData = 0;
        try {
            storageData = parseInt(window.localStorage.getItem(s));
        } catch (error) {
            return 0;
        }
        if (isNaN(storageData)) {
            storageData = 0;
            try {
                window.localStorage.setItem(s, defaultRetValue.toString());
            } catch (error) {
                return 0;
            }
        }
        return storageData;
    };
    Util.getStoragePerDifficulty = function(s, defaultRetValue) {
        if (defaultRetValue === void 0) {
            defaultRetValue = 0;
        }
        var totalString = "121" + s + CardUtil.NUM_SUIT_COLORS;
        return this.getStorage(totalString, defaultRetValue);
    };
    Util.setStorage = function(s, val) {
        try {
            window.localStorage.setItem(s, val.toString());
        } catch (error) {}
    };
    Util.setStoragePerDifficulty = function(s, val) {
        console.log("set " + s + " to: " + val);
        var totalString = "121" + s + CardUtil.NUM_SUIT_COLORS;
        this.setStorage(totalString, val);
    };
    Util.clearStorage = function(s, defaultVal) {
        if (defaultVal === void 0) {
            defaultVal = 0;
        }
    };
    Util.clearStoragePerDifficulty = function() {
        Util.setStoragePerDifficulty("cumulativeScore", 0);
        Util.setStoragePerDifficulty("cumulativeTime", 0);
        Util.setStoragePerDifficulty("cumulativeMoves", 0);
        Util.setStoragePerDifficulty("gamesPlayed", 0);
        Util.setStoragePerDifficulty("bestScore1", 0);
        Util.setStoragePerDifficulty("gamesWon", 0);
        Util.setStoragePerDifficulty("bestTime", 0);
        Util.setStoragePerDifficulty("leastMoves", 0);
    };
    Util.fixedDigitCount = function(digits, number) {
        var digitCount = number.toString().length;
        var deltaCount = digits - digitCount;
        var retStr = "";
        while (deltaCount-- > 0) {
            retStr += "0";
        }
        retStr += number.toString();
        return retStr;
    };
    return Util;
}());