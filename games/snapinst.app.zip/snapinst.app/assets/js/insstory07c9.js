function nFormatter(num) {
    if (num > 9999) {
        const lookup = [
        { value: 1, symbol: "" },
        { value: 1e3, symbol: "k" },
        { value: 1e6, symbol: "M" },
        { value: 1e9, symbol: "G" },
        { value: 1e12, symbol: "T" },
        { value: 1e15, symbol: "P" },
        { value: 1e18, symbol: "E" }
        ];
        const rx = /\.0+$|(\.[0-9]*[1-9])0+$/;
        var item = lookup.slice().reverse().find(function(item) {
        return num >= item.value;
        });
        return item ? (num / item.value).toFixed(1).replace(rx, "$1") + item.symbol : "0";
    }
    return new Intl.NumberFormat('en-IN').format(num);
}

function runProgress() {
    var e = $("#progress-bar");
    $("#progress-bar").width(0);
    var r = 1,
    t = setInterval(function() {
        
        r >= 99 ? (clearInterval(t)) : (r++, $("#progress-bar").width(r +'%'))
    }, 140)
}


let items = [
    'posts',
    'videos'
];

let idItem = {posts: 0, videos: 0, type:0};

$("form").on("submit", function (e) {
    $('#button-submit').prop('disabled', true);
    $("#button-submit").html("Please wait");
    $(".progress-form").show();
    runProgress();
    var dataString = $(this).serialize();
    $.ajax({
    type: "POST",
    url: "/story/active-story.php",
    data: dataString,
    success: function (result) {
        if (result.status_code != 0) {
            $("#form-alert").html(result.message);
            $("#form-alert").show();
            $("#button-submit").removeAttr('disabled');
            $("#button-submit").html("Search");
            $(".progress-form").hide();
            sendEvent(result.error_code);
        } else {
                let userData = result.data.data;
                $('#avatar').attr("src", userData.avatar_url);
                $('.modal-menu_left img').attr("src", userData.avatar_url);
                $('#username').html(userData.full_name);
                $('#user-bio').html(userData.biography);
                $('#post_count').html(nFormatter(userData.post_count));
                $('#follower_count').html(nFormatter(userData.follower_count));
                $('#following_count').html(nFormatter(userData.following_count));
                $('.profile').show();
                $('#hero').remove();
                $('#content').remove();
                if (userData.is_private === true) {
                    $('#alert-private').html(langStory.erorPrivate);
                    $('#alert-private').show();

                }
                $('#media').show();
                let posts = userData.posts.items;
                if (posts[0]['id']) {
                    // handlerSidecar(posts);
                    // Fix here
                    $.each(posts, function(key, post) {
                        if (post['__type'] === 'GraphImage') {
                            $("#posts").append('<div class="media-item"><img src="' + post.display_url + '" alt="photo"><svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="#fff" d="M447.1 32h-384C28.64 32-.0091 60.65-.0091 96v320c0 35.35 28.65 64 63.1 64h384c35.35 0 64-28.65 64-64V96C511.1 60.65 483.3 32 447.1 32zM111.1 96c26.51 0 48 21.49 48 48S138.5 192 111.1 192s-48-21.49-48-48S85.48 96 111.1 96zM446.1 407.6C443.3 412.8 437.9 416 432 416H82.01c-6.021 0-11.53-3.379-14.26-8.75c-2.73-5.367-2.215-11.81 1.334-16.68l70-96C142.1 290.4 146.9 288 152 288s9.916 2.441 12.93 6.574l32.46 44.51l93.3-139.1C293.7 194.7 298.7 192 304 192s10.35 2.672 13.31 7.125l128 192C448.6 396 448.9 402.3 446.1 407.6z"/></svg><a class="btn btn-primary" href="' + post.display_url + '&dl=1">Download</a></div>');
                
                        } else if (post['__type'] === 'GraphVideo') {
                            $("#posts").append('<div class="media-item"><img src="' + post.display_url + '" alt="photo"><svg aria-label="Clip" class="_ab6-" color="#ffffff" fill="#ffffff" height="20" role="img" viewBox="0 0 24 24" width="20"><path d="M12.823 1l2.974 5.002h-5.58l-2.65-4.971c.206-.013.419-.022.642-.027L8.55 1zm2.327 0h.298c3.06 0 4.468.754 5.64 1.887a6.007 6.007 0 011.596 2.82l.07.295h-4.629L15.15 1zm-9.667.377L7.95 6.002H1.244a6.01 6.01 0 013.942-4.53zm9.735 12.834l-4.545-2.624a.909.909 0 00-1.356.668l-.008.12v5.248a.91.91 0 001.255.84l.109-.053 4.545-2.624a.909.909 0 00.1-1.507l-.1-.068-4.545-2.624zm-14.2-6.209h21.964l.015.36.003.189v6.899c0 3.061-.755 4.469-1.888 5.64-1.151 1.114-2.5 1.856-5.33 1.909l-.334.003H8.551c-3.06 0-4.467-.755-5.64-1.889-1.114-1.15-1.854-2.498-1.908-5.33L1 15.45V8.551l.003-.189z" fill-rule="evenodd"></path></svg><a class="btn btn-primary" href="' + post.video_url + '&dl=1">Download</a></div>');
                        }
                    });
                }
                let videos = userData.videos.items;
                console.log(videos);
                if (videos[0]['id']) { // 
                    items['videos'] = videos;
                    $.each(videos, function(key, video) {
                        $("#videos").append('<div class="media-item"><img src="' + video.display_url + '" onclick="showFile(' + key + ', videos)" alt="video"><svg aria-label="Clip" class="_ab6-" color="#ffffff" fill="#ffffff" height="20" role="img" viewBox="0 0 24 24" width="20"><path d="M12.823 1l2.974 5.002h-5.58l-2.65-4.971c.206-.013.419-.022.642-.027L8.55 1zm2.327 0h.298c3.06 0 4.468.754 5.64 1.887a6.007 6.007 0 011.596 2.82l.07.295h-4.629L15.15 1zm-9.667.377L7.95 6.002H1.244a6.01 6.01 0 013.942-4.53zm9.735 12.834l-4.545-2.624a.909.909 0 00-1.356.668l-.008.12v5.248a.91.91 0 001.255.84l.109-.053 4.545-2.624a.909.909 0 00.1-1.507l-.1-.068-4.545-2.624zm-14.2-6.209h21.964l.015.36.003.189v6.899c0 3.061-.755 4.469-1.888 5.64-1.151 1.114-2.5 1.856-5.33 1.909l-.334.003H8.551c-3.06 0-4.467-.755-5.64-1.889-1.114-1.15-1.854-2.498-1.908-5.33L1 15.45V8.551l.003-.189z" fill-rule="evenodd"></path></svg><a class="btn btn-primary" href="' + video.video_url + '&dl=1">Download</a></div>');
                    });
                }
                getStory(userData.id);
            sendEvent("Get_userInfo_success");

        }
    }
    });

    e.preventDefault();
    
});


function handlerShowFile (id) {
    document.getElementById('story-dl').innerText = langStory.download;

    var data;
    if (idItem.type === 0) {
        data = items.posts;
    } else {
        data = items.videos;
    }
    console.log(data);
    if(data[id]['__type'] === 'GraphVideo') {

        $('#viewer .modal-file').html('<video controls playsinline src="' + data[id]['video_url']  + '" poster="' + data[id]['display_url'] + '"></video>');
        $('#story-dl').attr('href', data[id]['video_url']) + '&dl=1';
    } else {
        $('#viewer .modal-file').html('<img src="' +data[id]['display_url']+ '">');
        $('#story-dl').attr('href', data[id]['display_url'] + '&dl=1');
    }
}

function showFile(id, t) {
    if(t === 0) {
        idItem.type = 0;
        idItem.posts = id;
    } else {
        idItem.type = 1;
        idItem.videos = id;
    }
    $('#viewer').modal('show');
    handlerShowFile(id);
    
}

function handlerSidecar(allPost) {
    var newPosts = [];
    var counterPost = allPost.length;
    for (var i = 0; i < counterPost; i++) {
        if (allPost[i]['__type'] === 'GraphSidecar') {
            counterSidecar = allPost[i].items.length;
            for (var j = 0; j < counterSidecar; j++) {
                newPosts.push(allPost[i]['items'][j]);
            }
        } else {
            newPosts.push(allPost[i]);
        }
    }
    items['posts'] = newPosts;

    
    $.each(newPosts, function(key, post) {
        if (post['__type'] === 'GraphImage') {
            $( "#posts" ).append('<div class="media-item"><img src="' + post.display_url + '" onclick="showFile(' + key + ', 0)" alt="photo"><svg width="20" height="20" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="#fff" d="M447.1 32h-384C28.64 32-.0091 60.65-.0091 96v320c0 35.35 28.65 64 63.1 64h384c35.35 0 64-28.65 64-64V96C511.1 60.65 483.3 32 447.1 32zM111.1 96c26.51 0 48 21.49 48 48S138.5 192 111.1 192s-48-21.49-48-48S85.48 96 111.1 96zM446.1 407.6C443.3 412.8 437.9 416 432 416H82.01c-6.021 0-11.53-3.379-14.26-8.75c-2.73-5.367-2.215-11.81 1.334-16.68l70-96C142.1 290.4 146.9 288 152 288s9.916 2.441 12.93 6.574l32.46 44.51l93.3-139.1C293.7 194.7 298.7 192 304 192s10.35 2.672 13.31 7.125l128 192C448.6 396 448.9 402.3 446.1 407.6z"/></svg></div>');

        } else if (post['__type'] === 'GraphVideo') {
            $("#posts").append('<div class="media-item"><img src="' + post.display_url + '" onclick="showFile(' + key + ', 1)" alt="photo"><svg aria-label="Clip" class="_ab6-" color="#ffffff" fill="#ffffff" height="20" role="img" viewBox="0 0 24 24" width="20"><path d="M12.823 1l2.974 5.002h-5.58l-2.65-4.971c.206-.013.419-.022.642-.027L8.55 1zm2.327 0h.298c3.06 0 4.468.754 5.64 1.887a6.007 6.007 0 011.596 2.82l.07.295h-4.629L15.15 1zm-9.667.377L7.95 6.002H1.244a6.01 6.01 0 013.942-4.53zm9.735 12.834l-4.545-2.624a.909.909 0 00-1.356.668l-.008.12v5.248a.91.91 0 001.255.84l.109-.053 4.545-2.624a.909.909 0 00.1-1.507l-.1-.068-4.545-2.624zm-14.2-6.209h21.964l.015.36.003.189v6.899c0 3.061-.755 4.469-1.888 5.64-1.151 1.114-2.5 1.856-5.33 1.909l-.334.003H8.551c-3.06 0-4.467-.755-5.64-1.889-1.114-1.15-1.854-2.498-1.908-5.33L1 15.45V8.551l.003-.189z" fill-rule="evenodd"></path></svg></div>');
        }
    });

}

// Swipe to next 
$(function() {
    $("#viewer .modal-body").swipe( {
        swipe:function(event, direction, distance, duration, fingerCount, fingerData) {

            if (idItem.type === 0) {
                data = items.posts;
                id = idItem.posts;
                t = 'posts';
            } else {
                data = items.videos;
                id = idItem.videos;
                t = 'videos';
            }
            
            if (direction === 'left') {
                if (id === (data.length - 1)) {
                    idItem[t] = 0;
                    handlerShowFile(0);
                } else {
                    idItem[t] = idItem[t] + 1;
                    handlerShowFile(idItem[t]);
                }
                document.getElementById('story-dl').innerText = langStory.download;
            } else if (direction === 'right') {
                if (id === 0) {
                    idItem[t] = (data.length - 1);
                    handlerShowFile(data.length - 1);
                } else {
                    idItem[t] = idItem[t] - 1;
                    handlerShowFile(idItem[t]);
                }
                
                document.getElementById('story-dl').innerText = langStory.download;
            }
        }
    });
});

var storiesArr = [];
var socialStory;
function getStory(userId) {
    $.ajax({
    type: "POST",
    url: '/story/active-story.php',
    data: {id: userId},
    async: true,
    success: function(result) {
        
        $('#storyloading').hide();
        if (result.status_code != 0) {
            $('#alert-story').html(result.message);
            $('.alert-story').show();
            sendEvent(result.error_code);
        } else {
            storiesArr = result.data;
            $.each( result.data, function(key, value) {
                $( "#story-list" ).append('<div class="story-item" onclick="socialStory.launch(' + key + ');"> <div class="story-thumb"> <img src="' + value['thumbnailUrl'] + '"> </div></div>');
               
            });

            socialStory = new Story({
                playlist: storiesArr
            });
            sendEvent("Get_Story_success");
        }

    }
    });
}

$('#userinsta').on('input', function() {
    $("#form-alert").hide();
});